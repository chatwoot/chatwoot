# 🚀 FassZap Quick Start for EasyPanel

## 1. Upload & Deploy
1. Upload this ZIP to EasyPanel
2. Extract in your project
3. EasyPanel will auto-detect docker-compose.yml

## 2. Configure Environment
Set these variables in EasyPanel:
- `SECRET_KEY_BASE` - Generate a secure key
- `FRONTEND_URL` - Your domain URL
- `POSTGRES_PASSWORD` - Secure database password
- `REDIS_PASSWORD` - Secure Redis password

## 3. Optional: Configure Fabiana AI
- `FABIANA_OPEN_AI_API_KEY` - Your OpenAI API key
- `FABIANA_GROQ_API_KEY` - Your Groq API key
- `FABIANA_AI_PROVIDER` - Choose: openai, chatgpt, or groq

## 4. Deploy & Access
1. Deploy the stack
2. Wait 2-3 minutes for initialization
3. Access your FassZap instance
4. Create admin account

## 🎉 Done!
Your FassZap is ready with:
- ✅ Enterprise features enabled
- ✅ Orange theme
- ✅ Fabiana AI ready
- ✅ Push notifications working

For detailed instructions, see DEPLOY_EASYPANEL.md
