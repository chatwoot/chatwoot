#!/bin/bash
echo "🧡 Starting FassZap..."

# Wait for database
echo "⏳ Waiting for database..."
while ! pg_isready -h $POSTGRES_HOST -U $POSTGRES_USERNAME; do
  sleep 2
done

# Prepare database
echo "🗄️ Preparing database..."
bundle exec rails db:chatwoot_prepare

# Run FassZap setup
echo "⚙️ Running FassZap setup..."
./bin/fasszap_setup

# Start server
echo "🚀 Starting FassZap server..."
bundle exec rails server -b 0.0.0.0 -p 3000
