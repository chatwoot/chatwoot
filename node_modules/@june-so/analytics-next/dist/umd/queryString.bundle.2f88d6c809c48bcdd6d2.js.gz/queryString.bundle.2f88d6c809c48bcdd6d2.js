"use strict";
(self["webpackChunk_june_so_analytics_next"] = self["webpackChunk_june_so_analytics_next"] || []).push([["queryString"],{

/***/ 3195:
/*!****************************************!*\
  !*** ./src/core/query-string/index.ts ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "queryString": function() { return /* binding */ queryString; }
/* harmony export */ });
/* harmony import */ var _pickPrefix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pickPrefix */ 2330);

function queryString(analytics, query) {
    var a = document.createElement('a');
    a.href = query;
    var parsed = a.search.slice(1);
    var params = parsed.split('&').reduce(function (acc, str) {
        var _a = str.split('='), k = _a[0], v = _a[1];
        acc[k] = decodeURI(v).replace('+', ' ');
        return acc;
    }, {});
    var calls = [];
    /* eslint-disable @typescript-eslint/camelcase */
    var ajs_uid = params.ajs_uid, ajs_event = params.ajs_event, ajs_aid = params.ajs_aid;
    if (ajs_uid) {
        var uid = Array.isArray(params.ajs_uid)
            ? params.ajs_uid[0]
            : params.ajs_uid;
        var traits = (0,_pickPrefix__WEBPACK_IMPORTED_MODULE_0__.pickPrefix)('ajs_trait_', params);
        calls.push(analytics.identify(uid, traits));
    }
    if (ajs_event) {
        var event = Array.isArray(params.ajs_event)
            ? params.ajs_event[0]
            : params.ajs_event;
        var props = (0,_pickPrefix__WEBPACK_IMPORTED_MODULE_0__.pickPrefix)('ajs_prop_', params);
        calls.push(analytics.track(event, props));
    }
    if (ajs_aid) {
        var anonId = Array.isArray(params.ajs_aid)
            ? params.ajs_aid[0]
            : params.ajs_aid;
        analytics.setAnonymousId(anonId);
    }
    /* eslint-enable @typescript-eslint/camelcase */
    return Promise.all(calls);
}


/***/ }),

/***/ 2330:
/*!*********************************************!*\
  !*** ./src/core/query-string/pickPrefix.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pickPrefix": function() { return /* binding */ pickPrefix; }
/* harmony export */ });
/**
 * Returns an object containing only the properties prefixed by the input
 * string.
 * Ex: prefix('ajs_traits_', { ajs_traits_address: '123 St' })
 * will return { address: '123 St' }
 **/
function pickPrefix(prefix, object) {
    return Object.keys(object).reduce(function (acc, key) {
        if (key.startsWith(prefix)) {
            var field = key.substr(prefix.length);
            acc[field] = object[key];
        }
        return acc;
    }, {});
}


/***/ })

}]);
//# sourceMappingURL=queryString.bundle.2f88d6c809c48bcdd6d2.js.map