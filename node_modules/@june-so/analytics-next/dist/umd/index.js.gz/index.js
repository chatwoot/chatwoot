(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["AnalyticsNext"] = factory();
	else
		root["AnalyticsNext"] = factory();
})(self, function() {
return /******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 6025:
/*!******************************************************!*\
  !*** ./node_modules/@segment/facade/dist/address.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var obj_case_1 = __importDefault(__webpack_require__(/*! obj-case */ 3410));
function trait(a, b) {
    return function () {
        var traits = this.traits();
        var props = this.properties ? this.properties() : {};
        return (obj_case_1.default(traits, "address." + a) ||
            obj_case_1.default(traits, a) ||
            (b ? obj_case_1.default(traits, "address." + b) : null) ||
            (b ? obj_case_1.default(traits, b) : null) ||
            obj_case_1.default(props, "address." + a) ||
            obj_case_1.default(props, a) ||
            (b ? obj_case_1.default(props, "address." + b) : null) ||
            (b ? obj_case_1.default(props, b) : null));
    };
}
function default_1(proto) {
    proto.zip = trait("postalCode", "zip");
    proto.country = trait("country");
    proto.street = trait("street");
    proto.state = trait("state");
    proto.city = trait("city");
    proto.region = trait("region");
}
exports["default"] = default_1;
//# sourceMappingURL=address.js.map

/***/ }),

/***/ 6576:
/*!****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/alias.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Alias = void 0;
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var facade_1 = __webpack_require__(/*! ./facade */ 747);
function Alias(dictionary, opts) {
    facade_1.Facade.call(this, dictionary, opts);
}
exports.Alias = Alias;
inherits_1.default(Alias, facade_1.Facade);
Alias.prototype.action = function () {
    return "alias";
};
Alias.prototype.type = Alias.prototype.action;
Alias.prototype.previousId = function () {
    return this.field("previousId") || this.field("from");
};
Alias.prototype.from = Alias.prototype.previousId;
Alias.prototype.userId = function () {
    return this.field("userId") || this.field("to");
};
Alias.prototype.to = Alias.prototype.userId;
//# sourceMappingURL=alias.js.map

/***/ }),

/***/ 5655:
/*!*****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/delete.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Delete = void 0;
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var facade_1 = __webpack_require__(/*! ./facade */ 747);
function Delete(dictionary, opts) {
    facade_1.Facade.call(this, dictionary, opts);
}
exports.Delete = Delete;
inherits_1.default(Delete, facade_1.Facade);
Delete.prototype.type = function () {
    return "delete";
};
//# sourceMappingURL=delete.js.map

/***/ }),

/***/ 747:
/*!*****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/facade.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Facade = void 0;
var address_1 = __importDefault(__webpack_require__(/*! ./address */ 6025));
var lite_1 = __webpack_require__(/*! klona/lite */ 346);
var is_enabled_1 = __importDefault(__webpack_require__(/*! ./is-enabled */ 2530));
var new_date_1 = __importDefault(__webpack_require__(/*! new-date */ 8013));
var obj_case_1 = __importDefault(__webpack_require__(/*! obj-case */ 3410));
var isodate_traverse_1 = __importDefault(__webpack_require__(/*! @segment/isodate-traverse */ 8595));
function Facade(obj, opts) {
    opts = opts || {};
    this.raw = lite_1.klona(obj);
    if (!("clone" in opts))
        opts.clone = true;
    if (opts.clone)
        obj = lite_1.klona(obj);
    if (!("traverse" in opts))
        opts.traverse = true;
    if (!("timestamp" in obj))
        obj.timestamp = new Date();
    else
        obj.timestamp = new_date_1.default(obj.timestamp);
    if (opts.traverse)
        isodate_traverse_1.default(obj);
    this.opts = opts;
    this.obj = obj;
}
exports.Facade = Facade;
var f = Facade.prototype;
f.proxy = function (field) {
    var fields = field.split(".");
    field = fields.shift();
    var obj = this[field] || this.field(field);
    if (!obj)
        return obj;
    if (typeof obj === "function")
        obj = obj.call(this) || {};
    if (fields.length === 0)
        return this.opts.clone ? transform(obj) : obj;
    obj = obj_case_1.default(obj, fields.join("."));
    return this.opts.clone ? transform(obj) : obj;
};
f.field = function (field) {
    var obj = this.obj[field];
    return this.opts.clone ? transform(obj) : obj;
};
Facade.proxy = function (field) {
    return function () {
        return this.proxy(field);
    };
};
Facade.field = function (field) {
    return function () {
        return this.field(field);
    };
};
Facade.multi = function (path) {
    return function () {
        var multi = this.proxy(path + "s");
        if (Array.isArray(multi))
            return multi;
        var one = this.proxy(path);
        if (one)
            one = [this.opts.clone ? lite_1.klona(one) : one];
        return one || [];
    };
};
Facade.one = function (path) {
    return function () {
        var one = this.proxy(path);
        if (one)
            return one;
        var multi = this.proxy(path + "s");
        if (Array.isArray(multi))
            return multi[0];
    };
};
f.json = function () {
    var ret = this.opts.clone ? lite_1.klona(this.obj) : this.obj;
    if (this.type)
        ret.type = this.type();
    return ret;
};
f.rawEvent = function () {
    return this.raw;
};
f.options = function (integration) {
    var obj = this.obj.options || this.obj.context || {};
    var options = this.opts.clone ? lite_1.klona(obj) : obj;
    if (!integration)
        return options;
    if (!this.enabled(integration))
        return;
    var integrations = this.integrations();
    var value = integrations[integration] || obj_case_1.default(integrations, integration);
    if (typeof value !== "object")
        value = obj_case_1.default(this.options(), integration);
    return typeof value === "object" ? value : {};
};
f.context = f.options;
f.enabled = function (integration) {
    var allEnabled = this.proxy("options.providers.all");
    if (typeof allEnabled !== "boolean")
        allEnabled = this.proxy("options.all");
    if (typeof allEnabled !== "boolean")
        allEnabled = this.proxy("integrations.all");
    if (typeof allEnabled !== "boolean")
        allEnabled = true;
    var enabled = allEnabled && is_enabled_1.default(integration);
    var options = this.integrations();
    if (options.providers && options.providers.hasOwnProperty(integration)) {
        enabled = options.providers[integration];
    }
    if (options.hasOwnProperty(integration)) {
        var settings = options[integration];
        if (typeof settings === "boolean") {
            enabled = settings;
        }
        else {
            enabled = true;
        }
    }
    return !!enabled;
};
f.integrations = function () {
    return (this.obj.integrations || this.proxy("options.providers") || this.options());
};
f.active = function () {
    var active = this.proxy("options.active");
    if (active === null || active === undefined)
        active = true;
    return active;
};
f.anonymousId = function () {
    return this.field("anonymousId") || this.field("sessionId");
};
f.sessionId = f.anonymousId;
f.groupId = Facade.proxy("options.groupId");
f.traits = function (aliases) {
    var ret = this.proxy("options.traits") || {};
    var id = this.userId();
    aliases = aliases || {};
    if (id)
        ret.id = id;
    for (var alias in aliases) {
        var value = this[alias] == null
            ? this.proxy("options.traits." + alias)
            : this[alias]();
        if (value == null)
            continue;
        ret[aliases[alias]] = value;
        delete ret[alias];
    }
    return ret;
};
f.library = function () {
    var library = this.proxy("options.library");
    if (!library)
        return { name: "unknown", version: null };
    if (typeof library === "string")
        return { name: library, version: null };
    return library;
};
f.device = function () {
    var device = this.proxy("context.device");
    if (typeof device !== "object" || device === null) {
        device = {};
    }
    var library = this.library().name;
    if (device.type)
        return device;
    if (library.indexOf("ios") > -1)
        device.type = "ios";
    if (library.indexOf("android") > -1)
        device.type = "android";
    return device;
};
f.userAgent = Facade.proxy("context.userAgent");
f.timezone = Facade.proxy("context.timezone");
f.timestamp = Facade.field("timestamp");
f.channel = Facade.field("channel");
f.ip = Facade.proxy("context.ip");
f.userId = Facade.field("userId");
address_1.default(f);
function transform(obj) {
    return lite_1.klona(obj);
}
//# sourceMappingURL=facade.js.map

/***/ }),

/***/ 3789:
/*!****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/group.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Group = void 0;
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var is_email_1 = __importDefault(__webpack_require__(/*! ./is-email */ 6243));
var new_date_1 = __importDefault(__webpack_require__(/*! new-date */ 8013));
var facade_1 = __webpack_require__(/*! ./facade */ 747);
function Group(dictionary, opts) {
    facade_1.Facade.call(this, dictionary, opts);
}
exports.Group = Group;
inherits_1.default(Group, facade_1.Facade);
var g = Group.prototype;
g.action = function () {
    return "group";
};
g.type = g.action;
g.groupId = facade_1.Facade.field("groupId");
g.created = function () {
    var created = this.proxy("traits.createdAt") ||
        this.proxy("traits.created") ||
        this.proxy("properties.createdAt") ||
        this.proxy("properties.created");
    if (created)
        return new_date_1.default(created);
};
g.email = function () {
    var email = this.proxy("traits.email");
    if (email)
        return email;
    var groupId = this.groupId();
    if (is_email_1.default(groupId))
        return groupId;
};
g.traits = function (aliases) {
    var ret = this.properties();
    var id = this.groupId();
    aliases = aliases || {};
    if (id)
        ret.id = id;
    for (var alias in aliases) {
        var value = this[alias] == null ? this.proxy("traits." + alias) : this[alias]();
        if (value == null)
            continue;
        ret[aliases[alias]] = value;
        delete ret[alias];
    }
    return ret;
};
g.name = facade_1.Facade.proxy("traits.name");
g.industry = facade_1.Facade.proxy("traits.industry");
g.employees = facade_1.Facade.proxy("traits.employees");
g.properties = function () {
    return this.field("traits") || this.field("properties") || {};
};
//# sourceMappingURL=group.js.map

/***/ }),

/***/ 8649:
/*!*******************************************************!*\
  !*** ./node_modules/@segment/facade/dist/identify.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Identify = void 0;
var facade_1 = __webpack_require__(/*! ./facade */ 747);
var obj_case_1 = __importDefault(__webpack_require__(/*! obj-case */ 3410));
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var is_email_1 = __importDefault(__webpack_require__(/*! ./is-email */ 6243));
var new_date_1 = __importDefault(__webpack_require__(/*! new-date */ 8013));
var trim = function (str) { return str.trim(); };
function Identify(dictionary, opts) {
    facade_1.Facade.call(this, dictionary, opts);
}
exports.Identify = Identify;
inherits_1.default(Identify, facade_1.Facade);
var i = Identify.prototype;
i.action = function () {
    return "identify";
};
i.type = i.action;
i.traits = function (aliases) {
    var ret = this.field("traits") || {};
    var id = this.userId();
    aliases = aliases || {};
    if (id)
        ret.id = id;
    for (var alias in aliases) {
        var value = this[alias] == null ? this.proxy("traits." + alias) : this[alias]();
        if (value == null)
            continue;
        ret[aliases[alias]] = value;
        if (alias !== aliases[alias])
            delete ret[alias];
    }
    return ret;
};
i.email = function () {
    var email = this.proxy("traits.email");
    if (email)
        return email;
    var userId = this.userId();
    if (is_email_1.default(userId))
        return userId;
};
i.created = function () {
    var created = this.proxy("traits.created") || this.proxy("traits.createdAt");
    if (created)
        return new_date_1.default(created);
};
i.companyCreated = function () {
    var created = this.proxy("traits.company.created") ||
        this.proxy("traits.company.createdAt");
    if (created) {
        return new_date_1.default(created);
    }
};
i.companyName = function () {
    return this.proxy("traits.company.name");
};
i.name = function () {
    var name = this.proxy("traits.name");
    if (typeof name === "string") {
        return trim(name);
    }
    var firstName = this.firstName();
    var lastName = this.lastName();
    if (firstName && lastName) {
        return trim(firstName + " " + lastName);
    }
};
i.firstName = function () {
    var firstName = this.proxy("traits.firstName");
    if (typeof firstName === "string") {
        return trim(firstName);
    }
    var name = this.proxy("traits.name");
    if (typeof name === "string") {
        return trim(name).split(" ")[0];
    }
};
i.lastName = function () {
    var lastName = this.proxy("traits.lastName");
    if (typeof lastName === "string") {
        return trim(lastName);
    }
    var name = this.proxy("traits.name");
    if (typeof name !== "string") {
        return;
    }
    var space = trim(name).indexOf(" ");
    if (space === -1) {
        return;
    }
    return trim(name.substr(space + 1));
};
i.uid = function () {
    return this.userId() || this.username() || this.email();
};
i.description = function () {
    return this.proxy("traits.description") || this.proxy("traits.background");
};
i.age = function () {
    var date = this.birthday();
    var age = obj_case_1.default(this.traits(), "age");
    if (age != null)
        return age;
    if (!(date instanceof Date))
        return;
    var now = new Date();
    return now.getFullYear() - date.getFullYear();
};
i.avatar = function () {
    var traits = this.traits();
    return (obj_case_1.default(traits, "avatar") || obj_case_1.default(traits, "photoUrl") || obj_case_1.default(traits, "avatarUrl"));
};
i.position = function () {
    var traits = this.traits();
    return obj_case_1.default(traits, "position") || obj_case_1.default(traits, "jobTitle");
};
i.username = facade_1.Facade.proxy("traits.username");
i.website = facade_1.Facade.one("traits.website");
i.websites = facade_1.Facade.multi("traits.website");
i.phone = facade_1.Facade.one("traits.phone");
i.phones = facade_1.Facade.multi("traits.phone");
i.address = facade_1.Facade.proxy("traits.address");
i.gender = facade_1.Facade.proxy("traits.gender");
i.birthday = facade_1.Facade.proxy("traits.birthday");
//# sourceMappingURL=identify.js.map

/***/ }),

/***/ 9969:
/*!****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/index.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Delete = exports.Screen = exports.Page = exports.Track = exports.Identify = exports.Group = exports.Alias = exports.Facade = void 0;
var facade_1 = __webpack_require__(/*! ./facade */ 747);
Object.defineProperty(exports, "Facade", ({ enumerable: true, get: function () { return facade_1.Facade; } }));
var alias_1 = __webpack_require__(/*! ./alias */ 6576);
Object.defineProperty(exports, "Alias", ({ enumerable: true, get: function () { return alias_1.Alias; } }));
var group_1 = __webpack_require__(/*! ./group */ 3789);
Object.defineProperty(exports, "Group", ({ enumerable: true, get: function () { return group_1.Group; } }));
var identify_1 = __webpack_require__(/*! ./identify */ 8649);
Object.defineProperty(exports, "Identify", ({ enumerable: true, get: function () { return identify_1.Identify; } }));
var track_1 = __webpack_require__(/*! ./track */ 7286);
Object.defineProperty(exports, "Track", ({ enumerable: true, get: function () { return track_1.Track; } }));
var page_1 = __webpack_require__(/*! ./page */ 3070);
Object.defineProperty(exports, "Page", ({ enumerable: true, get: function () { return page_1.Page; } }));
var screen_1 = __webpack_require__(/*! ./screen */ 9860);
Object.defineProperty(exports, "Screen", ({ enumerable: true, get: function () { return screen_1.Screen; } }));
var delete_1 = __webpack_require__(/*! ./delete */ 5655);
Object.defineProperty(exports, "Delete", ({ enumerable: true, get: function () { return delete_1.Delete; } }));
exports["default"] = __assign(__assign({}, facade_1.Facade), { Alias: alias_1.Alias,
    Group: group_1.Group,
    Identify: identify_1.Identify,
    Track: track_1.Track,
    Page: page_1.Page,
    Screen: screen_1.Screen,
    Delete: delete_1.Delete });
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 6243:
/*!*******************************************************!*\
  !*** ./node_modules/@segment/facade/dist/is-email.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
var matcher = /.+\@.+\..+/;
function isEmail(string) {
    return matcher.test(string);
}
exports["default"] = isEmail;
//# sourceMappingURL=is-email.js.map

/***/ }),

/***/ 2530:
/*!*********************************************************!*\
  !*** ./node_modules/@segment/facade/dist/is-enabled.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
var disabled = {
    Salesforce: true,
};
function default_1(integration) {
    return !disabled[integration];
}
exports["default"] = default_1;
//# sourceMappingURL=is-enabled.js.map

/***/ }),

/***/ 3070:
/*!***************************************************!*\
  !*** ./node_modules/@segment/facade/dist/page.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Page = void 0;
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var facade_1 = __webpack_require__(/*! ./facade */ 747);
var track_1 = __webpack_require__(/*! ./track */ 7286);
var is_email_1 = __importDefault(__webpack_require__(/*! ./is-email */ 6243));
function Page(dictionary, opts) {
    facade_1.Facade.call(this, dictionary, opts);
}
exports.Page = Page;
inherits_1.default(Page, facade_1.Facade);
var p = Page.prototype;
p.action = function () {
    return "page";
};
p.type = p.action;
p.category = facade_1.Facade.field("category");
p.name = facade_1.Facade.field("name");
p.title = facade_1.Facade.proxy("properties.title");
p.path = facade_1.Facade.proxy("properties.path");
p.url = facade_1.Facade.proxy("properties.url");
p.referrer = function () {
    return (this.proxy("context.referrer.url") ||
        this.proxy("context.page.referrer") ||
        this.proxy("properties.referrer"));
};
p.properties = function (aliases) {
    var props = this.field("properties") || {};
    var category = this.category();
    var name = this.name();
    aliases = aliases || {};
    if (category)
        props.category = category;
    if (name)
        props.name = name;
    for (var alias in aliases) {
        var value = this[alias] == null ? this.proxy("properties." + alias) : this[alias]();
        if (value == null)
            continue;
        props[aliases[alias]] = value;
        if (alias !== aliases[alias])
            delete props[alias];
    }
    return props;
};
p.email = function () {
    var email = this.proxy("context.traits.email") || this.proxy("properties.email");
    if (email)
        return email;
    var userId = this.userId();
    if (is_email_1.default(userId))
        return userId;
};
p.fullName = function () {
    var category = this.category();
    var name = this.name();
    return name && category ? category + " " + name : name;
};
p.event = function (name) {
    return name ? "Viewed " + name + " Page" : "Loaded a Page";
};
p.track = function (name) {
    var json = this.json();
    json.event = this.event(name);
    json.timestamp = this.timestamp();
    json.properties = this.properties();
    return new track_1.Track(json, this.opts);
};
//# sourceMappingURL=page.js.map

/***/ }),

/***/ 9860:
/*!*****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/screen.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Screen = void 0;
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var page_1 = __webpack_require__(/*! ./page */ 3070);
var track_1 = __webpack_require__(/*! ./track */ 7286);
function Screen(dictionary, opts) {
    page_1.Page.call(this, dictionary, opts);
}
exports.Screen = Screen;
inherits_1.default(Screen, page_1.Page);
Screen.prototype.action = function () {
    return "screen";
};
Screen.prototype.type = Screen.prototype.action;
Screen.prototype.event = function (name) {
    return name ? "Viewed " + name + " Screen" : "Loaded a Screen";
};
Screen.prototype.track = function (name) {
    var json = this.json();
    json.event = this.event(name);
    json.timestamp = this.timestamp();
    json.properties = this.properties();
    return new track_1.Track(json, this.opts);
};
//# sourceMappingURL=screen.js.map

/***/ }),

/***/ 7286:
/*!****************************************************!*\
  !*** ./node_modules/@segment/facade/dist/track.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Track = void 0;
var inherits_1 = __importDefault(__webpack_require__(/*! inherits */ 5717));
var facade_1 = __webpack_require__(/*! ./facade */ 747);
var identify_1 = __webpack_require__(/*! ./identify */ 8649);
var is_email_1 = __importDefault(__webpack_require__(/*! ./is-email */ 6243));
var obj_case_1 = __importDefault(__webpack_require__(/*! obj-case */ 3410));
function Track(dictionary, opts) {
    facade_1.Facade.call(this, dictionary, opts);
}
exports.Track = Track;
inherits_1.default(Track, facade_1.Facade);
var t = Track.prototype;
t.action = function () {
    return "track";
};
t.type = t.action;
t.event = facade_1.Facade.field("event");
t.value = facade_1.Facade.proxy("properties.value");
t.category = facade_1.Facade.proxy("properties.category");
t.id = facade_1.Facade.proxy("properties.id");
t.productId = function () {
    return (this.proxy("properties.product_id") || this.proxy("properties.productId"));
};
t.promotionId = function () {
    return (this.proxy("properties.promotion_id") ||
        this.proxy("properties.promotionId"));
};
t.cartId = function () {
    return this.proxy("properties.cart_id") || this.proxy("properties.cartId");
};
t.checkoutId = function () {
    return (this.proxy("properties.checkout_id") || this.proxy("properties.checkoutId"));
};
t.paymentId = function () {
    return (this.proxy("properties.payment_id") || this.proxy("properties.paymentId"));
};
t.couponId = function () {
    return (this.proxy("properties.coupon_id") || this.proxy("properties.couponId"));
};
t.wishlistId = function () {
    return (this.proxy("properties.wishlist_id") || this.proxy("properties.wishlistId"));
};
t.reviewId = function () {
    return (this.proxy("properties.review_id") || this.proxy("properties.reviewId"));
};
t.orderId = function () {
    return (this.proxy("properties.id") ||
        this.proxy("properties.order_id") ||
        this.proxy("properties.orderId"));
};
t.sku = facade_1.Facade.proxy("properties.sku");
t.tax = facade_1.Facade.proxy("properties.tax");
t.name = facade_1.Facade.proxy("properties.name");
t.price = facade_1.Facade.proxy("properties.price");
t.total = facade_1.Facade.proxy("properties.total");
t.repeat = facade_1.Facade.proxy("properties.repeat");
t.coupon = facade_1.Facade.proxy("properties.coupon");
t.shipping = facade_1.Facade.proxy("properties.shipping");
t.discount = facade_1.Facade.proxy("properties.discount");
t.shippingMethod = function () {
    return (this.proxy("properties.shipping_method") ||
        this.proxy("properties.shippingMethod"));
};
t.paymentMethod = function () {
    return (this.proxy("properties.payment_method") ||
        this.proxy("properties.paymentMethod"));
};
t.description = facade_1.Facade.proxy("properties.description");
t.plan = facade_1.Facade.proxy("properties.plan");
t.subtotal = function () {
    var subtotal = obj_case_1.default(this.properties(), "subtotal");
    var total = this.total() || this.revenue();
    if (subtotal)
        return subtotal;
    if (!total)
        return 0;
    if (this.total()) {
        var n = this.tax();
        if (n)
            total -= n;
        n = this.shipping();
        if (n)
            total -= n;
        n = this.discount();
        if (n)
            total += n;
    }
    return total;
};
t.products = function () {
    var props = this.properties();
    var products = obj_case_1.default(props, "products");
    if (Array.isArray(products)) {
        return products.filter(function (item) { return item !== null; });
    }
    return [];
};
t.quantity = function () {
    var props = this.obj.properties || {};
    return props.quantity || 1;
};
t.currency = function () {
    var props = this.obj.properties || {};
    return props.currency || "USD";
};
t.referrer = function () {
    return (this.proxy("context.referrer.url") ||
        this.proxy("context.page.referrer") ||
        this.proxy("properties.referrer"));
};
t.query = facade_1.Facade.proxy("options.query");
t.properties = function (aliases) {
    var ret = this.field("properties") || {};
    aliases = aliases || {};
    for (var alias in aliases) {
        var value = this[alias] == null ? this.proxy("properties." + alias) : this[alias]();
        if (value == null)
            continue;
        ret[aliases[alias]] = value;
        delete ret[alias];
    }
    return ret;
};
t.username = function () {
    return (this.proxy("traits.username") ||
        this.proxy("properties.username") ||
        this.userId() ||
        this.sessionId());
};
t.email = function () {
    var email = this.proxy("traits.email") ||
        this.proxy("properties.email") ||
        this.proxy("options.traits.email");
    if (email)
        return email;
    var userId = this.userId();
    if (is_email_1.default(userId))
        return userId;
};
t.revenue = function () {
    var revenue = this.proxy("properties.revenue");
    var event = this.event();
    var orderCompletedRegExp = /^[ _]?completed[ _]?order[ _]?|^[ _]?order[ _]?completed[ _]?$/i;
    if (!revenue && event && event.match(orderCompletedRegExp)) {
        revenue = this.proxy("properties.total");
    }
    return currency(revenue);
};
t.cents = function () {
    var revenue = this.revenue();
    return typeof revenue !== "number" ? this.value() || 0 : revenue * 100;
};
t.identify = function () {
    var json = this.json();
    json.traits = this.traits();
    return new identify_1.Identify(json, this.opts);
};
function currency(val) {
    if (!val)
        return;
    if (typeof val === "number") {
        return val;
    }
    if (typeof val !== "string") {
        return;
    }
    val = val.replace(/\$/g, "");
    val = parseFloat(val);
    if (!isNaN(val)) {
        return val;
    }
}
//# sourceMappingURL=track.js.map

/***/ }),

/***/ 8595:
/*!*************************************************************!*\
  !*** ./node_modules/@segment/isodate-traverse/lib/index.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var isodate = __webpack_require__(/*! @segment/isodate */ 8336);

/**
 * Expose `traverse`.
 */
module.exports = traverse;

/**
 * Recursively traverse an object or array, and convert
 * all ISO date strings parse into Date objects.
 *
 * @param {Object} input - object, array, or string to convert
 * @param {Boolean} strict - only convert strings with year, month, and date
 * @return {Object}
 */
function traverse(input, strict) {
  if (strict === undefined) strict = true;
  if (input && typeof input === 'object') {
    return traverseObject(input, strict);
  } else if (Array.isArray(input)) {
    return traverseArray(input, strict);
  } else if (isodate.is(input, strict)) {
    return isodate.parse(input);
  }
  return input;
}

/**
 * Object traverser helper function.
 *
 * @param {Object} obj - object to traverse
 * @param {Boolean} strict - only convert strings with year, month, and date
 * @return {Object}
 */
function traverseObject(obj, strict) {
  Object.keys(obj).forEach(function(key) {
    obj[key] = traverse(obj[key], strict);
  });
  return obj;
}

/**
 * Array traverser helper function
 *
 * @param {Array} arr - array to traverse
 * @param {Boolean} strict - only convert strings with year, month, and date
 * @return {Array}
 */
function traverseArray(arr, strict) {
  arr.forEach(function(value, index) {
    arr[index] = traverse(value, strict);
  });
  return arr;
}


/***/ }),

/***/ 8336:
/*!****************************************************!*\
  !*** ./node_modules/@segment/isodate/lib/index.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


/**
 * Matcher, slightly modified from:
 *
 * https://github.com/csnover/js-iso8601/blob/lax/iso8601.js
 */

var matcher = /^(\d{4})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:([ T])(\d{2}):?(\d{2})(?::?(\d{2})(?:[,\.](\d{1,}))?)?(?:(Z)|([+\-])(\d{2})(?::?(\d{2}))?)?)?$/;

/**
 * Convert an ISO date string to a date. Fallback to native `Date.parse`.
 *
 * https://github.com/csnover/js-iso8601/blob/lax/iso8601.js
 *
 * @param {String} iso
 * @return {Date}
 */

exports.parse = function(iso) {
  var numericKeys = [1, 5, 6, 7, 11, 12];
  var arr = matcher.exec(iso);
  var offset = 0;

  // fallback to native parsing
  if (!arr) {
    return new Date(iso);
  }

  /* eslint-disable no-cond-assign */
  // remove undefined values
  for (var i = 0, val; val = numericKeys[i]; i++) {
    arr[val] = parseInt(arr[val], 10) || 0;
  }
  /* eslint-enable no-cond-assign */

  // allow undefined days and months
  arr[2] = parseInt(arr[2], 10) || 1;
  arr[3] = parseInt(arr[3], 10) || 1;

  // month is 0-11
  arr[2]--;

  // allow abitrary sub-second precision
  arr[8] = arr[8] ? (arr[8] + '00').substring(0, 3) : 0;

  // apply timezone if one exists
  if (arr[4] === ' ') {
    offset = new Date().getTimezoneOffset();
  } else if (arr[9] !== 'Z' && arr[10]) {
    offset = arr[11] * 60 + arr[12];
    if (arr[10] === '+') {
      offset = 0 - offset;
    }
  }

  var millis = Date.UTC(arr[1], arr[2], arr[3], arr[5], arr[6] + offset, arr[7], arr[8]);
  return new Date(millis);
};


/**
 * Checks whether a `string` is an ISO date string. `strict` mode requires that
 * the date string at least have a year, month and date.
 *
 * @param {String} string
 * @param {Boolean} strict
 * @return {Boolean}
 */

exports.is = function(string, strict) {
  if (typeof string !== 'string') {
    return false;
  }
  if (strict && (/^\d{4}-\d{2}-\d{2}/).test(string) === false) {
    return false;
  }
  return matcher.test(string);
};


/***/ }),

/***/ 5717:
/*!***************************************************!*\
  !*** ./node_modules/inherits/inherits_browser.js ***!
  \***************************************************/
/***/ (function(module) {

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      })
    }
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor
      var TempCtor = function () {}
      TempCtor.prototype = superCtor.prototype
      ctor.prototype = new TempCtor()
      ctor.prototype.constructor = ctor
    }
  }
}


/***/ }),

/***/ 6808:
/*!*************************************************!*\
  !*** ./node_modules/js-cookie/src/js.cookie.js ***!
  \*************************************************/
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
 * JavaScript Cookie v2.2.1
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */
;(function (factory) {
	var registeredInModuleLoader;
	if (true) {
		!(__WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) :
		__WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		registeredInModuleLoader = true;
	}
	if (true) {
		module.exports = factory();
		registeredInModuleLoader = true;
	}
	if (!registeredInModuleLoader) {
		var OldCookies = window.Cookies;
		var api = window.Cookies = factory();
		api.noConflict = function () {
			window.Cookies = OldCookies;
			return api;
		};
	}
}(function () {
	function extend () {
		var i = 0;
		var result = {};
		for (; i < arguments.length; i++) {
			var attributes = arguments[ i ];
			for (var key in attributes) {
				result[key] = attributes[key];
			}
		}
		return result;
	}

	function decode (s) {
		return s.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent);
	}

	function init (converter) {
		function api() {}

		function set (key, value, attributes) {
			if (typeof document === 'undefined') {
				return;
			}

			attributes = extend({
				path: '/'
			}, api.defaults, attributes);

			if (typeof attributes.expires === 'number') {
				attributes.expires = new Date(new Date() * 1 + attributes.expires * 864e+5);
			}

			// We're using "expires" because "max-age" is not supported by IE
			attributes.expires = attributes.expires ? attributes.expires.toUTCString() : '';

			try {
				var result = JSON.stringify(value);
				if (/^[\{\[]/.test(result)) {
					value = result;
				}
			} catch (e) {}

			value = converter.write ?
				converter.write(value, key) :
				encodeURIComponent(String(value))
					.replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);

			key = encodeURIComponent(String(key))
				.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent)
				.replace(/[\(\)]/g, escape);

			var stringifiedAttributes = '';
			for (var attributeName in attributes) {
				if (!attributes[attributeName]) {
					continue;
				}
				stringifiedAttributes += '; ' + attributeName;
				if (attributes[attributeName] === true) {
					continue;
				}

				// Considers RFC 6265 section 5.2:
				// ...
				// 3.  If the remaining unparsed-attributes contains a %x3B (";")
				//     character:
				// Consume the characters of the unparsed-attributes up to,
				// not including, the first %x3B (";") character.
				// ...
				stringifiedAttributes += '=' + attributes[attributeName].split(';')[0];
			}

			return (document.cookie = key + '=' + value + stringifiedAttributes);
		}

		function get (key, json) {
			if (typeof document === 'undefined') {
				return;
			}

			var jar = {};
			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all.
			var cookies = document.cookie ? document.cookie.split('; ') : [];
			var i = 0;

			for (; i < cookies.length; i++) {
				var parts = cookies[i].split('=');
				var cookie = parts.slice(1).join('=');

				if (!json && cookie.charAt(0) === '"') {
					cookie = cookie.slice(1, -1);
				}

				try {
					var name = decode(parts[0]);
					cookie = (converter.read || converter)(cookie, name) ||
						decode(cookie);

					if (json) {
						try {
							cookie = JSON.parse(cookie);
						} catch (e) {}
					}

					jar[name] = cookie;

					if (key === name) {
						break;
					}
				} catch (e) {}
			}

			return key ? jar[key] : jar;
		}

		api.set = set;
		api.get = function (key) {
			return get(key, false /* read as raw */);
		};
		api.getJSON = function (key) {
			return get(key, true /* read as json */);
		};
		api.remove = function (key, attributes) {
			set(key, '', extend(attributes, {
				expires: -1
			}));
		};

		api.defaults = {};

		api.withConverter = init;

		return api;
	}

	return init(function () {});
}));


/***/ }),

/***/ 346:
/*!******************************************!*\
  !*** ./node_modules/klona/lite/index.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, exports) {

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	return x;
}

exports.klona = klona;

/***/ }),

/***/ 8013:
/*!********************************************!*\
  !*** ./node_modules/new-date/lib/index.js ***!
  \********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var isodate = __webpack_require__(/*! @segment/isodate */ 8336);
var milliseconds = __webpack_require__(/*! ./milliseconds */ 8040);
var seconds = __webpack_require__(/*! ./seconds */ 4085);

var objProto = Object.prototype;
var toStr = objProto.toString;

function isDate(value) {
  return toStr.call(value) === "[object Date]";
}

function isNumber(value) {
  return toStr.call(value) === "[object Number]";
}

/**
 * Returns a new Javascript Date object, allowing a variety of extra input types
 * over the native Date constructor.
 *
 * @param {Date|string|number} val
 */
module.exports = function newDate(val) {
  if (isDate(val)) return val;
  if (isNumber(val)) return new Date(toMs(val));

  // date strings
  if (isodate.is(val)) {
    return isodate.parse(val);
  }
  if (milliseconds.is(val)) {
    return milliseconds.parse(val);
  }
  if (seconds.is(val)) {
    return seconds.parse(val);
  }

  // fallback to Date.parse
  return new Date(val);
};

/**
 * If the number passed val is seconds from the epoch, turn it into milliseconds.
 * Milliseconds would be greater than 31557600000 (December 31, 1970).
 *
 * @param {number} num
 */
function toMs(num) {
  if (num < 31557600000) return num * 1000;
  return num;
}


/***/ }),

/***/ 8040:
/*!***************************************************!*\
  !*** ./node_modules/new-date/lib/milliseconds.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


/**
 * Matcher.
 */

var matcher = /\d{13}/;

/**
 * Check whether a string is a millisecond date string.
 *
 * @param {string} string
 * @return {boolean}
 */
exports.is = function (string) {
  return matcher.test(string);
};

/**
 * Convert a millisecond string to a date.
 *
 * @param {string} millis
 * @return {Date}
 */
exports.parse = function (millis) {
  millis = parseInt(millis, 10);
  return new Date(millis);
};


/***/ }),

/***/ 4085:
/*!**********************************************!*\
  !*** ./node_modules/new-date/lib/seconds.js ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


/**
 * Matcher.
 */

var matcher = /\d{10}/;

/**
 * Check whether a string is a second date string.
 *
 * @param {string} string
 * @return {Boolean}
 */
exports.is = function (string) {
  return matcher.test(string);
};

/**
 * Convert a second string to a date.
 *
 * @param {string} seconds
 * @return {Date}
 */
exports.parse = function (seconds) {
  var millis = parseInt(seconds, 10) * 1000;
  return new Date(millis);
};


/***/ }),

/***/ 3410:
/*!****************************************!*\
  !*** ./node_modules/obj-case/index.js ***!
  \****************************************/
/***/ (function(module) {


var identity = function(_){ return _; };


/**
 * Module exports, export
 */

module.exports = multiple(find);
module.exports.find = module.exports;


/**
 * Export the replacement function, return the modified object
 */

module.exports.replace = function (obj, key, val, options) {
  multiple(replace).call(this, obj, key, val, options);
  return obj;
};


/**
 * Export the delete function, return the modified object
 */

module.exports.del = function (obj, key, options) {
  multiple(del).call(this, obj, key, null, options);
  return obj;
};


/**
 * Compose applying the function to a nested key
 */

function multiple (fn) {
  return function (obj, path, val, options) {
    var normalize = options && isFunction(options.normalizer) ? options.normalizer : defaultNormalize;
    path = normalize(path);

    var key;
    var finished = false;

    while (!finished) loop();

    function loop() {
      for (key in obj) {
        var normalizedKey = normalize(key);
        if (0 === path.indexOf(normalizedKey)) {
          var temp = path.substr(normalizedKey.length);
          if (temp.charAt(0) === '.' || temp.length === 0) {
            path = temp.substr(1);
            var child = obj[key];

            // we're at the end and there is nothing.
            if (null == child) {
              finished = true;
              return;
            }

            // we're at the end and there is something.
            if (!path.length) {
              finished = true;
              return;
            }

            // step into child
            obj = child;

            // but we're done here
            return;
          }
        }
      }

      key = undefined;
      // if we found no matching properties
      // on the current object, there's no match.
      finished = true;
    }

    if (!key) return;
    if (null == obj) return obj;

    // the `obj` and `key` is one above the leaf object and key, so
    // start object: { a: { 'b.c': 10 } }
    // end object: { 'b.c': 10 }
    // end key: 'b.c'
    // this way, you can do `obj[key]` and get `10`.
    return fn(obj, key, val);
  };
}


/**
 * Find an object by its key
 *
 * find({ first_name : 'Calvin' }, 'firstName')
 */

function find (obj, key) {
  if (obj.hasOwnProperty(key)) return obj[key];
}


/**
 * Delete a value for a given key
 *
 * del({ a : 'b', x : 'y' }, 'X' }) -> { a : 'b' }
 */

function del (obj, key) {
  if (obj.hasOwnProperty(key)) delete obj[key];
  return obj;
}


/**
 * Replace an objects existing value with a new one
 *
 * replace({ a : 'b' }, 'a', 'c') -> { a : 'c' }
 */

function replace (obj, key, val) {
  if (obj.hasOwnProperty(key)) obj[key] = val;
  return obj;
}

/**
 * Normalize a `dot.separated.path`.
 *
 * A.HELL(!*&#(!)O_WOR   LD.bar => ahelloworldbar
 *
 * @param {String} path
 * @return {String}
 */

function defaultNormalize(path) {
  return path.replace(/[^a-zA-Z0-9\.]+/g, '').toLowerCase();
}

/**
 * Check if a value is a function.
 *
 * @param {*} val
 * @return {boolean} Returns `true` if `val` is a function, otherwise `false`.
 */

function isFunction(val) {
  return typeof val === 'function';
}


/***/ }),

/***/ 8322:
/*!*********************************************!*\
  !*** ./node_modules/spark-md5/spark-md5.js ***!
  \*********************************************/
/***/ (function(module) {

(function (factory) {
    if (true) {
        // Node/CommonJS
        module.exports = factory();
    } else { var glob; }
}(function (undefined) {

    'use strict';

    /*
     * Fastest md5 implementation around (JKM md5).
     * Credits: Joseph Myers
     *
     * @see http://www.myersdaily.org/joseph/javascript/md5-text.html
     * @see http://jsperf.com/md5-shootout/7
     */

    /* this function is much faster,
      so if possible we use it. Some IEs
      are the only ones I know of that
      need the idiotic second function,
      generated by an if clause.  */
    var add32 = function (a, b) {
        return (a + b) & 0xFFFFFFFF;
    },
        hex_chr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'];


    function cmn(q, a, b, x, s, t) {
        a = add32(add32(a, q), add32(x, t));
        return add32((a << s) | (a >>> (32 - s)), b);
    }

    function md5cycle(x, k) {
        var a = x[0],
            b = x[1],
            c = x[2],
            d = x[3];

        a += (b & c | ~b & d) + k[0] - 680876936 | 0;
        a  = (a << 7 | a >>> 25) + b | 0;
        d += (a & b | ~a & c) + k[1] - 389564586 | 0;
        d  = (d << 12 | d >>> 20) + a | 0;
        c += (d & a | ~d & b) + k[2] + 606105819 | 0;
        c  = (c << 17 | c >>> 15) + d | 0;
        b += (c & d | ~c & a) + k[3] - 1044525330 | 0;
        b  = (b << 22 | b >>> 10) + c | 0;
        a += (b & c | ~b & d) + k[4] - 176418897 | 0;
        a  = (a << 7 | a >>> 25) + b | 0;
        d += (a & b | ~a & c) + k[5] + 1200080426 | 0;
        d  = (d << 12 | d >>> 20) + a | 0;
        c += (d & a | ~d & b) + k[6] - 1473231341 | 0;
        c  = (c << 17 | c >>> 15) + d | 0;
        b += (c & d | ~c & a) + k[7] - 45705983 | 0;
        b  = (b << 22 | b >>> 10) + c | 0;
        a += (b & c | ~b & d) + k[8] + 1770035416 | 0;
        a  = (a << 7 | a >>> 25) + b | 0;
        d += (a & b | ~a & c) + k[9] - 1958414417 | 0;
        d  = (d << 12 | d >>> 20) + a | 0;
        c += (d & a | ~d & b) + k[10] - 42063 | 0;
        c  = (c << 17 | c >>> 15) + d | 0;
        b += (c & d | ~c & a) + k[11] - 1990404162 | 0;
        b  = (b << 22 | b >>> 10) + c | 0;
        a += (b & c | ~b & d) + k[12] + 1804603682 | 0;
        a  = (a << 7 | a >>> 25) + b | 0;
        d += (a & b | ~a & c) + k[13] - 40341101 | 0;
        d  = (d << 12 | d >>> 20) + a | 0;
        c += (d & a | ~d & b) + k[14] - 1502002290 | 0;
        c  = (c << 17 | c >>> 15) + d | 0;
        b += (c & d | ~c & a) + k[15] + 1236535329 | 0;
        b  = (b << 22 | b >>> 10) + c | 0;

        a += (b & d | c & ~d) + k[1] - 165796510 | 0;
        a  = (a << 5 | a >>> 27) + b | 0;
        d += (a & c | b & ~c) + k[6] - 1069501632 | 0;
        d  = (d << 9 | d >>> 23) + a | 0;
        c += (d & b | a & ~b) + k[11] + 643717713 | 0;
        c  = (c << 14 | c >>> 18) + d | 0;
        b += (c & a | d & ~a) + k[0] - 373897302 | 0;
        b  = (b << 20 | b >>> 12) + c | 0;
        a += (b & d | c & ~d) + k[5] - 701558691 | 0;
        a  = (a << 5 | a >>> 27) + b | 0;
        d += (a & c | b & ~c) + k[10] + 38016083 | 0;
        d  = (d << 9 | d >>> 23) + a | 0;
        c += (d & b | a & ~b) + k[15] - 660478335 | 0;
        c  = (c << 14 | c >>> 18) + d | 0;
        b += (c & a | d & ~a) + k[4] - 405537848 | 0;
        b  = (b << 20 | b >>> 12) + c | 0;
        a += (b & d | c & ~d) + k[9] + 568446438 | 0;
        a  = (a << 5 | a >>> 27) + b | 0;
        d += (a & c | b & ~c) + k[14] - 1019803690 | 0;
        d  = (d << 9 | d >>> 23) + a | 0;
        c += (d & b | a & ~b) + k[3] - 187363961 | 0;
        c  = (c << 14 | c >>> 18) + d | 0;
        b += (c & a | d & ~a) + k[8] + 1163531501 | 0;
        b  = (b << 20 | b >>> 12) + c | 0;
        a += (b & d | c & ~d) + k[13] - 1444681467 | 0;
        a  = (a << 5 | a >>> 27) + b | 0;
        d += (a & c | b & ~c) + k[2] - 51403784 | 0;
        d  = (d << 9 | d >>> 23) + a | 0;
        c += (d & b | a & ~b) + k[7] + 1735328473 | 0;
        c  = (c << 14 | c >>> 18) + d | 0;
        b += (c & a | d & ~a) + k[12] - 1926607734 | 0;
        b  = (b << 20 | b >>> 12) + c | 0;

        a += (b ^ c ^ d) + k[5] - 378558 | 0;
        a  = (a << 4 | a >>> 28) + b | 0;
        d += (a ^ b ^ c) + k[8] - 2022574463 | 0;
        d  = (d << 11 | d >>> 21) + a | 0;
        c += (d ^ a ^ b) + k[11] + 1839030562 | 0;
        c  = (c << 16 | c >>> 16) + d | 0;
        b += (c ^ d ^ a) + k[14] - 35309556 | 0;
        b  = (b << 23 | b >>> 9) + c | 0;
        a += (b ^ c ^ d) + k[1] - 1530992060 | 0;
        a  = (a << 4 | a >>> 28) + b | 0;
        d += (a ^ b ^ c) + k[4] + 1272893353 | 0;
        d  = (d << 11 | d >>> 21) + a | 0;
        c += (d ^ a ^ b) + k[7] - 155497632 | 0;
        c  = (c << 16 | c >>> 16) + d | 0;
        b += (c ^ d ^ a) + k[10] - 1094730640 | 0;
        b  = (b << 23 | b >>> 9) + c | 0;
        a += (b ^ c ^ d) + k[13] + 681279174 | 0;
        a  = (a << 4 | a >>> 28) + b | 0;
        d += (a ^ b ^ c) + k[0] - 358537222 | 0;
        d  = (d << 11 | d >>> 21) + a | 0;
        c += (d ^ a ^ b) + k[3] - 722521979 | 0;
        c  = (c << 16 | c >>> 16) + d | 0;
        b += (c ^ d ^ a) + k[6] + 76029189 | 0;
        b  = (b << 23 | b >>> 9) + c | 0;
        a += (b ^ c ^ d) + k[9] - 640364487 | 0;
        a  = (a << 4 | a >>> 28) + b | 0;
        d += (a ^ b ^ c) + k[12] - 421815835 | 0;
        d  = (d << 11 | d >>> 21) + a | 0;
        c += (d ^ a ^ b) + k[15] + 530742520 | 0;
        c  = (c << 16 | c >>> 16) + d | 0;
        b += (c ^ d ^ a) + k[2] - 995338651 | 0;
        b  = (b << 23 | b >>> 9) + c | 0;

        a += (c ^ (b | ~d)) + k[0] - 198630844 | 0;
        a  = (a << 6 | a >>> 26) + b | 0;
        d += (b ^ (a | ~c)) + k[7] + 1126891415 | 0;
        d  = (d << 10 | d >>> 22) + a | 0;
        c += (a ^ (d | ~b)) + k[14] - 1416354905 | 0;
        c  = (c << 15 | c >>> 17) + d | 0;
        b += (d ^ (c | ~a)) + k[5] - 57434055 | 0;
        b  = (b << 21 |b >>> 11) + c | 0;
        a += (c ^ (b | ~d)) + k[12] + 1700485571 | 0;
        a  = (a << 6 | a >>> 26) + b | 0;
        d += (b ^ (a | ~c)) + k[3] - 1894986606 | 0;
        d  = (d << 10 | d >>> 22) + a | 0;
        c += (a ^ (d | ~b)) + k[10] - 1051523 | 0;
        c  = (c << 15 | c >>> 17) + d | 0;
        b += (d ^ (c | ~a)) + k[1] - 2054922799 | 0;
        b  = (b << 21 |b >>> 11) + c | 0;
        a += (c ^ (b | ~d)) + k[8] + 1873313359 | 0;
        a  = (a << 6 | a >>> 26) + b | 0;
        d += (b ^ (a | ~c)) + k[15] - 30611744 | 0;
        d  = (d << 10 | d >>> 22) + a | 0;
        c += (a ^ (d | ~b)) + k[6] - 1560198380 | 0;
        c  = (c << 15 | c >>> 17) + d | 0;
        b += (d ^ (c | ~a)) + k[13] + 1309151649 | 0;
        b  = (b << 21 |b >>> 11) + c | 0;
        a += (c ^ (b | ~d)) + k[4] - 145523070 | 0;
        a  = (a << 6 | a >>> 26) + b | 0;
        d += (b ^ (a | ~c)) + k[11] - 1120210379 | 0;
        d  = (d << 10 | d >>> 22) + a | 0;
        c += (a ^ (d | ~b)) + k[2] + 718787259 | 0;
        c  = (c << 15 | c >>> 17) + d | 0;
        b += (d ^ (c | ~a)) + k[9] - 343485551 | 0;
        b  = (b << 21 | b >>> 11) + c | 0;

        x[0] = a + x[0] | 0;
        x[1] = b + x[1] | 0;
        x[2] = c + x[2] | 0;
        x[3] = d + x[3] | 0;
    }

    function md5blk(s) {
        var md5blks = [],
            i; /* Andy King said do it this way. */

        for (i = 0; i < 64; i += 4) {
            md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24);
        }
        return md5blks;
    }

    function md5blk_array(a) {
        var md5blks = [],
            i; /* Andy King said do it this way. */

        for (i = 0; i < 64; i += 4) {
            md5blks[i >> 2] = a[i] + (a[i + 1] << 8) + (a[i + 2] << 16) + (a[i + 3] << 24);
        }
        return md5blks;
    }

    function md51(s) {
        var n = s.length,
            state = [1732584193, -271733879, -1732584194, 271733878],
            i,
            length,
            tail,
            tmp,
            lo,
            hi;

        for (i = 64; i <= n; i += 64) {
            md5cycle(state, md5blk(s.substring(i - 64, i)));
        }
        s = s.substring(i - 64);
        length = s.length;
        tail = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        for (i = 0; i < length; i += 1) {
            tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
        }
        tail[i >> 2] |= 0x80 << ((i % 4) << 3);
        if (i > 55) {
            md5cycle(state, tail);
            for (i = 0; i < 16; i += 1) {
                tail[i] = 0;
            }
        }

        // Beware that the final length might not fit in 32 bits so we take care of that
        tmp = n * 8;
        tmp = tmp.toString(16).match(/(.*?)(.{0,8})$/);
        lo = parseInt(tmp[2], 16);
        hi = parseInt(tmp[1], 16) || 0;

        tail[14] = lo;
        tail[15] = hi;

        md5cycle(state, tail);
        return state;
    }

    function md51_array(a) {
        var n = a.length,
            state = [1732584193, -271733879, -1732584194, 271733878],
            i,
            length,
            tail,
            tmp,
            lo,
            hi;

        for (i = 64; i <= n; i += 64) {
            md5cycle(state, md5blk_array(a.subarray(i - 64, i)));
        }

        // Not sure if it is a bug, however IE10 will always produce a sub array of length 1
        // containing the last element of the parent array if the sub array specified starts
        // beyond the length of the parent array - weird.
        // https://connect.microsoft.com/IE/feedback/details/771452/typed-array-subarray-issue
        a = (i - 64) < n ? a.subarray(i - 64) : new Uint8Array(0);

        length = a.length;
        tail = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        for (i = 0; i < length; i += 1) {
            tail[i >> 2] |= a[i] << ((i % 4) << 3);
        }

        tail[i >> 2] |= 0x80 << ((i % 4) << 3);
        if (i > 55) {
            md5cycle(state, tail);
            for (i = 0; i < 16; i += 1) {
                tail[i] = 0;
            }
        }

        // Beware that the final length might not fit in 32 bits so we take care of that
        tmp = n * 8;
        tmp = tmp.toString(16).match(/(.*?)(.{0,8})$/);
        lo = parseInt(tmp[2], 16);
        hi = parseInt(tmp[1], 16) || 0;

        tail[14] = lo;
        tail[15] = hi;

        md5cycle(state, tail);

        return state;
    }

    function rhex(n) {
        var s = '',
            j;
        for (j = 0; j < 4; j += 1) {
            s += hex_chr[(n >> (j * 8 + 4)) & 0x0F] + hex_chr[(n >> (j * 8)) & 0x0F];
        }
        return s;
    }

    function hex(x) {
        var i;
        for (i = 0; i < x.length; i += 1) {
            x[i] = rhex(x[i]);
        }
        return x.join('');
    }

    // In some cases the fast add32 function cannot be used..
    if (hex(md51('hello')) !== '5d41402abc4b2a76b9719d911017c592') {
        add32 = function (x, y) {
            var lsw = (x & 0xFFFF) + (y & 0xFFFF),
                msw = (x >> 16) + (y >> 16) + (lsw >> 16);
            return (msw << 16) | (lsw & 0xFFFF);
        };
    }

    // ---------------------------------------------------

    /**
     * ArrayBuffer slice polyfill.
     *
     * @see https://github.com/ttaubert/node-arraybuffer-slice
     */

    if (typeof ArrayBuffer !== 'undefined' && !ArrayBuffer.prototype.slice) {
        (function () {
            function clamp(val, length) {
                val = (val | 0) || 0;

                if (val < 0) {
                    return Math.max(val + length, 0);
                }

                return Math.min(val, length);
            }

            ArrayBuffer.prototype.slice = function (from, to) {
                var length = this.byteLength,
                    begin = clamp(from, length),
                    end = length,
                    num,
                    target,
                    targetArray,
                    sourceArray;

                if (to !== undefined) {
                    end = clamp(to, length);
                }

                if (begin > end) {
                    return new ArrayBuffer(0);
                }

                num = end - begin;
                target = new ArrayBuffer(num);
                targetArray = new Uint8Array(target);

                sourceArray = new Uint8Array(this, begin, num);
                targetArray.set(sourceArray);

                return target;
            };
        })();
    }

    // ---------------------------------------------------

    /**
     * Helpers.
     */

    function toUtf8(str) {
        if (/[\u0080-\uFFFF]/.test(str)) {
            str = unescape(encodeURIComponent(str));
        }

        return str;
    }

    function utf8Str2ArrayBuffer(str, returnUInt8Array) {
        var length = str.length,
           buff = new ArrayBuffer(length),
           arr = new Uint8Array(buff),
           i;

        for (i = 0; i < length; i += 1) {
            arr[i] = str.charCodeAt(i);
        }

        return returnUInt8Array ? arr : buff;
    }

    function arrayBuffer2Utf8Str(buff) {
        return String.fromCharCode.apply(null, new Uint8Array(buff));
    }

    function concatenateArrayBuffers(first, second, returnUInt8Array) {
        var result = new Uint8Array(first.byteLength + second.byteLength);

        result.set(new Uint8Array(first));
        result.set(new Uint8Array(second), first.byteLength);

        return returnUInt8Array ? result : result.buffer;
    }

    function hexToBinaryString(hex) {
        var bytes = [],
            length = hex.length,
            x;

        for (x = 0; x < length - 1; x += 2) {
            bytes.push(parseInt(hex.substr(x, 2), 16));
        }

        return String.fromCharCode.apply(String, bytes);
    }

    // ---------------------------------------------------

    /**
     * SparkMD5 OOP implementation.
     *
     * Use this class to perform an incremental md5, otherwise use the
     * static methods instead.
     */

    function SparkMD5() {
        // call reset to init the instance
        this.reset();
    }

    /**
     * Appends a string.
     * A conversion will be applied if an utf8 string is detected.
     *
     * @param {String} str The string to be appended
     *
     * @return {SparkMD5} The instance itself
     */
    SparkMD5.prototype.append = function (str) {
        // Converts the string to utf8 bytes if necessary
        // Then append as binary
        this.appendBinary(toUtf8(str));

        return this;
    };

    /**
     * Appends a binary string.
     *
     * @param {String} contents The binary string to be appended
     *
     * @return {SparkMD5} The instance itself
     */
    SparkMD5.prototype.appendBinary = function (contents) {
        this._buff += contents;
        this._length += contents.length;

        var length = this._buff.length,
            i;

        for (i = 64; i <= length; i += 64) {
            md5cycle(this._hash, md5blk(this._buff.substring(i - 64, i)));
        }

        this._buff = this._buff.substring(i - 64);

        return this;
    };

    /**
     * Finishes the incremental computation, reseting the internal state and
     * returning the result.
     *
     * @param {Boolean} raw True to get the raw string, false to get the hex string
     *
     * @return {String} The result
     */
    SparkMD5.prototype.end = function (raw) {
        var buff = this._buff,
            length = buff.length,
            i,
            tail = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ret;

        for (i = 0; i < length; i += 1) {
            tail[i >> 2] |= buff.charCodeAt(i) << ((i % 4) << 3);
        }

        this._finish(tail, length);
        ret = hex(this._hash);

        if (raw) {
            ret = hexToBinaryString(ret);
        }

        this.reset();

        return ret;
    };

    /**
     * Resets the internal state of the computation.
     *
     * @return {SparkMD5} The instance itself
     */
    SparkMD5.prototype.reset = function () {
        this._buff = '';
        this._length = 0;
        this._hash = [1732584193, -271733879, -1732584194, 271733878];

        return this;
    };

    /**
     * Gets the internal state of the computation.
     *
     * @return {Object} The state
     */
    SparkMD5.prototype.getState = function () {
        return {
            buff: this._buff,
            length: this._length,
            hash: this._hash.slice()
        };
    };

    /**
     * Gets the internal state of the computation.
     *
     * @param {Object} state The state
     *
     * @return {SparkMD5} The instance itself
     */
    SparkMD5.prototype.setState = function (state) {
        this._buff = state.buff;
        this._length = state.length;
        this._hash = state.hash;

        return this;
    };

    /**
     * Releases memory used by the incremental buffer and other additional
     * resources. If you plan to use the instance again, use reset instead.
     */
    SparkMD5.prototype.destroy = function () {
        delete this._hash;
        delete this._buff;
        delete this._length;
    };

    /**
     * Finish the final calculation based on the tail.
     *
     * @param {Array}  tail   The tail (will be modified)
     * @param {Number} length The length of the remaining buffer
     */
    SparkMD5.prototype._finish = function (tail, length) {
        var i = length,
            tmp,
            lo,
            hi;

        tail[i >> 2] |= 0x80 << ((i % 4) << 3);
        if (i > 55) {
            md5cycle(this._hash, tail);
            for (i = 0; i < 16; i += 1) {
                tail[i] = 0;
            }
        }

        // Do the final computation based on the tail and length
        // Beware that the final length may not fit in 32 bits so we take care of that
        tmp = this._length * 8;
        tmp = tmp.toString(16).match(/(.*?)(.{0,8})$/);
        lo = parseInt(tmp[2], 16);
        hi = parseInt(tmp[1], 16) || 0;

        tail[14] = lo;
        tail[15] = hi;
        md5cycle(this._hash, tail);
    };

    /**
     * Performs the md5 hash on a string.
     * A conversion will be applied if utf8 string is detected.
     *
     * @param {String}  str The string
     * @param {Boolean} [raw] True to get the raw string, false to get the hex string
     *
     * @return {String} The result
     */
    SparkMD5.hash = function (str, raw) {
        // Converts the string to utf8 bytes if necessary
        // Then compute it using the binary function
        return SparkMD5.hashBinary(toUtf8(str), raw);
    };

    /**
     * Performs the md5 hash on a binary string.
     *
     * @param {String}  content The binary string
     * @param {Boolean} [raw]     True to get the raw string, false to get the hex string
     *
     * @return {String} The result
     */
    SparkMD5.hashBinary = function (content, raw) {
        var hash = md51(content),
            ret = hex(hash);

        return raw ? hexToBinaryString(ret) : ret;
    };

    // ---------------------------------------------------

    /**
     * SparkMD5 OOP implementation for array buffers.
     *
     * Use this class to perform an incremental md5 ONLY for array buffers.
     */
    SparkMD5.ArrayBuffer = function () {
        // call reset to init the instance
        this.reset();
    };

    /**
     * Appends an array buffer.
     *
     * @param {ArrayBuffer} arr The array to be appended
     *
     * @return {SparkMD5.ArrayBuffer} The instance itself
     */
    SparkMD5.ArrayBuffer.prototype.append = function (arr) {
        var buff = concatenateArrayBuffers(this._buff.buffer, arr, true),
            length = buff.length,
            i;

        this._length += arr.byteLength;

        for (i = 64; i <= length; i += 64) {
            md5cycle(this._hash, md5blk_array(buff.subarray(i - 64, i)));
        }

        this._buff = (i - 64) < length ? new Uint8Array(buff.buffer.slice(i - 64)) : new Uint8Array(0);

        return this;
    };

    /**
     * Finishes the incremental computation, reseting the internal state and
     * returning the result.
     *
     * @param {Boolean} raw True to get the raw string, false to get the hex string
     *
     * @return {String} The result
     */
    SparkMD5.ArrayBuffer.prototype.end = function (raw) {
        var buff = this._buff,
            length = buff.length,
            tail = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            i,
            ret;

        for (i = 0; i < length; i += 1) {
            tail[i >> 2] |= buff[i] << ((i % 4) << 3);
        }

        this._finish(tail, length);
        ret = hex(this._hash);

        if (raw) {
            ret = hexToBinaryString(ret);
        }

        this.reset();

        return ret;
    };

    /**
     * Resets the internal state of the computation.
     *
     * @return {SparkMD5.ArrayBuffer} The instance itself
     */
    SparkMD5.ArrayBuffer.prototype.reset = function () {
        this._buff = new Uint8Array(0);
        this._length = 0;
        this._hash = [1732584193, -271733879, -1732584194, 271733878];

        return this;
    };

    /**
     * Gets the internal state of the computation.
     *
     * @return {Object} The state
     */
    SparkMD5.ArrayBuffer.prototype.getState = function () {
        var state = SparkMD5.prototype.getState.call(this);

        // Convert buffer to a string
        state.buff = arrayBuffer2Utf8Str(state.buff);

        return state;
    };

    /**
     * Gets the internal state of the computation.
     *
     * @param {Object} state The state
     *
     * @return {SparkMD5.ArrayBuffer} The instance itself
     */
    SparkMD5.ArrayBuffer.prototype.setState = function (state) {
        // Convert string to buffer
        state.buff = utf8Str2ArrayBuffer(state.buff, true);

        return SparkMD5.prototype.setState.call(this, state);
    };

    SparkMD5.ArrayBuffer.prototype.destroy = SparkMD5.prototype.destroy;

    SparkMD5.ArrayBuffer.prototype._finish = SparkMD5.prototype._finish;

    /**
     * Performs the md5 hash on an array buffer.
     *
     * @param {ArrayBuffer} arr The array buffer
     * @param {Boolean}     [raw] True to get the raw string, false to get the hex one
     *
     * @return {String} The result
     */
    SparkMD5.ArrayBuffer.hash = function (arr, raw) {
        var hash = md51_array(new Uint8Array(arr)),
            ret = hex(hash);

        return raw ? hexToBinaryString(ret) : ret;
    };

    return SparkMD5;
}));


/***/ }),

/***/ 4876:
/*!**************************!*\
  !*** ./src/analytics.ts ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Analytics": function() { return /* binding */ Analytics; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./browser */ 9686);
/* harmony import */ var _core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./core/arguments-resolver */ 4090);
/* harmony import */ var _core_callback__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/callback */ 5546);
/* harmony import */ var _core_connection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/connection */ 8231);
/* harmony import */ var _core_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core/context */ 5373);
/* harmony import */ var _core_emitter__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./core/emitter */ 6373);
/* harmony import */ var _core_events__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/events */ 7763);
/* harmony import */ var _core_queue_event_queue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./core/queue/event-queue */ 9054);
/* harmony import */ var _core_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/user */ 8617);
/* harmony import */ var _lib_bind_all__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lib/bind-all */ 9348);
/* harmony import */ var _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/priority-queue/persisted */ 1778);
/* harmony import */ var _generated_version__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./generated/version */ 1594);













var deprecationWarning = 'This is being deprecated and will be not be available in future releases of Analytics JS';
// reference any pre-existing "analytics" object so a user can restore the reference
// eslint-disable-next-line @typescript-eslint/no-explicit-any
var globalAny = __webpack_require__.g;
var _analytics = globalAny.analytics;
var Analytics = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(Analytics, _super);
    function Analytics(settings, options, queue, user, group) {
        var _a, _b;
        var _this = _super.call(this) || this;
        _this._debug = false;
        _this.initialized = false;
        _this.user = function () {
            return _this._user;
        };
        _this.init = _this.initialize.bind(_this);
        var cookieOptions = options === null || options === void 0 ? void 0 : options.cookie;
        _this.settings = settings;
        _this.settings.timeout = (_a = _this.settings.timeout) !== null && _a !== void 0 ? _a : 300;
        _this.queue = queue !== null && queue !== void 0 ? queue : new _core_queue_event_queue__WEBPACK_IMPORTED_MODULE_1__.EventQueue(new _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_2__.PersistedPriorityQueue((options === null || options === void 0 ? void 0 : options.retryQueue) ? 4 : 1, 'event-queue'));
        _this._user = user !== null && user !== void 0 ? user : new _core_user__WEBPACK_IMPORTED_MODULE_3__.User(options === null || options === void 0 ? void 0 : options.user, cookieOptions).load();
        _this._group = group !== null && group !== void 0 ? group : new _core_user__WEBPACK_IMPORTED_MODULE_3__.Group(options === null || options === void 0 ? void 0 : options.group, cookieOptions).load();
        _this.eventFactory = new _core_events__WEBPACK_IMPORTED_MODULE_4__.EventFactory(_this._user);
        _this.integrations = (_b = options === null || options === void 0 ? void 0 : options.integrations) !== null && _b !== void 0 ? _b : {};
        _this.options = options !== null && options !== void 0 ? options : {};
        (0,_lib_bind_all__WEBPACK_IMPORTED_MODULE_5__["default"])(_this);
        return _this;
    }
    Analytics.prototype.track = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _a, name, data, opts, cb, segmentEvent;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                _a = _core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__.resolveArguments.apply(void 0, args), name = _a[0], data = _a[1], opts = _a[2], cb = _a[3];
                segmentEvent = this.eventFactory.track(name, data, opts, this.integrations);
                return [2 /*return*/, this.dispatch(segmentEvent, cb).then(function (ctx) {
                        _this.emit('track', name, ctx.event.properties, ctx.event.options);
                        return ctx;
                    })];
            });
        });
    };
    Analytics.prototype.page = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _a, category, page, properties, options, callback, segmentEvent;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                _a = _core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__.resolvePageArguments.apply(void 0, args), category = _a[0], page = _a[1], properties = _a[2], options = _a[3], callback = _a[4];
                segmentEvent = this.eventFactory.page(category, page, properties, options, this.integrations);
                return [2 /*return*/, this.dispatch(segmentEvent, callback).then(function (ctx) {
                        _this.emit('page', category, page, ctx.event.properties, ctx.event.options);
                        return ctx;
                    })];
            });
        });
    };
    Analytics.prototype.identify = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _a, id, _traits, options, callback, segmentEvent;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                _a = (0,_core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__.resolveUserArguments)(this._user).apply(void 0, args), id = _a[0], _traits = _a[1], options = _a[2], callback = _a[3];
                this._user.identify(id, _traits);
                segmentEvent = this.eventFactory.identify(this._user.id(), this._user.traits(), options, this.integrations);
                return [2 /*return*/, this.dispatch(segmentEvent, callback).then(function (ctx) {
                        _this.emit('identify', ctx.event.userId, ctx.event.traits, ctx.event.options);
                        return ctx;
                    })];
            });
        });
    };
    Analytics.prototype.group = function () {
        var _this = this;
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (args.length === 0) {
            return this._group;
        }
        var _a = (0,_core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__.resolveUserArguments)(this._group).apply(void 0, args), id = _a[0], _traits = _a[1], options = _a[2], callback = _a[3];
        this._group.identify(id, _traits);
        var groupId = this._group.id();
        var groupTraits = this._group.traits();
        var segmentEvent = this.eventFactory.group(groupId, groupTraits, options, this.integrations);
        return this.dispatch(segmentEvent, callback).then(function (ctx) {
            _this.emit('group', ctx.event.groupId, ctx.event.traits, ctx.event.options);
            return ctx;
        });
    };
    Analytics.prototype.alias = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _a, to, from, options, callback, segmentEvent;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                _a = _core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__.resolveAliasArguments.apply(void 0, args), to = _a[0], from = _a[1], options = _a[2], callback = _a[3];
                segmentEvent = this.eventFactory.alias(to, from, options, this.integrations);
                return [2 /*return*/, this.dispatch(segmentEvent, callback).then(function (ctx) {
                        _this.emit('alias', to, from, ctx.event.options);
                        return ctx;
                    })];
            });
        });
    };
    Analytics.prototype.screen = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _a, category, page, properties, options, callback, segmentEvent;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                _a = _core_arguments_resolver__WEBPACK_IMPORTED_MODULE_6__.resolvePageArguments.apply(void 0, args), category = _a[0], page = _a[1], properties = _a[2], options = _a[3], callback = _a[4];
                segmentEvent = this.eventFactory.screen(category, page, properties, options, this.integrations);
                return [2 /*return*/, this.dispatch(segmentEvent, callback).then(function (ctx) {
                        _this.emit('screen', category, page, ctx.event.properties, ctx.event.options);
                        return ctx;
                    })];
            });
        });
    };
    Analytics.prototype.trackClick = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var autotrack;
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, __webpack_require__.e(/*! import() | auto-track */ "auto-track").then(__webpack_require__.bind(__webpack_require__, /*! ./core/auto-track */ 2839))];
                    case 1:
                        autotrack = _b.sent();
                        return [2 /*return*/, (_a = autotrack.link).call.apply(_a, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArrays)([this], args))];
                }
            });
        });
    };
    Analytics.prototype.trackLink = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var autotrack;
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, __webpack_require__.e(/*! import() | auto-track */ "auto-track").then(__webpack_require__.bind(__webpack_require__, /*! ./core/auto-track */ 2839))];
                    case 1:
                        autotrack = _b.sent();
                        return [2 /*return*/, (_a = autotrack.link).call.apply(_a, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArrays)([this], args))];
                }
            });
        });
    };
    Analytics.prototype.trackSubmit = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var autotrack;
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, __webpack_require__.e(/*! import() | auto-track */ "auto-track").then(__webpack_require__.bind(__webpack_require__, /*! ./core/auto-track */ 2839))];
                    case 1:
                        autotrack = _b.sent();
                        return [2 /*return*/, (_a = autotrack.form).call.apply(_a, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArrays)([this], args))];
                }
            });
        });
    };
    Analytics.prototype.trackForm = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var autotrack;
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, __webpack_require__.e(/*! import() | auto-track */ "auto-track").then(__webpack_require__.bind(__webpack_require__, /*! ./core/auto-track */ 2839))];
                    case 1:
                        autotrack = _b.sent();
                        return [2 /*return*/, (_a = autotrack.form).call.apply(_a, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArrays)([this], args))];
                }
            });
        });
    };
    Analytics.prototype.register = function () {
        var plugins = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            plugins[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var ctx, registrations;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        ctx = _core_context__WEBPACK_IMPORTED_MODULE_7__.Context.system();
                        registrations = plugins.map(function (xt) {
                            return _this.queue.register(ctx, xt, _this);
                        });
                        return [4 /*yield*/, Promise.all(registrations)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, ctx];
                }
            });
        });
    };
    Analytics.prototype.deregister = function () {
        var plugins = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            plugins[_i] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var ctx, deregistrations;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        ctx = _core_context__WEBPACK_IMPORTED_MODULE_7__.Context.system();
                        deregistrations = plugins.map(function (pl) { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(_this, void 0, void 0, function () {
                            var plugin;
                            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                                plugin = this.queue.plugins.find(function (p) { return p.name === pl; });
                                if (plugin) {
                                    return [2 /*return*/, this.queue.deregister(ctx, plugin, this)];
                                }
                                else {
                                    ctx.log('warn', "plugin " + pl + " not found");
                                }
                                return [2 /*return*/];
                            });
                        }); });
                        return [4 /*yield*/, Promise.all(deregistrations)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, ctx];
                }
            });
        });
    };
    Analytics.prototype.debug = function (toggle) {
        // Make sure legacy ajs debug gets turned off if it was enabled before upgrading.
        if (toggle === false && localStorage.getItem('debug')) {
            localStorage.removeItem('debug');
        }
        this._debug = toggle;
        return this;
    };
    Analytics.prototype.reset = function () {
        this._user.reset();
    };
    Analytics.prototype.timeout = function (timeout) {
        this.settings.timeout = timeout;
    };
    Analytics.prototype.dispatch = function (event, callback) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var ctx, dispatched;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        ctx = new _core_context__WEBPACK_IMPORTED_MODULE_7__.Context(event);
                        if ((0,_core_connection__WEBPACK_IMPORTED_MODULE_8__.isOffline)() && !this.options.retryQueue) {
                            return [2 /*return*/, ctx];
                        }
                        if (!this.queue.isEmpty()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.queue.dispatchSingle(ctx)];
                    case 1:
                        dispatched = _a.sent();
                        return [3 /*break*/, 4];
                    case 2: return [4 /*yield*/, this.queue.dispatch(ctx)];
                    case 3:
                        dispatched = _a.sent();
                        _a.label = 4;
                    case 4:
                        if (!callback) return [3 /*break*/, 6];
                        return [4 /*yield*/, (0,_core_callback__WEBPACK_IMPORTED_MODULE_9__.invokeCallback)(dispatched, callback, this.settings.timeout)];
                    case 5:
                        dispatched = _a.sent();
                        _a.label = 6;
                    case 6:
                        if (this._debug) {
                            dispatched.flush();
                        }
                        return [2 /*return*/, dispatched];
                }
            });
        });
    };
    Analytics.prototype.addSourceMiddleware = function (fn) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var sourceMiddlewarePlugin, integrations, plugin;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, __webpack_require__.e(/*! import() | middleware */ "middleware").then(__webpack_require__.bind(__webpack_require__, /*! ./plugins/middleware */ 2734))];
                    case 1:
                        sourceMiddlewarePlugin = (_a.sent()).sourceMiddlewarePlugin;
                        integrations = {};
                        this.queue.plugins.forEach(function (plugin) {
                            if (plugin.type === 'destination') {
                                return (integrations[plugin.name] = true);
                            }
                        });
                        plugin = sourceMiddlewarePlugin(fn, integrations);
                        return [4 /*yield*/, this.register(plugin)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, this];
                }
            });
        });
    };
    Analytics.prototype.addDestinationMiddleware = function (integrationName) {
        var middlewares = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            middlewares[_i - 1] = arguments[_i];
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var legacyDestinations;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                legacyDestinations = this.queue.plugins.filter(function (xt) {
                    // xt instanceof LegacyDestination &&
                    return xt.name.toLowerCase() === integrationName.toLowerCase();
                });
                legacyDestinations.forEach(function (destination) {
                    destination.addMiddleware.apply(destination, middlewares);
                });
                return [2 /*return*/, this];
            });
        });
    };
    Analytics.prototype.setAnonymousId = function (id) {
        return this._user.anonymousId(id);
    };
    Analytics.prototype.queryString = function (query) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var queryString;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, __webpack_require__.e(/*! import() | queryString */ "queryString").then(__webpack_require__.bind(__webpack_require__, /*! ./core/query-string */ 3195))];
                    case 1:
                        queryString = (_a.sent()).queryString;
                        return [2 /*return*/, queryString(this, query)];
                }
            });
        });
    };
    /**
     * @deprecated This function does not register a destination plugin.
     *
     * Instantiates a legacy Analytics.js destination.
     *
     * This function does not register the destination as an Analytics.JS plugin,
     * all the it does it to invoke the factory function back.
     */
    Analytics.prototype.use = function (legacyPluginFactory) {
        legacyPluginFactory(this);
        return this;
    };
    Analytics.prototype.ready = function (callback) {
        if (callback === void 0) { callback = function (res) { return res; }; }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                return [2 /*return*/, Promise.all(this.queue.plugins.map(function (i) { return (i.ready ? i.ready() : Promise.resolve()); })).then(function (res) {
                        callback(res);
                        return res;
                    })];
            });
        });
    };
    // analytics-classic api
    Analytics.prototype.noConflict = function () {
        console.warn(deprecationWarning);
        window.analytics = _analytics !== null && _analytics !== void 0 ? _analytics : this;
        return this;
    };
    Analytics.prototype.normalize = function (msg) {
        console.warn(deprecationWarning);
        return this.eventFactory.normalize(msg);
    };
    Object.defineProperty(Analytics.prototype, "failedInitializations", {
        get: function () {
            console.warn(deprecationWarning);
            return this.queue.failedInitializations;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Analytics.prototype, "VERSION", {
        get: function () {
            return _generated_version__WEBPACK_IMPORTED_MODULE_10__.version;
        },
        enumerable: false,
        configurable: true
    });
    Analytics.prototype.initialize = function (settings, options) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.warn(deprecationWarning);
                        if (!settings) return [3 /*break*/, 2];
                        return [4 /*yield*/, _browser__WEBPACK_IMPORTED_MODULE_11__.AnalyticsBrowser.load(settings, options)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        this.options = options || {};
                        return [2 /*return*/, this];
                }
            });
        });
    };
    Analytics.prototype.pageview = function (url) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.warn(deprecationWarning);
                        return [4 /*yield*/, this.page({ path: url })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, this];
                }
            });
        });
    };
    Object.defineProperty(Analytics.prototype, "plugins", {
        get: function () {
            var _a;
            console.warn(deprecationWarning);
            // @ts-expect-error
            return (_a = this._plugins) !== null && _a !== void 0 ? _a : {};
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Analytics.prototype, "Integrations", {
        get: function () {
            console.warn(deprecationWarning);
            var integrations = this.queue.plugins
                .filter(function (plugin) { return plugin.type === 'destination'; })
                .reduce(function (acc, plugin) {
                var name = plugin.name
                    .toLowerCase()
                    .replace('.', '')
                    .split(' ')
                    .join('-') + "Integration";
                // @ts-expect-error
                var integration = window[name];
                if (!integration) {
                    return acc;
                }
                var nested = integration.Integration; // hack - Google Analytics function resides in the "Integration" field
                if (nested) {
                    acc[plugin.name] = nested;
                    return acc;
                }
                acc[plugin.name] = integration;
                return acc;
            }, {});
            return integrations;
        },
        enumerable: false,
        configurable: true
    });
    // analytics-classic stubs
    Analytics.prototype.log = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.addIntegrationMiddleware = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.listeners = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.addEventListener = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.removeAllListeners = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.removeListener = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.removeEventListener = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.hasListeners = function () {
        console.warn(deprecationWarning);
        return;
    };
    // This function is only used to add GA and Appcue, but these are already being added to Integrations by AJSN
    Analytics.prototype.addIntegration = function () {
        console.warn(deprecationWarning);
        return;
    };
    Analytics.prototype.add = function () {
        console.warn(deprecationWarning);
        return;
    };
    // snippet function
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Analytics.prototype.push = function (args) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        var an = this;
        var method = args.shift();
        if (method) {
            if (!an[method])
                return;
        }
        an[method].apply(this, args);
    };
    return Analytics;
}(_core_emitter__WEBPACK_IMPORTED_MODULE_12__.Emitter));



/***/ }),

/***/ 9686:
/*!************************!*\
  !*** ./src/browser.ts ***!
  \************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadLegacySettings": function() { return /* binding */ loadLegacySettings; },
/* harmony export */   "AnalyticsBrowser": function() { return /* binding */ AnalyticsBrowser; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _lib_get_process_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lib/get-process-env */ 9562);
/* harmony import */ var _analytics__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./analytics */ 4876);
/* harmony import */ var _core_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/context */ 5373);
/* harmony import */ var _lib_merged_options__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/merged-options */ 7851);
/* harmony import */ var _plugins_page_enrichment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./plugins/page-enrichment */ 7985);
/* harmony import */ var _plugins_remote_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./plugins/remote-loader */ 990);
/* harmony import */ var _plugins_segmentio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./plugins/segmentio */ 6678);
/* harmony import */ var _plugins_validation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./plugins/validation */ 2487);









function loadLegacySettings(writeKey, settings) {
    var _a;
    return {
        // @ts-expect-error
        integrations: {
            'Segment.io': {
                apiKey: writeKey,
                addBundledMetadata: true,
                apiHost: (_a = settings.apiHost) !== null && _a !== void 0 ? _a : "api.june.so/sdk",
                versionSettings: { version: '4.4.7', componentTypes: ['browser'] },
            },
        },
        plan: {
            track: { __default: { enabled: true, integrations: {} } },
            identify: {
                __default: { enabled: true },
            },
            group: { __default: { enabled: true } },
        },
        edgeFunction: {},
        analyticsNextEnabled: true,
        middlewareSettings: {},
        enabledMiddleware: {},
        metrics: { sampleRate: 0.1 },
        legacyVideoPluginsEnabled: false,
        remotePlugins: [],
    };
}
function hasLegacyDestinations(settings) {
    return ((0,_lib_get_process_env__WEBPACK_IMPORTED_MODULE_0__.getProcessEnv)().NODE_ENV !== 'test' &&
        // just one integration means segmentio
        Object.keys(settings.integrations).length > 1);
}
function flushBuffered(analytics) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var wa, buffered, _loop_1, _i, buffered_1, _a, operation, args;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
            switch (_b.label) {
                case 0:
                    wa = window.analytics;
                    buffered = 
                    // @ts-expect-error
                    wa && wa[0] ? (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__spreadArrays)(wa) : [];
                    _loop_1 = function (operation, args) {
                        var _a;
                        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
                            switch (_b.label) {
                                case 0:
                                    if (!
                                    // @ts-expect-error
                                    (analytics[operation] &&
                                        // @ts-expect-error
                                        typeof analytics[operation] === 'function')) 
                                    // @ts-expect-error
                                    return [3 /*break*/, 3];
                                    if (!(operation === 'addSourceMiddleware')) return [3 /*break*/, 2];
                                    // @ts-expect-error
                                    return [4 /*yield*/, (_a = analytics[operation]).call.apply(_a, (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__spreadArrays)([analytics], args))];
                                case 1:
                                    // @ts-expect-error
                                    _b.sent();
                                    return [3 /*break*/, 3];
                                case 2:
                                    // flush each individual event as its own task, so not to block initial page loads
                                    setTimeout(function () {
                                        var _a;
                                        // @ts-expect-error
                                        (_a = analytics[operation]).call.apply(_a, (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__spreadArrays)([analytics], args));
                                    }, 0);
                                    _b.label = 3;
                                case 3: return [2 /*return*/];
                            }
                        });
                    };
                    _i = 0, buffered_1 = buffered;
                    _b.label = 1;
                case 1:
                    if (!(_i < buffered_1.length)) return [3 /*break*/, 4];
                    _a = buffered_1[_i], operation = _a[0], args = _a.slice(1);
                    return [5 /*yield**/, _loop_1(operation, args)];
                case 2:
                    _b.sent();
                    _b.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4: return [2 /*return*/];
            }
        });
    });
}
/**
 * With AJS classic, we allow users to call setAnonymousId before the library initialization.
 * This is important because some of the destinations will use the anonymousId during the initialization,
 * and if we set anonId afterwards, that wouldn’t impact the destination.
 */
function flushAnonymousUser(analytics) {
    var wa = window.analytics;
    var buffered = 
    // @ts-expect-error
    wa && wa[0] ? (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__spreadArrays)(wa) : [];
    var anon = buffered.find(function (_a) {
        var op = _a[0];
        return op === 'setAnonymousId';
    });
    if (anon) {
        var id = anon[1];
        analytics.setAnonymousId(id);
    }
}
function registerPlugins(legacySettings, analytics, opts, options, plugins) {
    var _a, _b, _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var legacyDestinations, _d, schemaFilter, _e, mergedSettings, remotePlugins, toRegister, shouldIgnoreSegmentio, ctx;
        var _this = this;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_f) {
            switch (_f.label) {
                case 0:
                    if (!hasLegacyDestinations(legacySettings)) return [3 /*break*/, 2];
                    return [4 /*yield*/, Promise.all(/*! import() | ajs-destination */[__webpack_require__.e("vendors-node_modules_segment_tsub_dist_index_js"), __webpack_require__.e("ajs-destination")]).then(__webpack_require__.bind(__webpack_require__, /*! ./plugins/ajs-destination */ 9559)).then(function (mod) {
                            return mod.ajsDestinations(legacySettings, analytics.integrations, opts);
                        })];
                case 1:
                    _d = _f.sent();
                    return [3 /*break*/, 3];
                case 2:
                    _d = [];
                    _f.label = 3;
                case 3:
                    legacyDestinations = _d;
                    if (!legacySettings.legacyVideoPluginsEnabled) return [3 /*break*/, 5];
                    return [4 /*yield*/, __webpack_require__.e(/*! import() | legacyVideos */ "legacyVideos").then(__webpack_require__.bind(__webpack_require__, /*! ./plugins/legacy-video-plugins */ 9404)).then(function (mod) {
                            return mod.loadLegacyVideoPlugins(analytics);
                        })];
                case 4:
                    _f.sent();
                    _f.label = 5;
                case 5:
                    if (!((_a = opts.plan) === null || _a === void 0 ? void 0 : _a.track)) return [3 /*break*/, 7];
                    return [4 /*yield*/, __webpack_require__.e(/*! import() | schemaFilter */ "schemaFilter").then(__webpack_require__.bind(__webpack_require__, /*! ./plugins/schema-filter */ 8497)).then(function (mod) {
                            var _a;
                            return mod.schemaFilter((_a = opts.plan) === null || _a === void 0 ? void 0 : _a.track, legacySettings);
                        })];
                case 6:
                    _e = _f.sent();
                    return [3 /*break*/, 8];
                case 7:
                    _e = undefined;
                    _f.label = 8;
                case 8:
                    schemaFilter = _e;
                    mergedSettings = (0,_lib_merged_options__WEBPACK_IMPORTED_MODULE_2__.mergedOptions)(legacySettings, options);
                    return [4 /*yield*/, (0,_plugins_remote_loader__WEBPACK_IMPORTED_MODULE_3__.remoteLoader)(legacySettings).catch(function () { return []; })];
                case 9:
                    remotePlugins = _f.sent();
                    toRegister = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__spreadArrays)([
                        _plugins_validation__WEBPACK_IMPORTED_MODULE_4__.validation,
                        _plugins_page_enrichment__WEBPACK_IMPORTED_MODULE_5__.pageEnrichment
                    ], plugins, legacyDestinations, remotePlugins);
                    if (schemaFilter) {
                        toRegister.push(schemaFilter);
                    }
                    shouldIgnoreSegmentio = (((_b = opts.integrations) === null || _b === void 0 ? void 0 : _b.All) === false && !opts.integrations['Segment.io']) ||
                        (opts.integrations && opts.integrations['Segment.io'] === false);
                    if (!shouldIgnoreSegmentio) {
                        toRegister.push((0,_plugins_segmentio__WEBPACK_IMPORTED_MODULE_6__.segmentio)(analytics, mergedSettings['Segment.io'], legacySettings.integrations));
                    }
                    return [4 /*yield*/, analytics.register.apply(analytics, toRegister)];
                case 10:
                    ctx = _f.sent();
                    if (!(Object.keys((_c = legacySettings.enabledMiddleware) !== null && _c !== void 0 ? _c : {}).length > 0)) return [3 /*break*/, 12];
                    return [4 /*yield*/, __webpack_require__.e(/*! import() | remoteMiddleware */ "remoteMiddleware").then(__webpack_require__.bind(__webpack_require__, /*! ./plugins/remote-middleware */ 7070)).then(function (_a) {
                            var remoteMiddlewares = _a.remoteMiddlewares;
                            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () {
                                var middleware, promises;
                                return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
                                    switch (_b.label) {
                                        case 0: return [4 /*yield*/, remoteMiddlewares(ctx, legacySettings)];
                                        case 1:
                                            middleware = _b.sent();
                                            promises = middleware.map(function (mdw) {
                                                return analytics.addSourceMiddleware(mdw);
                                            });
                                            return [2 /*return*/, Promise.all(promises)];
                                    }
                                });
                            });
                        })];
                case 11:
                    _f.sent();
                    _f.label = 12;
                case 12: return [2 /*return*/, ctx];
            }
        });
    });
}
var AnalyticsBrowser = /** @class */ (function () {
    function AnalyticsBrowser() {
    }
    AnalyticsBrowser.load = function (settings, options) {
        var _a, _b, _c, _d, _e;
        if (options === void 0) { options = {}; }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            var legacySettings, retryQueue, opts, analytics, plugins, ctx, search, hash, term;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_f) {
                switch (_f.label) {
                    case 0: return [4 /*yield*/, loadLegacySettings(settings.writeKey, settings)];
                    case 1:
                        legacySettings = _f.sent();
                        retryQueue = (_b = (_a = legacySettings.integrations['Segment.io']) === null || _a === void 0 ? void 0 : _a.retryQueue) !== null && _b !== void 0 ? _b : true;
                        opts = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({ retryQueue: retryQueue }, options);
                        analytics = new _analytics__WEBPACK_IMPORTED_MODULE_7__.Analytics(settings, opts);
                        plugins = (_c = settings.plugins) !== null && _c !== void 0 ? _c : [];
                        _core_context__WEBPACK_IMPORTED_MODULE_8__.Context.initMetrics(legacySettings.metrics);
                        // needs to be flushed before plugins are registered
                        flushAnonymousUser(analytics);
                        return [4 /*yield*/, registerPlugins(legacySettings, analytics, opts, options, plugins)];
                    case 2:
                        ctx = _f.sent();
                        analytics.initialized = true;
                        analytics.emit('initialize', settings, options);
                        if (options.initialPageview) {
                            analytics.page().catch(console.error);
                        }
                        search = (_d = window.location.search) !== null && _d !== void 0 ? _d : '';
                        hash = (_e = window.location.hash) !== null && _e !== void 0 ? _e : '';
                        term = search.length ? search : hash.replace(/(?=#).*(?=\?)/, '');
                        if (term.includes('ajs_')) {
                            analytics.queryString(term).catch(console.error);
                        }
                        return [4 /*yield*/, flushBuffered(analytics)];
                    case 3:
                        _f.sent();
                        return [2 /*return*/, [analytics, ctx]];
                }
            });
        });
    };
    AnalyticsBrowser.standalone = function (writeKey, options) {
        return AnalyticsBrowser.load({ writeKey: writeKey }, options).then(function (res) { return res[0]; });
    };
    return AnalyticsBrowser;
}());



/***/ }),

/***/ 4090:
/*!**********************************************!*\
  !*** ./src/core/arguments-resolver/index.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "resolveArguments": function() { return /* binding */ resolveArguments; },
/* harmony export */   "resolvePageArguments": function() { return /* binding */ resolvePageArguments; },
/* harmony export */   "resolveUserArguments": function() { return /* binding */ resolveUserArguments; },
/* harmony export */   "resolveAliasArguments": function() { return /* binding */ resolveAliasArguments; }
/* harmony export */ });
/* harmony import */ var _plugins_validation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../plugins/validation */ 2487);

function resolveArguments(eventName, properties, options, callback) {
    var _a;
    var args = [eventName, properties, options, callback];
    var name = (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(eventName) ? eventName.event : eventName;
    if (!name || !(0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isString)(name)) {
        throw new Error('Event missing');
    }
    var data = (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(eventName)
        ? (_a = eventName.properties) !== null && _a !== void 0 ? _a : {} : (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(properties)
        ? properties
        : {};
    var opts = {};
    if ((0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(properties) && !(0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isFunction)(options)) {
        opts = options !== null && options !== void 0 ? options : {};
    }
    if ((0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(eventName) && !(0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isFunction)(properties)) {
        opts = properties !== null && properties !== void 0 ? properties : {};
    }
    var cb = args.find(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isFunction);
    return [name, data, opts, cb];
}
function resolvePageArguments(category, name, properties, options, callback) {
    var _a, _b;
    var resolvedCategory = null;
    var resolvedName = null;
    var args = [category, name, properties, options, callback];
    var strings = args.filter(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isString);
    if (strings[0] !== undefined && strings[1] !== undefined) {
        resolvedCategory = strings[0];
        resolvedName = strings[1];
    }
    if (strings.length === 1) {
        resolvedCategory = null;
        resolvedName = strings[0];
    }
    var resolvedCallback = args.find(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isFunction);
    var objects = args.filter(function (obj) {
        if (resolvedName === null) {
            return (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(obj);
        }
        return (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(obj) || obj === null;
    });
    var resolvedProperties = (_a = objects[0]) !== null && _a !== void 0 ? _a : {};
    var resolvedOptions = (_b = objects[1]) !== null && _b !== void 0 ? _b : {};
    return [
        resolvedCategory,
        resolvedName,
        resolvedProperties,
        resolvedOptions,
        resolvedCallback,
    ];
}
var resolveUserArguments = function (user) {
    return function () {
        var _a, _b, _c, _d, _e;
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var id = null;
        id = (_c = (_a = args.find(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isString)) !== null && _a !== void 0 ? _a : (_b = args.find(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isNumber)) === null || _b === void 0 ? void 0 : _b.toString()) !== null && _c !== void 0 ? _c : user.id();
        var objects = args.filter(function (obj) {
            if (id === null) {
                return (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(obj);
            }
            return (0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)(obj) || obj === null;
        });
        var data = (_d = objects[0]) !== null && _d !== void 0 ? _d : {};
        var opts = (_e = objects[1]) !== null && _e !== void 0 ? _e : {};
        var resolvedCallback = args.find(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isFunction);
        return [id, data, opts, resolvedCallback];
    };
};
function resolveAliasArguments(to, from, options, callback) {
    if ((0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isNumber)(to))
        to = to.toString(); // Legacy behaviour - allow integers for alias calls
    if ((0,_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isNumber)(from))
        from = from.toString();
    var args = [to, from, options, callback];
    var _a = args.filter(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isString), _b = _a[0], aliasTo = _b === void 0 ? to : _b, _c = _a[1], aliasFrom = _c === void 0 ? null : _c;
    var _d = args.filter(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isPlainObject)[0], opts = _d === void 0 ? {} : _d;
    var resolvedCallback = args.find(_plugins_validation__WEBPACK_IMPORTED_MODULE_0__.isFunction);
    return [aliasTo, aliasFrom, opts, resolvedCallback];
}


/***/ }),

/***/ 5546:
/*!************************************!*\
  !*** ./src/core/callback/index.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pTimeout": function() { return /* binding */ pTimeout; },
/* harmony export */   "invokeCallback": function() { return /* binding */ invokeCallback; }
/* harmony export */ });
/* harmony import */ var _lib_as_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/as-promise */ 5764);

function pTimeout(cb, timeout) {
    return new Promise(function (resolve, reject) {
        var timeoutId = setTimeout(function () {
            reject(Error('Promise timed out'));
        }, timeout);
        cb.then(function (val) {
            clearTimeout(timeoutId);
            return resolve(val);
        }).catch(reject);
    });
}
function invokeCallback(ctx, callback, timeout) {
    if (!callback) {
        return Promise.resolve(ctx);
    }
    var cb = function () {
        try {
            return (0,_lib_as_promise__WEBPACK_IMPORTED_MODULE_0__.asPromise)(callback(ctx));
        }
        catch (err) {
            return Promise.reject(err);
        }
    };
    return pTimeout(cb(), timeout !== null && timeout !== void 0 ? timeout : 1000)
        .catch(function (err) {
        ctx === null || ctx === void 0 ? void 0 : ctx.log('warn', 'Callback Error', { error: err });
        ctx === null || ctx === void 0 ? void 0 : ctx.stats.increment('callback_error');
    })
        .then(function () { return ctx; });
}


/***/ }),

/***/ 8231:
/*!**************************************!*\
  !*** ./src/core/connection/index.ts ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isOnline": function() { return /* binding */ isOnline; },
/* harmony export */   "isOffline": function() { return /* binding */ isOffline; }
/* harmony export */ });
/* harmony import */ var _environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../environment */ 4083);

function isOnline() {
    if ((0,_environment__WEBPACK_IMPORTED_MODULE_0__.isBrowser)()) {
        return window.navigator.onLine;
    }
    return true;
}
function isOffline() {
    return !isOnline();
}


/***/ }),

/***/ 5373:
/*!***********************************!*\
  !*** ./src/core/context/index.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContextCancelation": function() { return /* binding */ ContextCancelation; },
/* harmony export */   "Context": function() { return /* binding */ Context; }
/* harmony export */ });
/* harmony import */ var _lukeed_uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lukeed/uuid */ 9108);
/* harmony import */ var dset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! dset */ 6475);
/* harmony import */ var _logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../logger */ 9934);
/* harmony import */ var _stats__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../stats */ 123);
/* harmony import */ var _stats_remote_metrics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../stats/remote-metrics */ 2088);





var ContextCancelation = /** @class */ (function () {
    function ContextCancelation(options) {
        var _a, _b, _c;
        this.retry = (_a = options.retry) !== null && _a !== void 0 ? _a : true;
        this.type = (_b = options.type) !== null && _b !== void 0 ? _b : 'plugin Error';
        this.reason = (_c = options.reason) !== null && _c !== void 0 ? _c : '';
    }
    return ContextCancelation;
}());

var remoteMetrics;
var Context = /** @class */ (function () {
    function Context(event, id) {
        this.logger = new _logger__WEBPACK_IMPORTED_MODULE_2__["default"]();
        this.cancel = function (error) {
            if (error) {
                throw error;
            }
            throw new ContextCancelation({ reason: 'Context Cancel' });
        };
        this._attempts = 0;
        this._event = event;
        this._id = id !== null && id !== void 0 ? id : (0,_lukeed_uuid__WEBPACK_IMPORTED_MODULE_0__.v4)();
        this.stats = new _stats__WEBPACK_IMPORTED_MODULE_3__["default"](remoteMetrics);
    }
    Context.initMetrics = function (options) {
        remoteMetrics = new _stats_remote_metrics__WEBPACK_IMPORTED_MODULE_4__.RemoteMetrics(options);
    };
    Context.system = function () {
        return new Context({ type: 'track', event: 'system' });
    };
    Context.prototype.isSame = function (other) {
        return other._id === this._id;
    };
    Context.prototype.log = function (level, message, extras) {
        this.logger.log(level, message, extras);
    };
    Object.defineProperty(Context.prototype, "id", {
        get: function () {
            return this._id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Context.prototype, "event", {
        get: function () {
            return this._event;
        },
        set: function (evt) {
            this._event = evt;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Context.prototype, "attempts", {
        get: function () {
            return this._attempts;
        },
        set: function (attempts) {
            this._attempts = attempts;
        },
        enumerable: false,
        configurable: true
    });
    Context.prototype.updateEvent = function (path, val) {
        var _a;
        // Don't allow integrations that are set to false to be overwritten with integration settings.
        if (path.split('.')[0] === 'integrations') {
            var integrationName = path.split('.')[1];
            if (((_a = this._event.integrations) === null || _a === void 0 ? void 0 : _a[integrationName]) === false) {
                return this._event;
            }
        }
        (0,dset__WEBPACK_IMPORTED_MODULE_1__.dset)(this._event, path, val);
        return this._event;
    };
    Context.prototype.logs = function () {
        return this.logger.logs;
    };
    Context.prototype.flush = function () {
        this.logger.flush();
        this.stats.flush();
    };
    Context.prototype.toJSON = function () {
        return {
            id: this._id,
            event: this._event,
            logs: this.logger.logs,
            metrics: this.stats.metrics,
        };
    };
    return Context;
}());



/***/ }),

/***/ 6373:
/*!***********************************!*\
  !*** ./src/core/emitter/index.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Emitter": function() { return /* binding */ Emitter; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

var Emitter = /** @class */ (function () {
    function Emitter() {
        this.callbacks = {};
    }
    Emitter.prototype.on = function (event, callback) {
        var _a;
        this.callbacks[event] = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArrays)(((_a = this.callbacks[event]) !== null && _a !== void 0 ? _a : []), [callback]);
        return this;
    };
    Emitter.prototype.once = function (event, fn) {
        var _this = this;
        var on = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            _this.off(event, on);
            fn.apply(_this, args);
        };
        this.on(event, on);
        return this;
    };
    Emitter.prototype.off = function (event, callback) {
        var _a;
        var fns = (_a = this.callbacks[event]) !== null && _a !== void 0 ? _a : [];
        var without = fns.filter(function (fn) { return fn !== callback; });
        this.callbacks[event] = without;
        return this;
    };
    Emitter.prototype.emit = function (event) {
        var _this = this;
        var _a;
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        var callbacks = (_a = this.callbacks[event]) !== null && _a !== void 0 ? _a : [];
        callbacks.forEach(function (callback) {
            callback.apply(_this, args);
        });
        return this;
    };
    return Emitter;
}());



/***/ }),

/***/ 4083:
/*!***************************************!*\
  !*** ./src/core/environment/index.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isBrowser": function() { return /* binding */ isBrowser; },
/* harmony export */   "isServer": function() { return /* binding */ isServer; }
/* harmony export */ });
function isBrowser() {
    return typeof window !== 'undefined';
}
function isServer() {
    return !isBrowser();
}


/***/ }),

/***/ 7763:
/*!**********************************!*\
  !*** ./src/core/events/index.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventFactory": function() { return /* binding */ EventFactory; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _lukeed_uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lukeed/uuid */ 9108);
/* harmony import */ var dset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! dset */ 6475);
/* harmony import */ var spark_md5__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! spark-md5 */ 8322);
/* harmony import */ var spark_md5__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(spark_md5__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./interfaces */ 7090);
/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_interfaces__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _interfaces__WEBPACK_IMPORTED_MODULE_3__) if(["default","EventFactory"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _interfaces__WEBPACK_IMPORTED_MODULE_3__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);





var EventFactory = /** @class */ (function () {
    function EventFactory(user) {
        this.user = user;
    }
    EventFactory.prototype.track = function (event, properties, options, globalIntegrations) {
        return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, this.baseEvent()), { event: event, type: 'track', properties: properties, options: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, options), integrations: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, globalIntegrations) }));
    };
    EventFactory.prototype.page = function (category, page, properties, options, globalIntegrations) {
        var _a;
        var event = {
            type: 'page',
            properties: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, properties),
            options: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, options),
            integrations: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, globalIntegrations),
        };
        if (category !== null) {
            event.category = category;
            event.properties = (_a = event.properties) !== null && _a !== void 0 ? _a : {};
            event.properties.category = category;
        }
        if (page !== null) {
            event.name = page;
        }
        return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, this.baseEvent()), event));
    };
    EventFactory.prototype.screen = function (category, screen, properties, options, globalIntegrations) {
        var event = {
            type: 'screen',
            properties: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, properties),
            options: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, options),
            integrations: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, globalIntegrations),
        };
        if (category !== null) {
            event.category = category;
        }
        if (screen !== null) {
            event.name = screen;
        }
        return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, this.baseEvent()), event));
    };
    EventFactory.prototype.identify = function (userId, traits, options, globalIntegrations) {
        return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, this.baseEvent()), { type: 'identify', userId: userId,
            traits: traits, options: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, options), integrations: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, globalIntegrations) }));
    };
    EventFactory.prototype.group = function (groupId, traits, options, globalIntegrations) {
        return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, this.baseEvent()), { type: 'group', traits: traits, options: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, options), integrations: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, globalIntegrations), groupId: groupId }));
    };
    EventFactory.prototype.alias = function (to, from, options, globalIntegrations) {
        var base = {
            userId: to,
            type: 'alias',
            options: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, options),
            integrations: (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, globalIntegrations),
        };
        if (from !== null) {
            base.previousId = from;
        }
        if (to === undefined) {
            return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, base), this.baseEvent()));
        }
        return this.normalize((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, this.baseEvent()), base));
    };
    EventFactory.prototype.baseEvent = function () {
        var base = {
            integrations: {},
            options: {},
        };
        if (this.user.id()) {
            base.userId = this.user.id();
        }
        base.anonymousId = this.user.anonymousId();
        return base;
    };
    /**
     * Builds the context part of an event based on "foreign" keys that
     * are provided in the `Options` parameter for an Event
     */
    EventFactory.prototype.context = function (event) {
        var _a, _b, _c;
        var optionsKeys = ['integrations', 'anonymousId', 'timestamp', 'userId'];
        var options = (_a = event.options) !== null && _a !== void 0 ? _a : {};
        delete options['integrations'];
        var providedOptionsKeys = Object.keys(options);
        var context = (_c = (_b = event.options) === null || _b === void 0 ? void 0 : _b.context) !== null && _c !== void 0 ? _c : {};
        var overrides = {};
        providedOptionsKeys.forEach(function (key) {
            if (key === 'context') {
                return;
            }
            if (optionsKeys.includes(key)) {
                (0,dset__WEBPACK_IMPORTED_MODULE_1__.dset)(overrides, key, options[key]);
            }
            else {
                (0,dset__WEBPACK_IMPORTED_MODULE_1__.dset)(context, key, options[key]);
            }
        });
        return [context, overrides];
    };
    EventFactory.prototype.normalize = function (event) {
        var _a, _b;
        var integrationBooleans = Object.keys((_a = event.integrations) !== null && _a !== void 0 ? _a : {}).reduce(function (integrationNames, name) {
            var _a;
            var _b;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, integrationNames), (_a = {}, _a[name] = Boolean((_b = event.integrations) === null || _b === void 0 ? void 0 : _b[name]), _a));
        }, {});
        // This is pretty trippy, but here's what's going on:
        // - a) We don't pass initial integration options as part of the event, only if they're true or false
        // - b) We do accept per integration overrides (like integrations.Amplitude.sessionId) at the event level
        // Hence the need to convert base integration options to booleans, but maintain per event integration overrides
        var allIntegrations = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, integrationBooleans), (_b = event.options) === null || _b === void 0 ? void 0 : _b.integrations);
        var _c = this.context(event), context = _c[0], overrides = _c[1];
        var options = event.options, rest = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__rest)(event, ["options"]);
        var body = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, rest), { context: context, integrations: allIntegrations }), overrides);
        var messageId = 'ajs-next-' + spark_md5__WEBPACK_IMPORTED_MODULE_2___default().hash(JSON.stringify(body) + (0,_lukeed_uuid__WEBPACK_IMPORTED_MODULE_0__.v4)());
        var evt = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, body), { messageId: messageId });
        return evt;
    };
    return EventFactory;
}());



/***/ }),

/***/ 7090:
/*!***************************************!*\
  !*** ./src/core/events/interfaces.ts ***!
  \***************************************/
/***/ (function() {



/***/ }),

/***/ 9934:
/*!**********************************!*\
  !*** ./src/core/logger/index.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

var Logger = /** @class */ (function () {
    function Logger() {
        var _this = this;
        this._logs = [];
        this.log = function (level, message, extras) {
            var time = new Date();
            _this._logs.push({
                level: level,
                message: message,
                time: time,
                extras: extras,
            });
        };
    }
    Object.defineProperty(Logger.prototype, "logs", {
        get: function () {
            return this._logs;
        },
        enumerable: false,
        configurable: true
    });
    Logger.prototype.flush = function () {
        if (this.logs.length > 1) {
            var formatted = this._logs.reduce(function (logs, log) {
                var _a;
                var _b, _c;
                var line = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, log), { json: JSON.stringify(log.extras, null, ' '), extras: log.extras });
                delete line['time'];
                var key = (_c = (_b = log.time) === null || _b === void 0 ? void 0 : _b.toISOString()) !== null && _c !== void 0 ? _c : '';
                if (logs[key]) {
                    key = key + "-" + Math.random();
                }
                return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, logs), (_a = {}, _a[key] = line, _a));
            }, {});
            // ie doesn't like console.table
            if (console.table) {
                console.table(formatted);
            }
            else {
                console.log(formatted);
            }
        }
        else {
            this.logs.forEach(function (logEntry) {
                var level = logEntry.level, message = logEntry.message, extras = logEntry.extras;
                if (level === 'info' || level === 'debug') {
                    console.log(message, extras !== null && extras !== void 0 ? extras : '');
                }
                else {
                    console[level](message, extras !== null && extras !== void 0 ? extras : '');
                }
            });
        }
        this._logs = [];
    };
    return Logger;
}());
/* harmony default export */ __webpack_exports__["default"] = (Logger);


/***/ }),

/***/ 57:
/*!************************************!*\
  !*** ./src/core/queue/delivery.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "attempt": function() { return /* binding */ attempt; },
/* harmony export */   "ensure": function() { return /* binding */ ensure; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../context */ 5373);


function tryOperation(op) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
        var err_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, op()];
                case 1: return [2 /*return*/, _a.sent()];
                case 2:
                    err_1 = _a.sent();
                    return [2 /*return*/, Promise.reject(err_1)];
                case 3: return [2 /*return*/];
            }
        });
    });
}
function attempt(ctx, plugin) {
    ctx.log('debug', 'plugin', { plugin: plugin.name });
    var start = new Date().getTime();
    var hook = plugin[ctx.event.type];
    if (hook === undefined) {
        return Promise.resolve(ctx);
    }
    var newCtx = tryOperation(function () { return hook.apply(plugin, [ctx]); })
        .then(function (ctx) {
        var done = new Date().getTime() - start;
        ctx.stats.gauge('plugin_time', done, ["plugin:" + plugin.name]);
        return ctx;
    })
        .catch(function (err) {
        if (err instanceof _context__WEBPACK_IMPORTED_MODULE_1__.ContextCancelation &&
            err.type === 'middleware_cancellation') {
            throw err;
        }
        if (err instanceof _context__WEBPACK_IMPORTED_MODULE_1__.ContextCancelation) {
            ctx.log('warn', err.type, {
                plugin: plugin.name,
                error: err,
            });
            return;
        }
        ctx.log('error', 'plugin Error', {
            plugin: plugin.name,
            error: err,
        });
        ctx.stats.increment('plugin_error', 1, ["plugin:" + plugin.name]);
        return err;
    });
    return newCtx;
}
function ensure(ctx, plugin) {
    return attempt(ctx, plugin).then(function (newContext) {
        if (newContext === undefined || newContext instanceof Error) {
            ctx.log('debug', 'Context canceled');
            ctx.stats.increment('context_canceled');
            ctx.cancel(newContext);
            return undefined;
        }
        return newContext;
    });
}


/***/ }),

/***/ 9054:
/*!***************************************!*\
  !*** ./src/core/queue/event-queue.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventQueue": function() { return /* binding */ EventQueue; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _lib_group_by__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/group-by */ 9137);
/* harmony import */ var _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/priority-queue/persisted */ 1778);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../connection */ 8231);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../context */ 5373);
/* harmony import */ var _emitter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../emitter */ 6373);
/* harmony import */ var _delivery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./delivery */ 57);







var EventQueue = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(EventQueue, _super);
    function EventQueue(priorityQueue) {
        var _this = _super.call(this) || this;
        _this.plugins = [];
        _this.failedInitializations = [];
        _this.flushing = false;
        _this.queue = priorityQueue !== null && priorityQueue !== void 0 ? priorityQueue : new _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_1__.PersistedPriorityQueue(4, 'event-queue');
        _this.scheduleFlush();
        return _this;
    }
    EventQueue.prototype.register = function (ctx, plugin, instance) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Promise.resolve(plugin.load(ctx, instance))
                            .then(function () {
                            _this.plugins.push(plugin);
                        })
                            .catch(function (err) {
                            if (plugin.type === 'destination') {
                                _this.failedInitializations.push(plugin.name);
                                console.warn(plugin.name, err);
                                ctx.log('warn', 'Failed to load destination', {
                                    plugin: plugin.name,
                                    error: err,
                                });
                                return;
                            }
                            throw err;
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EventQueue.prototype.deregister = function (ctx, plugin, instance) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var e_1;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        if (!plugin.unload) return [3 /*break*/, 2];
                        return [4 /*yield*/, Promise.resolve(plugin.unload(ctx, instance))];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        this.plugins = this.plugins.filter(function (p) { return p.name !== plugin.name; });
                        return [3 /*break*/, 4];
                    case 3:
                        e_1 = _a.sent();
                        ctx.log('warn', 'Failed to unload destination', {
                            plugin: plugin.name,
                            error: e_1,
                        });
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    EventQueue.prototype.dispatch = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var willDeliver;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                ctx.log('debug', 'Dispatching');
                ctx.stats.increment('message_dispatched');
                this.queue.push(ctx);
                willDeliver = this.subscribeToDelivery(ctx);
                this.scheduleFlush(0);
                return [2 /*return*/, willDeliver];
            });
        });
    };
    EventQueue.prototype.subscribeToDelivery = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        var onDeliver = function (flushed, delivered) {
                            if (flushed.isSame(ctx)) {
                                _this.off('flush', onDeliver);
                                if (delivered) {
                                    resolve(flushed);
                                }
                                else {
                                    reject(flushed);
                                }
                            }
                        };
                        _this.on('flush', onDeliver);
                    })];
            });
        });
    };
    EventQueue.prototype.dispatchSingle = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                ctx.log('debug', 'Dispatching');
                ctx.stats.increment('message_dispatched');
                this.queue.updateAttempts(ctx);
                ctx.attempts = 1;
                return [2 /*return*/, this.deliver(ctx).catch(function (err) {
                        if (err instanceof _context__WEBPACK_IMPORTED_MODULE_2__.ContextCancelation && err.retry === false) {
                            return ctx;
                        }
                        var accepted = _this.enqueuRetry(err, ctx);
                        if (!accepted) {
                            throw err;
                        }
                        return _this.subscribeToDelivery(ctx);
                    })];
            });
        });
    };
    EventQueue.prototype.isEmpty = function () {
        return this.queue.length === 0;
    };
    EventQueue.prototype.scheduleFlush = function (timeout) {
        var _this = this;
        if (timeout === void 0) { timeout = 500; }
        if (this.flushing) {
            return;
        }
        this.flushing = true;
        setTimeout(function () {
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            _this.flush().then(function () {
                setTimeout(function () {
                    _this.flushing = false;
                    if (_this.queue.length) {
                        _this.scheduleFlush(0);
                    }
                    else {
                        _this.scheduleFlush(500);
                    }
                }, 0);
            });
        }, timeout);
    };
    EventQueue.prototype.deliver = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var start, done, err_1;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        start = Date.now();
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.flushOne(ctx)];
                    case 2:
                        ctx = _a.sent();
                        done = Date.now() - start;
                        ctx.stats.gauge('delivered', done);
                        ctx.log('debug', 'Delivered', ctx.event);
                        return [2 /*return*/, ctx];
                    case 3:
                        err_1 = _a.sent();
                        ctx.log('error', 'Failed to deliver', err_1);
                        ctx.stats.increment('delivery_failed');
                        throw err_1;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    EventQueue.prototype.enqueuRetry = function (err, ctx) {
        var notRetriable = err instanceof _context__WEBPACK_IMPORTED_MODULE_2__.ContextCancelation && err.retry === false;
        var retriable = !notRetriable;
        if (retriable) {
            var accepted = this.queue.pushWithBackoff(ctx);
            return accepted;
        }
        return false;
    };
    EventQueue.prototype.flush = function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var ctx, err_2, accepted;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.queue.length === 0 || !(0,_connection__WEBPACK_IMPORTED_MODULE_3__.isOnline)()) {
                            return [2 /*return*/, []];
                        }
                        ctx = this.queue.pop();
                        if (!ctx) {
                            return [2 /*return*/, []];
                        }
                        ctx.attempts = this.queue.getAttempts(ctx);
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.deliver(ctx)];
                    case 2:
                        ctx = _a.sent();
                        this.emit('flush', ctx, true);
                        return [3 /*break*/, 4];
                    case 3:
                        err_2 = _a.sent();
                        accepted = this.enqueuRetry(err_2, ctx);
                        if (!accepted) {
                            this.emit('flush', ctx, false);
                        }
                        return [2 /*return*/, []];
                    case 4: return [2 /*return*/, [ctx]];
                }
            });
        });
    };
    EventQueue.prototype.isReady = function () {
        // return this.plugins.every((p) => p.isLoaded())
        // should we wait for every plugin to load?
        return true;
    };
    EventQueue.prototype.availableExtensions = function (denyList) {
        var available = denyList.All === false
            ? this.plugins.filter(function (p) { return denyList[p.name] !== undefined || p.type !== 'destination'; })
            : // !== false includes plugins not present on the denyList
                this.plugins.filter(function (p) { return denyList[p.name] !== false; });
        var _a = (0,_lib_group_by__WEBPACK_IMPORTED_MODULE_4__.groupBy)(available, 'type'), _b = _a.before, before = _b === void 0 ? [] : _b, _c = _a.enrichment, enrichment = _c === void 0 ? [] : _c, _d = _a.destination, destination = _d === void 0 ? [] : _d, _e = _a.after, after = _e === void 0 ? [] : _e;
        return {
            before: before,
            enrichment: enrichment,
            destinations: destination,
            after: after,
        };
    };
    EventQueue.prototype.flushOne = function (ctx) {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var _c, before, enrichment, _i, before_1, beforeWare, temp, _d, enrichment_1, enrichmentWare, temp, _e, destinations, after, afterCalls;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_f) {
                switch (_f.label) {
                    case 0:
                        if (!this.isReady()) {
                            throw new Error('Not ready');
                        }
                        _c = this.availableExtensions((_a = ctx.event.integrations) !== null && _a !== void 0 ? _a : {}), before = _c.before, enrichment = _c.enrichment;
                        _i = 0, before_1 = before;
                        _f.label = 1;
                    case 1:
                        if (!(_i < before_1.length)) return [3 /*break*/, 4];
                        beforeWare = before_1[_i];
                        return [4 /*yield*/, (0,_delivery__WEBPACK_IMPORTED_MODULE_5__.ensure)(ctx, beforeWare)];
                    case 2:
                        temp = _f.sent();
                        if (temp !== undefined) {
                            ctx = temp;
                        }
                        _f.label = 3;
                    case 3:
                        _i++;
                        return [3 /*break*/, 1];
                    case 4:
                        _d = 0, enrichment_1 = enrichment;
                        _f.label = 5;
                    case 5:
                        if (!(_d < enrichment_1.length)) return [3 /*break*/, 8];
                        enrichmentWare = enrichment_1[_d];
                        return [4 /*yield*/, (0,_delivery__WEBPACK_IMPORTED_MODULE_5__.attempt)(ctx, enrichmentWare)];
                    case 6:
                        temp = _f.sent();
                        if (temp instanceof _context__WEBPACK_IMPORTED_MODULE_2__.Context) {
                            ctx = temp;
                        }
                        _f.label = 7;
                    case 7:
                        _d++;
                        return [3 /*break*/, 5];
                    case 8:
                        _e = this.availableExtensions((_b = ctx.event.integrations) !== null && _b !== void 0 ? _b : {}), destinations = _e.destinations, after = _e.after;
                        return [4 /*yield*/, new Promise(function (resolve, reject) {
                                setTimeout(function () {
                                    var attempts = destinations.map(function (destination) {
                                        return (0,_delivery__WEBPACK_IMPORTED_MODULE_5__.attempt)(ctx, destination);
                                    });
                                    Promise.all(attempts).then(resolve).catch(reject);
                                }, 0);
                            })];
                    case 9:
                        _f.sent();
                        ctx.stats.increment('message_delivered');
                        afterCalls = after.map(function (after) { return (0,_delivery__WEBPACK_IMPORTED_MODULE_5__.attempt)(ctx, after); });
                        return [4 /*yield*/, Promise.all(afterCalls)];
                    case 10:
                        _f.sent();
                        return [2 /*return*/, ctx];
                }
            });
        });
    };
    return EventQueue;
}(_emitter__WEBPACK_IMPORTED_MODULE_6__.Emitter));



/***/ }),

/***/ 123:
/*!*********************************!*\
  !*** ./src/core/stats/index.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

var compactMetricType = function (type) {
    var enums = {
        gauge: 'g',
        counter: 'c',
    };
    return enums[type];
};
var Stats = /** @class */ (function () {
    function Stats(remoteMetrics) {
        this.metrics = [];
        this.remoteMetrics = remoteMetrics;
    }
    Stats.prototype.increment = function (metric, by, tags) {
        var _a;
        if (by === void 0) { by = 1; }
        this.metrics.push({
            metric: metric,
            value: by,
            tags: tags !== null && tags !== void 0 ? tags : [],
            type: 'counter',
            timestamp: Date.now(),
        });
        (_a = this.remoteMetrics) === null || _a === void 0 ? void 0 : _a.increment(metric, tags !== null && tags !== void 0 ? tags : []);
    };
    Stats.prototype.gauge = function (metric, value, tags) {
        this.metrics.push({
            metric: metric,
            value: value,
            tags: tags !== null && tags !== void 0 ? tags : [],
            type: 'gauge',
            timestamp: Date.now(),
        });
    };
    Stats.prototype.flush = function () {
        var formatted = this.metrics.map(function (m) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, m), { tags: m.tags.join(',') })); });
        // ie doesn't like console.table
        if (console.table) {
            console.table(formatted);
        }
        else {
            console.log(formatted);
        }
        this.metrics = [];
    };
    /**
     * compact keys for smaller payload
     */
    Stats.prototype.serialize = function () {
        return this.metrics.map(function (m) {
            return {
                m: m.metric,
                v: m.value,
                t: m.tags,
                k: compactMetricType(m.type),
                e: m.timestamp,
            };
        });
    };
    return Stats;
}());
/* harmony default export */ __webpack_exports__["default"] = (Stats);


/***/ }),

/***/ 2088:
/*!******************************************!*\
  !*** ./src/core/stats/remote-metrics.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RemoteMetrics": function() { return /* binding */ RemoteMetrics; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! unfetch */ 5869);
/* harmony import */ var _generated_version__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../generated/version */ 1594);
/* harmony import */ var _plugins_segmentio_normalize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../plugins/segmentio/normalize */ 9841);




var RemoteMetrics = /** @class */ (function () {
    function RemoteMetrics(options) {
        var _this = this;
        var _a, _b, _c, _d;
        // This works only in the browser.
        this.host = (_a = options === null || options === void 0 ? void 0 : options.host) !== null && _a !== void 0 ? _a : 'api.june.so/sdk';
        this.sampleRate = (_b = options === null || options === void 0 ? void 0 : options.sampleRate) !== null && _b !== void 0 ? _b : 1;
        this.flushTimer = (_c = options === null || options === void 0 ? void 0 : options.flushTimer) !== null && _c !== void 0 ? _c : 30 * 1000; /* 30s */
        this.maxQueueSize = (_d = options === null || options === void 0 ? void 0 : options.maxQueueSize) !== null && _d !== void 0 ? _d : 20;
        this.queue = [];
        if (this.sampleRate > 0) {
            var flushing_1 = false;
            var run_1 = function () {
                if (flushing_1) {
                    return;
                }
                flushing_1 = true;
                _this.flush().catch(function (err) {
                    console.error(err);
                });
                flushing_1 = false;
                setTimeout(run_1, _this.flushTimer);
            };
            run_1();
        }
    }
    RemoteMetrics.prototype.increment = function (metric, tags) {
        // All metrics are part of an allow list in Tracking API
        if (!metric.includes('analytics_js.')) {
            return;
        }
        // /m doesn't like empty tags
        if (tags.length === 0) {
            return;
        }
        if (Math.random() > this.sampleRate) {
            return;
        }
        if (this.queue.length >= this.maxQueueSize) {
            return;
        }
        var formatted = tags.reduce(function (acc, t) {
            var _a = t.split(':'), k = _a[0], v = _a[1];
            acc[k] = v;
            return acc;
        }, {});
        formatted['library'] = 'analytics.js';
        var type = (0,_plugins_segmentio_normalize__WEBPACK_IMPORTED_MODULE_1__.getVersionType)();
        if (type === 'web') {
            formatted['library_version'] = "next-" + _generated_version__WEBPACK_IMPORTED_MODULE_2__.version;
        }
        else {
            formatted['library_version'] = "npm:next-" + _generated_version__WEBPACK_IMPORTED_MODULE_2__.version;
        }
        this.queue.push({
            type: 'Counter',
            metric: metric,
            value: 1,
            tags: formatted,
        });
        if (metric.includes('error')) {
            this.flush().catch(function (err) { return console.error(err); });
        }
    };
    RemoteMetrics.prototype.flush = function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, Promise, function () {
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.queue.length <= 0) {
                            return [2 /*return*/];
                        }
                        return [4 /*yield*/, this.send().catch(function (error) {
                                console.error(error);
                                _this.sampleRate = 0;
                            })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    RemoteMetrics.prototype.send = function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, Promise, function () {
            var payload, headers, url;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
                payload = { series: this.queue };
                this.queue = [];
                headers = { 'Content-Type': 'application/json' };
                url = "https://" + this.host + "/m";
                // @ts-ignore
                return [2 /*return*/, (0,unfetch__WEBPACK_IMPORTED_MODULE_0__["default"])(url, {
                        headers: headers,
                        body: JSON.stringify(payload),
                        method: 'POST',
                    })];
            });
        });
    };
    return RemoteMetrics;
}());



/***/ }),

/***/ 8617:
/*!********************************!*\
  !*** ./src/core/user/index.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Cookie": function() { return /* binding */ Cookie; },
/* harmony export */   "LocalStorage": function() { return /* binding */ LocalStorage; },
/* harmony export */   "User": function() { return /* binding */ User; },
/* harmony export */   "Group": function() { return /* binding */ Group; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _lukeed_uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lukeed/uuid */ 9108);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ 6808);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tld__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tld */ 928);
/* harmony import */ var _lib_bind_all__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/bind-all */ 9348);





var defaults = {
    persist: true,
    cookie: {
        key: 'ajs_user_id',
        oldKey: 'ajs_user',
    },
    localStorage: {
        key: 'ajs_user_traits',
    },
};
var Store = /** @class */ (function () {
    function Store() {
        this.cache = {};
    }
    Store.prototype.get = function (key) {
        return this.cache[key];
    };
    Store.prototype.set = function (key, value) {
        this.cache[key] = value;
        return value;
    };
    Store.prototype.remove = function (key) {
        delete this.cache[key];
    };
    return Store;
}());
var domain = undefined;
try {
    domain = (0,_tld__WEBPACK_IMPORTED_MODULE_2__.tld)(new URL(window.location.href));
}
catch (_) {
    domain = undefined;
}
var ONE_YEAR = 365;
var Cookie = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__extends)(Cookie, _super);
    function Cookie(options) {
        if (options === void 0) { options = Cookie.defaults; }
        var _this = _super.call(this) || this;
        _this.options = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({}, Cookie.defaults), options);
        return _this;
    }
    Cookie.available = function () {
        var cookieEnabled = window.navigator.cookieEnabled;
        if (!cookieEnabled) {
            js_cookie__WEBPACK_IMPORTED_MODULE_1___default().set('ajs:cookies', 'test');
            cookieEnabled = document.cookie.includes('ajs:cookies');
            js_cookie__WEBPACK_IMPORTED_MODULE_1___default().remove('ajs:cookies');
        }
        return cookieEnabled;
    };
    Cookie.prototype.opts = function () {
        return {
            sameSite: this.options.sameSite,
            expires: this.options.maxage,
            domain: this.options.domain,
            path: this.options.path,
        };
    };
    Cookie.prototype.get = function (key) {
        return js_cookie__WEBPACK_IMPORTED_MODULE_1___default().getJSON(key);
    };
    Cookie.prototype.set = function (key, value) {
        if (typeof value === 'string') {
            js_cookie__WEBPACK_IMPORTED_MODULE_1___default().set(key, value, this.opts());
        }
        else if (value === null) {
            js_cookie__WEBPACK_IMPORTED_MODULE_1___default().remove(key, this.opts());
        }
        else {
            js_cookie__WEBPACK_IMPORTED_MODULE_1___default().set(key, JSON.stringify(value), this.opts());
        }
        return value;
    };
    Cookie.prototype.remove = function (key) {
        return js_cookie__WEBPACK_IMPORTED_MODULE_1___default().remove(key, this.opts());
    };
    Cookie.defaults = {
        maxage: ONE_YEAR,
        domain: domain,
        path: '/',
        sameSite: 'Lax',
    };
    return Cookie;
}(Store));

var NullStorage = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__extends)(NullStorage, _super);
    function NullStorage() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.get = function (_key) { return null; };
        _this.set = function (_key, _val) { return null; };
        _this.remove = function (_key) { };
        return _this;
    }
    return NullStorage;
}(Store));
var LocalStorage = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__extends)(LocalStorage, _super);
    function LocalStorage() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LocalStorage.available = function () {
        var test = 'test';
        try {
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        }
        catch (e) {
            return false;
        }
    };
    LocalStorage.prototype.get = function (key) {
        var val = localStorage.getItem(key);
        if (val) {
            try {
                return JSON.parse(val);
            }
            catch (e) {
                return JSON.parse(JSON.stringify(val));
            }
        }
        return null;
    };
    LocalStorage.prototype.set = function (key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        }
        catch (_a) {
            console.warn("Unable to set " + key + " in localStorage, storage may be full.");
        }
        return value;
    };
    LocalStorage.prototype.remove = function (key) {
        return localStorage.removeItem(key);
    };
    return LocalStorage;
}(Store));

var User = /** @class */ (function () {
    function User(options, cookieOptions) {
        var _this = this;
        if (options === void 0) { options = defaults; }
        var _a, _b, _c, _d;
        this.mem = new Store();
        this.options = {};
        this.id = function (id) {
            var _a, _b;
            var prevId = _this.chainGet(_this.idKey);
            if (id !== undefined) {
                _this.trySet(_this.idKey, id);
                var changingIdentity = id !== prevId && prevId !== null && id !== null;
                if (changingIdentity) {
                    _this.anonymousId(null);
                }
            }
            return ((_b = (_a = _this.chainGet(_this.idKey)) !== null && _a !== void 0 ? _a : _this.cookies.get(defaults.cookie.oldKey)) !== null && _b !== void 0 ? _b : null);
        };
        this.anonymousId = function (id) {
            var _a, _b;
            if (id === undefined) {
                var val = (_a = _this.chainGet(_this.anonKey)) !== null && _a !== void 0 ? _a : (_b = _this.legacySIO()) === null || _b === void 0 ? void 0 : _b[0];
                if (val) {
                    return val;
                }
            }
            if (id === null) {
                _this.trySet(_this.anonKey, null);
                return _this.chainGet(_this.anonKey);
            }
            _this.trySet(_this.anonKey, id !== null && id !== void 0 ? id : (0,_lukeed_uuid__WEBPACK_IMPORTED_MODULE_0__.v4)());
            return _this.chainGet(_this.anonKey);
        };
        this.traits = function (traits) {
            var _a, _b;
            if (traits === null) {
                traits = {};
            }
            if (traits) {
                _this.mem.set(_this.traitsKey, traits !== null && traits !== void 0 ? traits : {});
                _this.localStorage.set(_this.traitsKey, traits !== null && traits !== void 0 ? traits : {});
            }
            return ((_b = (_a = _this.localStorage.get(_this.traitsKey)) !== null && _a !== void 0 ? _a : _this.mem.get(_this.traitsKey)) !== null && _b !== void 0 ? _b : {});
        };
        this.options = options;
        this.cookieOptions = cookieOptions;
        this.idKey = (_b = (_a = options.cookie) === null || _a === void 0 ? void 0 : _a.key) !== null && _b !== void 0 ? _b : defaults.cookie.key;
        this.traitsKey = (_d = (_c = options.localStorage) === null || _c === void 0 ? void 0 : _c.key) !== null && _d !== void 0 ? _d : defaults.localStorage.key;
        this.anonKey = 'ajs_anonymous_id';
        var shouldPersist = options.persist !== false;
        this.localStorage =
            options.localStorageFallbackDisabled ||
                !shouldPersist ||
                !LocalStorage.available()
                ? new NullStorage()
                : new LocalStorage();
        this.cookies =
            shouldPersist && Cookie.available()
                ? new Cookie(cookieOptions)
                : new NullStorage();
        var legacyUser = this.cookies.get(defaults.cookie.oldKey);
        if (legacyUser) {
            legacyUser.id && this.id(legacyUser.id);
            legacyUser.traits && this.traits(legacyUser.traits);
        }
        (0,_lib_bind_all__WEBPACK_IMPORTED_MODULE_4__["default"])(this);
    }
    User.prototype.chainGet = function (key) {
        var _a, _b, _c;
        var val = (_c = (_b = (_a = this.localStorage.get(key)) !== null && _a !== void 0 ? _a : this.cookies.get(key)) !== null && _b !== void 0 ? _b : this.mem.get(key)) !== null && _c !== void 0 ? _c : null;
        return this.trySet(key, typeof val === 'number' ? val.toString() : val);
    };
    User.prototype.trySet = function (key, value) {
        this.localStorage.set(key, value);
        this.cookies.set(key, value);
        this.mem.set(key, value);
        return value;
    };
    User.prototype.chainClear = function (key) {
        this.localStorage.remove(key);
        this.cookies.remove(key);
        this.mem.remove(key);
    };
    User.prototype.legacySIO = function () {
        var val = this.cookies.get('_sio');
        if (!val) {
            return null;
        }
        var _a = val.split('----'), anon = _a[0], user = _a[1];
        return [anon, user];
    };
    User.prototype.identify = function (id, traits) {
        traits = traits !== null && traits !== void 0 ? traits : {};
        var currentId = this.id();
        if (currentId === null || currentId === id) {
            traits = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({}, this.traits()), traits);
        }
        if (id) {
            this.id(id);
        }
        this.traits(traits);
    };
    User.prototype.logout = function () {
        this.anonymousId(null);
        this.id(null);
        this.traits({});
    };
    User.prototype.reset = function () {
        this.logout();
        this.chainClear(this.idKey);
        this.chainClear(this.anonKey);
        this.chainClear(this.traitsKey);
    };
    User.prototype.load = function () {
        return new User(this.options, this.cookieOptions);
    };
    User.prototype.save = function () {
        return true;
    };
    User.defaults = defaults;
    return User;
}());

var groupDefaults = {
    persist: true,
    cookie: {
        key: 'ajs_group_id',
    },
    localStorage: {
        key: 'ajs_group_properties',
    },
};
var Group = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__extends)(Group, _super);
    function Group(options, cookie) {
        if (options === void 0) { options = groupDefaults; }
        var _this = _super.call(this, options, cookie) || this;
        _this.anonymousId = function (_id) {
            return undefined;
        };
        (0,_lib_bind_all__WEBPACK_IMPORTED_MODULE_4__["default"])(_this);
        return _this;
    }
    return Group;
}(User));



/***/ }),

/***/ 928:
/*!******************************!*\
  !*** ./src/core/user/tld.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tld": function() { return /* binding */ tld; }
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! js-cookie */ 6808);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Levels returns all levels of the given url.
 *
 * @param {string} url
 * @return {Array}
 * @api public
 */
function levels(url) {
    var host = url.hostname;
    var parts = host.split('.');
    var last = parts[parts.length - 1];
    var levels = [];
    // Ip address.
    if (parts.length === 4 && parseInt(last, 10) > 0) {
        return levels;
    }
    // Localhost.
    if (parts.length <= 1) {
        return levels;
    }
    // Create levels.
    for (var i = parts.length - 2; i >= 0; --i) {
        levels.push(parts.slice(i).join('.'));
    }
    return levels;
}
function tld(url) {
    var lvls = levels(url);
    // Lookup the real top level one.
    for (var i = 0; i < lvls.length; ++i) {
        var cname = '__tld__';
        var domain = lvls[i];
        var opts = { domain: '.' + domain };
        js_cookie__WEBPACK_IMPORTED_MODULE_0___default().set(cname, '1', opts);
        if (js_cookie__WEBPACK_IMPORTED_MODULE_0___default().get(cname)) {
            js_cookie__WEBPACK_IMPORTED_MODULE_0___default().remove(cname, opts);
            return domain;
        }
    }
}


/***/ }),

/***/ 1594:
/*!**********************************!*\
  !*** ./src/generated/version.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "version": function() { return /* binding */ version; }
/* harmony export */ });
// This file is generated.
var version = '1.36.5';


/***/ }),

/***/ 5764:
/*!*******************************!*\
  !*** ./src/lib/as-promise.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "asPromise": function() { return /* binding */ asPromise; }
/* harmony export */ });
/**
 * Wraps an arbitrary value in a Promise so that it can be awaited on
 */
function asPromise(value) {
    return Promise.resolve(value);
}


/***/ }),

/***/ 9348:
/*!*****************************!*\
  !*** ./src/lib/bind-all.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ bindAll; }
/* harmony export */ });
/* eslint-disable @typescript-eslint/no-explicit-any */
function bindAll(obj) {
    var proto = obj.constructor.prototype;
    for (var _i = 0, _a = Object.getOwnPropertyNames(proto); _i < _a.length; _i++) {
        var key = _a[_i];
        if (key !== 'constructor') {
            var desc = Object.getOwnPropertyDescriptor(obj.constructor.prototype, key);
            if (!!desc && typeof desc.value === 'function') {
                obj[key] = obj[key].bind(obj);
            }
        }
    }
    return obj;
}
/* eslint-enable @typescript-eslint/no-explicit-any */


/***/ }),

/***/ 1333:
/*!***************************************!*\
  !*** ./src/lib/embedded-write-key.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "embeddedWriteKey": function() { return /* binding */ embeddedWriteKey; }
/* harmony export */ });
// This variable is used as an optional fallback for when customers
// host or proxy their own analytics.js.
try {
    window.analyticsWriteKey = '__WRITE_KEY__';
}
catch (_) {
    // @ eslint-disable-next-line
}
function embeddedWriteKey() {
    if (window.analyticsWriteKey === undefined) {
        return undefined;
    }
    // this is done so that we don't accidentally override every reference to __write_key__
    return window.analyticsWriteKey !== ['__', 'WRITE', '_', 'KEY', '__'].join('')
        ? window.analyticsWriteKey
        : undefined;
}


/***/ }),

/***/ 9562:
/*!************************************!*\
  !*** ./src/lib/get-process-env.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getProcessEnv": function() { return /* binding */ getProcessEnv; }
/* harmony export */ });
/**
 * Returns `process.env` if it is available in the environment.
 * Always returns an object make it similarly easy to use as `process.env`.
 */
function getProcessEnv() {
    if (typeof process === 'undefined' || !process.env) {
        return {};
    }
    return process.env;
}


/***/ }),

/***/ 9137:
/*!*****************************!*\
  !*** ./src/lib/group-by.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "groupBy": function() { return /* binding */ groupBy; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

function groupBy(collection, grouper) {
    var results = {};
    collection.forEach(function (item) {
        var _a;
        var key = undefined;
        if (typeof grouper === 'string') {
            var suggestedKey = item[grouper];
            key =
                typeof suggestedKey !== 'string'
                    ? JSON.stringify(suggestedKey)
                    : suggestedKey;
        }
        else if (grouper instanceof Function) {
            key = grouper(item);
        }
        if (key === undefined) {
            return;
        }
        results[key] = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArrays)(((_a = results[key]) !== null && _a !== void 0 ? _a : []), [item]);
    });
    return results;
}


/***/ }),

/***/ 6673:
/*!********************************!*\
  !*** ./src/lib/load-script.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadScript": function() { return /* binding */ loadScript; },
/* harmony export */   "unloadScript": function() { return /* binding */ unloadScript; }
/* harmony export */ });
function findScript(src) {
    var scripts = Array.prototype.slice.call(window.document.querySelectorAll('script'));
    return scripts.find(function (s) { return s.src === src; });
}
function loadScript(src, attributes) {
    var found = findScript(src);
    if (found !== undefined) {
        var status = found === null || found === void 0 ? void 0 : found.getAttribute('status');
        if (status === 'loaded') {
            return Promise.resolve(found);
        }
        if (status === 'loading') {
            return new Promise(function (resolve, reject) {
                found.addEventListener('load', function () { return resolve(found); });
                found.addEventListener('error', function (err) { return reject(err); });
            });
        }
    }
    return new Promise(function (resolve, reject) {
        var _a;
        var script = __webpack_require__.g.window.document.createElement('script');
        script.type = 'text/javascript';
        script.src = src;
        script.async = true;
        script.setAttribute('status', 'loading');
        for (var _i = 0, _b = Object.entries(attributes !== null && attributes !== void 0 ? attributes : {}); _i < _b.length; _i++) {
            var _c = _b[_i], k = _c[0], v = _c[1];
            script.setAttribute(k, v);
        }
        script.onload = function () {
            script.onerror = script.onload = null;
            script.setAttribute('status', 'loaded');
            resolve(script);
        };
        script.onerror = function () {
            script.onerror = script.onload = null;
            script.setAttribute('status', 'error');
            reject(new Error("Failed to load " + src));
        };
        var tag = __webpack_require__.g.window.document.getElementsByTagName('script')[0];
        (_a = tag.parentElement) === null || _a === void 0 ? void 0 : _a.insertBefore(script, tag);
    });
}
function unloadScript(src) {
    var found = findScript(src);
    if (found !== undefined) {
        found.remove();
    }
    return Promise.resolve();
}


/***/ }),

/***/ 7851:
/*!***********************************!*\
  !*** ./src/lib/merged-options.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mergedOptions": function() { return /* binding */ mergedOptions; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

/**
 * Merge legacy settings and initialized Integration option overrides.
 *
 * This will merge any options that were passed from initialization into
 * overrides for settings that are returned by the Segment CDN.
 *
 * i.e. this allows for passing options directly into destinations from
 * the Analytics constructor.
 */
function mergedOptions(settings, options) {
    var _a;
    var optionOverrides = Object.entries((_a = options.integrations) !== null && _a !== void 0 ? _a : {}).reduce(function (overrides, _a) {
        var _b, _c;
        var integration = _a[0], options = _a[1];
        if (typeof options === 'object') {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, overrides), (_b = {}, _b[integration] = options, _b));
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, overrides), (_c = {}, _c[integration] = {}, _c));
    }, {});
    return Object.entries(settings.integrations).reduce(function (integrationSettings, _a) {
        var _b;
        var integration = _a[0], settings = _a[1];
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, integrationSettings), (_b = {}, _b[integration] = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, settings), optionOverrides[integration]), _b));
    }, {});
}


/***/ }),

/***/ 3319:
/*!****************************!*\
  !*** ./src/lib/p-while.ts ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pWhile": function() { return /* binding */ pWhile; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

var pWhile = function (condition, action) { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(void 0, void 0, Promise, function () {
    var loop;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
        loop = function (actionResult) { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(void 0, void 0, Promise, function () {
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!condition(actionResult)) return [3 /*break*/, 2];
                        _a = loop;
                        return [4 /*yield*/, action()];
                    case 1: return [2 /*return*/, _a.apply(void 0, [_b.sent()])];
                    case 2: return [2 /*return*/];
                }
            });
        }); };
        return [2 /*return*/, loop(undefined)];
    });
}); };


/***/ }),

/***/ 46:
/*!******************************!*\
  !*** ./src/lib/parse-cdn.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getCDN": function() { return /* binding */ getCDN; },
/* harmony export */   "getLegacyAJSPath": function() { return /* binding */ getLegacyAJSPath; }
/* harmony export */ });
/* harmony import */ var _embedded_write_key__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./embedded-write-key */ 1333);

var regex = /(https:\/\/.*)\/analytics\.js\/v1\/(?:.*?)\/(?:platform|analytics.*)?/;
function getCDN() {
    var cdn = undefined;
    var scripts = Array.prototype.slice.call(document.querySelectorAll('script'));
    scripts.forEach(function (s) {
        var _a;
        var src = (_a = s.getAttribute('src')) !== null && _a !== void 0 ? _a : '';
        var result = regex.exec(src);
        if (result && result[1]) {
            cdn = result[1];
        }
    });
    // it's possible that the CDN is not found in the page because:
    // - the script is loaded through a proxy
    // - the script is removed after execution
    // in this case, we fall back to the default Segment CDN
    if (!cdn) {
        return "https://cdn.segment.com";
    }
    return cdn;
}
/**
 * Replaces the CDN URL in the script tag with the one from Analytics.js 1.0
 *
 * @returns the path to Analytics JS 1.0
 **/
function getLegacyAJSPath() {
    var _a, _b;
    var writeKey = (_a = (0,_embedded_write_key__WEBPACK_IMPORTED_MODULE_0__.embeddedWriteKey)()) !== null && _a !== void 0 ? _a : window.analytics._writeKey;
    var scripts = Array.prototype.slice.call(document.querySelectorAll('script'));
    var path = undefined;
    for (var _i = 0, scripts_1 = scripts; _i < scripts_1.length; _i++) {
        var s = scripts_1[_i];
        var src = (_b = s.getAttribute('src')) !== null && _b !== void 0 ? _b : '';
        var result = regex.exec(src);
        if (result && result[1]) {
            path = src;
            break;
        }
    }
    if (path) {
        return path.replace('analytics.min.js', 'analytics.classic.js');
    }
    return "https://cdn.segment.com/analytics.js/v1/" + writeKey + "/analytics.classic.js";
}


/***/ }),

/***/ 7390:
/*!*******************************************!*\
  !*** ./src/lib/priority-queue/backoff.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "backoff": function() { return /* binding */ backoff; }
/* harmony export */ });
function backoff(params) {
    var random = Math.random() + 1;
    var _a = params.minTimeout, minTimeout = _a === void 0 ? 500 : _a, _b = params.factor, factor = _b === void 0 ? 2 : _b, attempt = params.attempt, _c = params.maxTimeout, maxTimeout = _c === void 0 ? Infinity : _c;
    return Math.min(random * minTimeout * Math.pow(factor, attempt), maxTimeout);
}


/***/ }),

/***/ 7485:
/*!*****************************************!*\
  !*** ./src/lib/priority-queue/index.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PriorityQueue": function() { return /* binding */ PriorityQueue; }
/* harmony export */ });
/* harmony import */ var _backoff__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./backoff */ 7390);

var PriorityQueue = /** @class */ (function () {
    function PriorityQueue(maxAttempts, queue, seen) {
        this.future = [];
        this.maxAttempts = maxAttempts;
        this.queue = queue;
        this.seen = seen !== null && seen !== void 0 ? seen : {};
    }
    PriorityQueue.prototype.push = function () {
        var _this = this;
        var operations = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            operations[_i] = arguments[_i];
        }
        var accepted = operations.map(function (operation) {
            var attempts = _this.updateAttempts(operation);
            if (attempts > _this.maxAttempts || _this.includes(operation)) {
                return false;
            }
            _this.queue.push(operation);
            return true;
        });
        this.queue = this.queue.sort(function (a, b) { return _this.getAttempts(a) - _this.getAttempts(b); });
        return accepted;
    };
    PriorityQueue.prototype.pushWithBackoff = function (operation) {
        var _this = this;
        if (this.getAttempts(operation) === 0) {
            return this.push(operation)[0];
        }
        var attempt = this.updateAttempts(operation);
        if (attempt > this.maxAttempts || this.includes(operation)) {
            return false;
        }
        var timeout = (0,_backoff__WEBPACK_IMPORTED_MODULE_0__.backoff)({ attempt: attempt - 1 });
        setTimeout(function () {
            _this.queue.push(operation);
            // remove from future list
            _this.future = _this.future.filter(function (f) { return f.id !== operation.id; });
        }, timeout);
        this.future.push(operation);
        return true;
    };
    PriorityQueue.prototype.getAttempts = function (operation) {
        var _a;
        return (_a = this.seen[operation.id]) !== null && _a !== void 0 ? _a : 0;
    };
    PriorityQueue.prototype.updateAttempts = function (operation) {
        this.seen[operation.id] = this.getAttempts(operation) + 1;
        return this.getAttempts(operation);
    };
    PriorityQueue.prototype.includes = function (operation) {
        return (this.queue.includes(operation) ||
            this.future.includes(operation) ||
            Boolean(this.queue.find(function (i) { return i.id === operation.id; })) ||
            Boolean(this.future.find(function (i) { return i.id === operation.id; })));
    };
    PriorityQueue.prototype.pop = function () {
        return this.queue.shift();
    };
    Object.defineProperty(PriorityQueue.prototype, "length", {
        get: function () {
            return this.queue.length;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PriorityQueue.prototype, "todo", {
        get: function () {
            return this.queue.length + this.future.length;
        },
        enumerable: false,
        configurable: true
    });
    return PriorityQueue;
}());



/***/ }),

/***/ 1778:
/*!*********************************************!*\
  !*** ./src/lib/priority-queue/persisted.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PersistedPriorityQueue": function() { return /* binding */ PersistedPriorityQueue; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! . */ 7485);
/* harmony import */ var _core_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/context */ 5373);
/* harmony import */ var _core_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/environment */ 4083);




var loc = {
    getItem: function () { },
    setItem: function () { },
    removeItem: function () { },
};
try {
    loc = (0,_core_environment__WEBPACK_IMPORTED_MODULE_0__.isBrowser)() && window.localStorage ? window.localStorage : loc;
}
catch (err) {
    console.warn('Unable to access localStorage', err);
}
function persisted(key) {
    var items = loc.getItem(key);
    return (items ? JSON.parse(items) : []).map(function (p) { return new _core_context__WEBPACK_IMPORTED_MODULE_1__.Context(p.event, p.id); });
}
function persistItems(key, items) {
    var existing = persisted(key);
    var all = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__spreadArrays)(items, existing);
    var merged = all.reduce(function (acc, item) {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_a = {}, _a[item.id] = item, _a));
    }, {});
    loc.setItem(key, JSON.stringify(Object.values(merged)));
}
function seen(key) {
    var stored = loc.getItem(key);
    return stored ? JSON.parse(stored) : {};
}
function persistSeen(key, memory) {
    var stored = seen(key);
    loc.setItem(key, JSON.stringify((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, stored), memory)));
}
function remove(key) {
    loc.removeItem(key);
}
var now = function () { return new Date().getTime(); };
function mutex(key, onUnlock, attempt) {
    if (attempt === void 0) { attempt = 0; }
    var lockTimeout = 50;
    var lockKey = "persisted-queue:v1:" + key + ":lock";
    var expired = function (lock) { return new Date().getTime() > lock; };
    var rawLock = loc.getItem(lockKey);
    var lock = rawLock ? JSON.parse(rawLock) : null;
    var allowed = lock === null || expired(lock);
    if (allowed) {
        loc.setItem(lockKey, JSON.stringify(now() + lockTimeout));
        onUnlock();
        loc.removeItem(lockKey);
        return;
    }
    if (!allowed && attempt < 3) {
        setTimeout(function () {
            mutex(key, onUnlock, attempt + 1);
        }, lockTimeout);
    }
    else {
        throw new Error('Unable to retrieve lock');
    }
}
var PersistedPriorityQueue = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(PersistedPriorityQueue, _super);
    function PersistedPriorityQueue(maxAttempts, key) {
        var _this = _super.call(this, maxAttempts, []) || this;
        var itemsKey = "persisted-queue:v1:" + key + ":items";
        var seenKey = "persisted-queue:v1:" + key + ":seen";
        var saved = [];
        var lastSeen = {};
        mutex(key, function () {
            try {
                saved = persisted(itemsKey);
                lastSeen = seen(seenKey);
                remove(itemsKey);
                remove(seenKey);
                _this.queue = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__spreadArrays)(saved, _this.queue);
                _this.seen = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, lastSeen), _this.seen);
            }
            catch (err) {
                console.error(err);
            }
        });
        window.addEventListener('beforeunload', function () {
            if (_this.todo > 0) {
                var items_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__spreadArrays)(_this.queue, _this.future);
                try {
                    mutex(key, function () {
                        persistItems(itemsKey, items_1);
                        persistSeen(seenKey, _this.seen);
                    });
                }
                catch (err) {
                    console.error(err);
                }
            }
        });
        return _this;
    }
    return PersistedPriorityQueue;
}(___WEBPACK_IMPORTED_MODULE_3__.PriorityQueue));



/***/ }),

/***/ 2722:
/*!******************************!*\
  !*** ./src/lib/to-facade.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "toFacade": function() { return /* binding */ toFacade; }
/* harmony export */ });
/* harmony import */ var _segment_facade__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @segment/facade */ 9969);
/* harmony import */ var _segment_facade__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_segment_facade__WEBPACK_IMPORTED_MODULE_0__);

function toFacade(evt, options) {
    var fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Facade(evt, options);
    if (evt.type === 'track') {
        fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Track(evt, options);
    }
    if (evt.type === 'identify') {
        fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Identify(evt, options);
    }
    if (evt.type === 'page') {
        fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Page(evt, options);
    }
    if (evt.type === 'alias') {
        fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Alias(evt, options);
    }
    if (evt.type === 'group') {
        fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Group(evt, options);
    }
    if (evt.type === 'screen') {
        fcd = new _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Screen(evt, options);
    }
    Object.defineProperty(fcd, 'obj', {
        value: evt,
        writable: true,
    });
    return fcd;
}


/***/ }),

/***/ 7985:
/*!**********************************************!*\
  !*** ./src/plugins/page-enrichment/index.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "canonicalUrl": function() { return /* binding */ canonicalUrl; },
/* harmony export */   "pageDefaults": function() { return /* binding */ pageDefaults; },
/* harmony export */   "pageEnrichment": function() { return /* binding */ pageEnrichment; }
/* harmony export */ });
/**
 * Get the current page's canonical URL.
 *
 * @return {string|undefined}
 */
function canonical() {
    var tags = document.getElementsByTagName('link');
    var canon = '';
    Array.prototype.slice.call(tags).forEach(function (tag) {
        if (tag.getAttribute('rel') === 'canonical') {
            canon = tag.getAttribute('href');
        }
    });
    return canon;
}
/**
 * Return the canonical path for the page.
 */
function canonicalPath() {
    var canon = canonical();
    if (!canon) {
        return window.location.pathname;
    }
    var a = document.createElement('a');
    a.href = canon;
    var pathname = !a.pathname.startsWith('/') ? '/' + a.pathname : a.pathname;
    return pathname;
}
/**
 * Return the canonical URL for the page concat the given `search`
 * and strip the hash.
 */
function canonicalUrl(search) {
    if (search === void 0) { search = ''; }
    var canon = canonical();
    if (canon) {
        return canon.includes('?') ? canon : "" + canon + search;
    }
    var url = window.location.href;
    var i = url.indexOf('#');
    return i === -1 ? url : url.slice(0, i);
}
/**
 * Return a default `options.context.page` object.
 *
 * https://segment.com/docs/spec/page/#properties
 */
function pageDefaults() {
    return {
        path: canonicalPath(),
        referrer: document.referrer,
        search: location.search,
        title: document.title,
        url: canonicalUrl(location.search),
    };
}
function enrichPageContext(ctx) {
    var _a;
    var event = ctx.event;
    event.context = event.context || {};
    var pageContext = pageDefaults();
    var pageProps = (_a = event.properties) !== null && _a !== void 0 ? _a : {};
    Object.keys(pageContext).forEach(function (key) {
        if (pageProps[key]) {
            pageContext[key] = pageProps[key];
        }
    });
    if (event.context.page) {
        pageContext = Object.assign({}, pageContext, event.context.page);
    }
    event.context = Object.assign({}, event.context, {
        page: pageContext,
    });
    ctx.event = event;
    return ctx;
}
var pageEnrichment = {
    name: 'Page Enrichment',
    version: '0.1.0',
    isLoaded: function () { return true; },
    load: function () { return Promise.resolve(); },
    type: 'before',
    page: function (ctx) {
        ctx.event.properties = Object.assign({}, pageDefaults(), ctx.event.properties);
        if (ctx.event.name) {
            ctx.event.properties.name = ctx.event.name;
        }
        return enrichPageContext(ctx);
    },
    alias: enrichPageContext,
    track: enrichPageContext,
    identify: enrichPageContext,
    group: enrichPageContext,
};


/***/ }),

/***/ 990:
/*!********************************************!*\
  !*** ./src/plugins/remote-loader/index.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "remoteLoader": function() { return /* binding */ remoteLoader; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _lib_as_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/as-promise */ 5764);
/* harmony import */ var _lib_load_script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/load-script */ 6673);
/* harmony import */ var _lib_parse_cdn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/parse-cdn */ 46);




function validate(pluginLike) {
    if (!Array.isArray(pluginLike)) {
        throw new Error('Not a valid list of plugins');
    }
    var required = ['load', 'isLoaded', 'name', 'version', 'type'];
    pluginLike.forEach(function (plugin) {
        required.forEach(function (method) {
            var _a;
            if (plugin[method] === undefined) {
                throw new Error("Plugin: " + ((_a = plugin.name) !== null && _a !== void 0 ? _a : 'unknown') + " missing required function " + method);
            }
        });
    });
    return true;
}
function remoteLoader(settings) {
    var _a, _b, _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
        var allPlugins, cdn, pluginPromises;
        var _this = this;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_d) {
            switch (_d.label) {
                case 0:
                    allPlugins = [];
                    cdn = (_b = (_a = window.analytics) === null || _a === void 0 ? void 0 : _a._cdn) !== null && _b !== void 0 ? _b : (0,_lib_parse_cdn__WEBPACK_IMPORTED_MODULE_1__.getCDN)();
                    pluginPromises = ((_c = settings.remotePlugins) !== null && _c !== void 0 ? _c : []).map(function (remotePlugin) { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(_this, void 0, void 0, function () {
                        var libraryName, pluginFactory, plugin, plugins, error_1;
                        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    _a.trys.push([0, 4, , 5]);
                                    return [4 /*yield*/, (0,_lib_load_script__WEBPACK_IMPORTED_MODULE_2__.loadScript)(remotePlugin.url.replace('https://cdn.segment.com', cdn))];
                                case 1:
                                    _a.sent();
                                    libraryName = remotePlugin.libraryName;
                                    if (!(typeof window[libraryName] === 'function')) return [3 /*break*/, 3];
                                    pluginFactory = window[libraryName];
                                    return [4 /*yield*/, (0,_lib_as_promise__WEBPACK_IMPORTED_MODULE_3__.asPromise)(pluginFactory(remotePlugin.settings))];
                                case 2:
                                    plugin = _a.sent();
                                    plugins = Array.isArray(plugin) ? plugin : [plugin];
                                    validate(plugins);
                                    allPlugins.push.apply(allPlugins, plugins);
                                    _a.label = 3;
                                case 3: return [3 /*break*/, 5];
                                case 4:
                                    error_1 = _a.sent();
                                    console.warn('Failed to load Remote Plugin', error_1);
                                    return [3 /*break*/, 5];
                                case 5: return [2 /*return*/];
                            }
                        });
                    }); });
                    return [4 /*yield*/, Promise.all(pluginPromises)];
                case 1:
                    _d.sent();
                    return [2 /*return*/, allPlugins.filter(Boolean)];
            }
        });
    });
}


/***/ }),

/***/ 7365:
/*!*****************************************************!*\
  !*** ./src/plugins/segmentio/batched-dispatcher.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ batch; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! unfetch */ 5869);


var fetch = unfetch__WEBPACK_IMPORTED_MODULE_0__["default"];
if (typeof window !== 'undefined') {
    // @ts-ignore
    fetch = window.fetch || unfetch__WEBPACK_IMPORTED_MODULE_0__["default"];
}
var MAX_PAYLOAD_SIZE = 500;
function kilobytes(buffer) {
    var size = encodeURI(JSON.stringify(buffer)).split(/%..|./).length - 1;
    return size / 1024;
}
/**
 * Checks if the payload is over or close to
 * the maximum payload size allowed by tracking
 * API.
 */
function approachingTrackingAPILimit(buffer) {
    return kilobytes(buffer) >= MAX_PAYLOAD_SIZE - 50;
}
function chunks(batch) {
    var result = [];
    var index = 0;
    batch.forEach(function (item) {
        var size = kilobytes(result[index]);
        if (size >= 64) {
            index++;
        }
        if (result[index]) {
            result[index].push(item);
        }
        else {
            result[index] = [item];
        }
    });
    return result;
}
function batch(apiHost, config) {
    var _this = this;
    var _a, _b;
    var buffer = [];
    var flushing = false;
    var limit = (_a = config === null || config === void 0 ? void 0 : config.size) !== null && _a !== void 0 ? _a : 10;
    var timeout = (_b = config === null || config === void 0 ? void 0 : config.timeout) !== null && _b !== void 0 ? _b : 5000;
    function flush() {
        var _a;
        if (flushing) {
            return;
        }
        flushing = true;
        var batch = buffer.map(function (_a) {
            var _url = _a[0], blob = _a[1];
            return blob;
        });
        buffer = [];
        flushing = false;
        var writeKey = (_a = batch[0]) === null || _a === void 0 ? void 0 : _a.writeKey;
        return fetch("https://" + apiHost + "/b", {
            // @ts-ignore
            headers: {
                'Content-Type': 'application/json',
            },
            method: 'post',
            body: JSON.stringify({ batch: batch, writeKey: writeKey }),
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-use-before-define
    var schedule = scheduleFlush();
    function scheduleFlush() {
        return setTimeout(function () {
            schedule = undefined;
            if (buffer.length && !flushing) {
                flush();
            }
        }, timeout);
    }
    window.addEventListener('beforeunload', function () {
        if (buffer.length === 0) {
            return;
        }
        var batch = buffer.map(function (_a) {
            var _url = _a[0], blob = _a[1];
            return blob;
        });
        var chunked = chunks(batch);
        var reqs = chunked.map(function (chunk) { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () {
            var remote, writeKey;
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
                if (chunk.length === 0) {
                    return [2 /*return*/];
                }
                remote = "https://" + apiHost + "/b";
                writeKey = (_a = chunk[0]) === null || _a === void 0 ? void 0 : _a.writeKey;
                return [2 /*return*/, fetch(remote, {
                        // @ts-expect-error
                        keepalive: true,
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        method: 'post',
                        body: JSON.stringify({ batch: chunk, writeKey: writeKey }),
                    })];
            });
        }); });
        Promise.all(reqs).catch(console.error);
    });
    function dispatch(url, body) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            var bufferOverflow;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                buffer.push([url, body]);
                bufferOverflow = buffer.length >= limit || approachingTrackingAPILimit(buffer);
                if (bufferOverflow && !flushing) {
                    flush();
                }
                else {
                    if (!schedule) {
                        schedule = scheduleFlush();
                    }
                }
                return [2 /*return*/, true];
            });
        });
    }
    return {
        dispatch: dispatch,
    };
}


/***/ }),

/***/ 1497:
/*!***************************************************!*\
  !*** ./src/plugins/segmentio/fetch-dispatcher.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* export default binding */ __WEBPACK_DEFAULT_EXPORT__; }
/* harmony export */ });
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! unfetch */ 5869);

var fetch = unfetch__WEBPACK_IMPORTED_MODULE_0__["default"];
if (typeof window !== 'undefined') {
    // @ts-ignore
    fetch = window.fetch || unfetch__WEBPACK_IMPORTED_MODULE_0__["default"];
}
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__() {
    function dispatch(url, body) {
        return fetch(url, {
            headers: { 'Content-Type': 'application/json' },
            method: 'post',
            body: JSON.stringify(body),
        });
    }
    return {
        dispatch: dispatch,
    };
}


/***/ }),

/***/ 6678:
/*!****************************************!*\
  !*** ./src/plugins/segmentio/index.ts ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "segmentio": function() { return /* binding */ segmentio; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _core_connection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/connection */ 8231);
/* harmony import */ var _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/priority-queue/persisted */ 1778);
/* harmony import */ var _lib_to_facade__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/to-facade */ 2722);
/* harmony import */ var _batched_dispatcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./batched-dispatcher */ 7365);
/* harmony import */ var _fetch_dispatcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./fetch-dispatcher */ 1497);
/* harmony import */ var _normalize__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./normalize */ 9841);
/* harmony import */ var _schedule_flush__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./schedule-flush */ 6004);








function onAlias(analytics, json) {
    var _a, _b, _c, _d;
    var user = analytics.user();
    json.previousId = (_c = (_b = (_a = json.previousId) !== null && _a !== void 0 ? _a : json.from) !== null && _b !== void 0 ? _b : user.id()) !== null && _c !== void 0 ? _c : user.anonymousId();
    json.userId = (_d = json.userId) !== null && _d !== void 0 ? _d : json.to;
    delete json.from;
    delete json.to;
    return json;
}
function segmentio(analytics, settings, integrations) {
    var _a, _b, _c;
    var buffer = new _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_0__.PersistedPriorityQueue(analytics.queue.queue.maxAttempts, "dest-Segment.io");
    var flushing = false;
    var apiHost = (_a = settings === null || settings === void 0 ? void 0 : settings.apiHost) !== null && _a !== void 0 ? _a : 'api.june.so/sdk';
    var remote = apiHost.includes('localhost')
        ? "http://" + apiHost
        : "https://" + apiHost;
    var client = ((_b = settings === null || settings === void 0 ? void 0 : settings.deliveryStrategy) === null || _b === void 0 ? void 0 : _b.strategy) === 'batching'
        ? (0,_batched_dispatcher__WEBPACK_IMPORTED_MODULE_1__["default"])(apiHost, (_c = settings === null || settings === void 0 ? void 0 : settings.deliveryStrategy) === null || _c === void 0 ? void 0 : _c.config)
        : (0,_fetch_dispatcher__WEBPACK_IMPORTED_MODULE_2__["default"])();
    function send(ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, Promise, function () {
            var path, json;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
                if ((0,_core_connection__WEBPACK_IMPORTED_MODULE_4__.isOffline)()) {
                    buffer.push(ctx);
                    // eslint-disable-next-line @typescript-eslint/no-use-before-define
                    (0,_schedule_flush__WEBPACK_IMPORTED_MODULE_5__.scheduleFlush)(flushing, buffer, segmentio, _schedule_flush__WEBPACK_IMPORTED_MODULE_5__.scheduleFlush);
                    return [2 /*return*/, ctx];
                }
                path = ctx.event.type //.charAt(0)
                ;
                json = (0,_lib_to_facade__WEBPACK_IMPORTED_MODULE_6__.toFacade)(ctx.event).json();
                if (ctx.event.type === 'track') {
                    delete json.traits;
                }
                if (ctx.event.type === 'alias') {
                    json = onAlias(analytics, json);
                }
                return [2 /*return*/, client
                        .dispatch(remote + "/" + path, (0,_normalize__WEBPACK_IMPORTED_MODULE_7__.normalize)(analytics, json, settings, integrations))
                        .then(function () { return ctx; })
                        .catch(function (err) {
                        if (err.type === 'error' || err.message === 'Failed to fetch') {
                            buffer.push(ctx);
                            // eslint-disable-next-line @typescript-eslint/no-use-before-define
                            (0,_schedule_flush__WEBPACK_IMPORTED_MODULE_5__.scheduleFlush)(flushing, buffer, segmentio, _schedule_flush__WEBPACK_IMPORTED_MODULE_5__.scheduleFlush);
                        }
                        return ctx;
                    })];
            });
        });
    }
    var segmentio = {
        name: 'Segment.io',
        type: 'after',
        version: '0.1.0',
        isLoaded: function () { return true; },
        load: function () { return Promise.resolve(); },
        track: send,
        identify: send,
        page: send,
        alias: send,
        group: send,
    };
    return segmentio;
}


/***/ }),

/***/ 9841:
/*!********************************************!*\
  !*** ./src/plugins/segmentio/normalize.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "setVersionType": function() { return /* binding */ setVersionType; },
/* harmony export */   "getVersionType": function() { return /* binding */ getVersionType; },
/* harmony export */   "sCookie": function() { return /* binding */ sCookie; },
/* harmony export */   "ampId": function() { return /* binding */ ampId; },
/* harmony export */   "utm": function() { return /* binding */ utm; },
/* harmony export */   "normalize": function() { return /* binding */ normalize; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! js-cookie */ 6808);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_user_tld__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/user/tld */ 928);
/* harmony import */ var _generated_version__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../generated/version */ 1594);




var domain = undefined;
try {
    domain = (0,_core_user_tld__WEBPACK_IMPORTED_MODULE_1__.tld)(new URL(window.location.href));
}
catch (_) {
    domain = undefined;
}
var cookieOptions = {
    expires: 31536000000,
    secure: false,
    path: '/',
};
if (domain) {
    cookieOptions.domain = domain;
}
// Default value will be updated to 'web' in `bundle-umd.ts` for web build.
var _version = 'npm';
function setVersionType(version) {
    _version = version;
}
function getVersionType() {
    return _version;
}
function sCookie(key, value) {
    return (0,js_cookie__WEBPACK_IMPORTED_MODULE_0__.set)(key, value, cookieOptions);
}
function ampId() {
    var ampId = (0,js_cookie__WEBPACK_IMPORTED_MODULE_0__.get)('_ga');
    if (ampId && ampId.startsWith('amp')) {
        return ampId;
    }
}
function utm(query) {
    if (query.startsWith('?')) {
        query = query.substring(1);
    }
    query = query.replace(/\?/g, '&');
    return query.split('&').reduce(function (acc, str) {
        var _a = str.split('='), k = _a[0], _b = _a[1], v = _b === void 0 ? '' : _b;
        if (k.includes('utm_') && k.length > 4) {
            var utmParam = k.substr(4);
            if (utmParam === 'campaign') {
                utmParam = 'name';
            }
            acc[utmParam] = decodeURIComponent(v.replace(/\+/g, ' '));
        }
        return acc;
    }, {});
}
function ads(query) {
    var queryIds = {
        btid: 'dataxu',
        urid: 'millennial-media',
    };
    if (query.startsWith('?')) {
        query = query.substring(1);
    }
    query = query.replace(/\?/g, '&');
    var parts = query.split('&');
    for (var _i = 0, parts_1 = parts; _i < parts_1.length; _i++) {
        var part = parts_1[_i];
        var _a = part.split('='), k = _a[0], v = _a[1];
        if (queryIds[k]) {
            return {
                id: v,
                type: queryIds[k],
            };
        }
    }
}
function referrerId(query, ctx) {
    var stored = (0,js_cookie__WEBPACK_IMPORTED_MODULE_0__.get)('s:context.referrer');
    var ad = ads(query);
    stored = stored ? JSON.parse(stored) : undefined;
    ad = ad !== null && ad !== void 0 ? ad : stored;
    if (!ad) {
        return;
    }
    if (ctx) {
        ctx.referrer = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, ctx.referrer), ad);
    }
    (0,js_cookie__WEBPACK_IMPORTED_MODULE_0__.set)('s:context.referrer', JSON.stringify(ad), cookieOptions);
}
function normalize(analytics, json, settings, integrations) {
    var _a, _b, _c;
    var user = analytics.user();
    var query = window.location.search;
    json.context = (_b = (_a = json.context) !== null && _a !== void 0 ? _a : json.options) !== null && _b !== void 0 ? _b : {};
    var ctx = json.context;
    var anonId = json.anonymousId;
    delete json.options;
    json.writeKey = settings === null || settings === void 0 ? void 0 : settings.apiKey;
    ctx.userAgent = window.navigator.userAgent;
    // @ts-ignore
    var locale = navigator.userLanguage || navigator.language;
    if (typeof ctx.locale === 'undefined' && typeof locale !== 'undefined') {
        ctx.locale = locale;
    }
    if (!ctx.library) {
        var type = getVersionType();
        if (type === 'web') {
            ctx.library = {
                name: 'analytics.js',
                version: "next-" + _generated_version__WEBPACK_IMPORTED_MODULE_3__.version,
            };
        }
        else {
            ctx.library = {
                name: 'analytics.js',
                version: "npm:next-" + _generated_version__WEBPACK_IMPORTED_MODULE_3__.version,
            };
        }
    }
    if (query && !ctx.campaign) {
        ctx.campaign = utm(query);
    }
    referrerId(query, ctx);
    json.userId = json.userId || user.id();
    json.anonymousId = user.anonymousId(anonId);
    json.sentAt = new Date();
    json.timestamp = new Date();
    var failed = analytics.queue.failedInitializations || [];
    if (failed.length > 0) {
        json._metadata = { failedInitializations: failed };
    }
    var bundled = [];
    var unbundled = [];
    for (var key in integrations) {
        var integration = integrations[key];
        if (key === 'Segment.io') {
            bundled.push(key);
        }
        if (integration.bundlingStatus === 'bundled') {
            bundled.push(key);
        }
        if (integration.bundlingStatus === 'unbundled') {
            unbundled.push(key);
        }
    }
    // This will make sure that the disabled cloud mode destinations will be
    // included in the unbundled list.
    for (var _i = 0, _d = (settings === null || settings === void 0 ? void 0 : settings.unbundledIntegrations) || []; _i < _d.length; _i++) {
        var settingsUnbundled = _d[_i];
        if (!unbundled.includes(settingsUnbundled)) {
            unbundled.push(settingsUnbundled);
        }
    }
    var configIds = (_c = settings === null || settings === void 0 ? void 0 : settings.maybeBundledConfigIds) !== null && _c !== void 0 ? _c : {};
    var bundledConfigIds = [];
    bundled.sort().forEach(function (name) {
        var _a;
        ;
        ((_a = configIds[name]) !== null && _a !== void 0 ? _a : []).forEach(function (id) {
            bundledConfigIds.push(id);
        });
    });
    if ((settings === null || settings === void 0 ? void 0 : settings.addBundledMetadata) !== false) {
        json._metadata = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, json._metadata), { bundled: bundled.sort(), unbundled: unbundled.sort(), bundledIds: bundledConfigIds });
    }
    var amp = ampId();
    if (amp) {
        ctx.amp = { id: amp };
    }
    return json;
}


/***/ }),

/***/ 6004:
/*!*************************************************!*\
  !*** ./src/plugins/segmentio/schedule-flush.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "scheduleFlush": function() { return /* binding */ scheduleFlush; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _core_connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/connection */ 8231);
/* harmony import */ var _core_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/context */ 5373);
/* harmony import */ var _core_queue_delivery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/queue/delivery */ 57);
/* harmony import */ var _lib_p_while__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/p-while */ 3319);





function flushQueue(xt, queue) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
        var failedQueue;
        var _this = this;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    failedQueue = [];
                    if ((0,_core_connection__WEBPACK_IMPORTED_MODULE_1__.isOffline)()) {
                        return [2 /*return*/, queue];
                    }
                    return [4 /*yield*/, (0,_lib_p_while__WEBPACK_IMPORTED_MODULE_2__.pWhile)(function () { return queue.length > 0 && !(0,_core_connection__WEBPACK_IMPORTED_MODULE_1__.isOffline)(); }, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(_this, void 0, void 0, function () {
                            var ctx, result, success;
                            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        ctx = queue.pop();
                                        if (!ctx) {
                                            return [2 /*return*/];
                                        }
                                        return [4 /*yield*/, (0,_core_queue_delivery__WEBPACK_IMPORTED_MODULE_3__.attempt)(ctx, xt)];
                                    case 1:
                                        result = _a.sent();
                                        success = result instanceof _core_context__WEBPACK_IMPORTED_MODULE_4__.Context;
                                        if (!success) {
                                            failedQueue.push(ctx);
                                        }
                                        return [2 /*return*/];
                                }
                            });
                        }); })
                        // re-add failed tasks
                    ];
                case 1:
                    _a.sent();
                    // re-add failed tasks
                    failedQueue.map(function (failed) { return queue.pushWithBackoff(failed); });
                    return [2 /*return*/, queue];
            }
        });
    });
}
function scheduleFlush(flushing, buffer, xt, scheduleFlush) {
    var _this = this;
    if (flushing) {
        return;
    }
    // eslint-disable-next-line @typescript-eslint/no-misused-promises
    setTimeout(function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(_this, void 0, void 0, function () {
        var isFlushing, newBuffer;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    isFlushing = true;
                    return [4 /*yield*/, flushQueue(xt, buffer)];
                case 1:
                    newBuffer = _a.sent();
                    isFlushing = false;
                    if (buffer.todo > 0) {
                        scheduleFlush(isFlushing, newBuffer, xt, scheduleFlush);
                    }
                    return [2 /*return*/];
            }
        });
    }); }, Math.random() * 5000);
}


/***/ }),

/***/ 2487:
/*!*****************************************!*\
  !*** ./src/plugins/validation/index.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isString": function() { return /* binding */ isString; },
/* harmony export */   "isNumber": function() { return /* binding */ isNumber; },
/* harmony export */   "isFunction": function() { return /* binding */ isFunction; },
/* harmony export */   "isPlainObject": function() { return /* binding */ isPlainObject; },
/* harmony export */   "validation": function() { return /* binding */ validation; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

function isString(obj) {
    return typeof obj === 'string';
}
function isNumber(obj) {
    return typeof obj === 'number';
}
function isFunction(obj) {
    return typeof obj === 'function';
}
function isPlainObject(obj) {
    return (Object.prototype.toString.call(obj).slice(8, -1).toLowerCase() === 'object');
}
function hasUser(event) {
    var _a, _b, _c;
    var id = (_c = (_b = (_a = event.userId) !== null && _a !== void 0 ? _a : event.anonymousId) !== null && _b !== void 0 ? _b : event.groupId) !== null && _c !== void 0 ? _c : event.previousId;
    return isString(id);
}
var ValidationError = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ValidationError, _super);
    function ValidationError(field, message) {
        var _this = _super.call(this, message) || this;
        _this.field = field;
        return _this;
    }
    return ValidationError;
}(Error));
function validate(ctx) {
    var _a;
    var eventType = ctx && ctx.event && ctx.event.type;
    var event = ctx.event;
    if (event === undefined) {
        throw new ValidationError('event', 'Event is missing');
    }
    if (!isString(eventType)) {
        throw new ValidationError('event', 'Event is not a string');
    }
    if (eventType === 'track' && !isString(event.event)) {
        throw new ValidationError('event', 'Event is not a string');
    }
    var props = (_a = event.properties) !== null && _a !== void 0 ? _a : event.traits;
    if (eventType !== 'alias' && !isPlainObject(props)) {
        throw new ValidationError('properties', 'properties is not an object');
    }
    if (!hasUser(event)) {
        throw new ValidationError('userId', 'Missing userId or anonymousId');
    }
    return ctx;
}
var validation = {
    name: 'Event Validation',
    type: 'before',
    version: '1.0.0',
    isLoaded: function () { return true; },
    load: function () { return Promise.resolve(); },
    track: validate,
    identify: validate,
    page: validate,
    alias: validate,
    group: validate,
    screen: validate,
};


/***/ }),

/***/ 655:
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__extends": function() { return /* binding */ __extends; },
/* harmony export */   "__assign": function() { return /* binding */ __assign; },
/* harmony export */   "__rest": function() { return /* binding */ __rest; },
/* harmony export */   "__decorate": function() { return /* binding */ __decorate; },
/* harmony export */   "__param": function() { return /* binding */ __param; },
/* harmony export */   "__metadata": function() { return /* binding */ __metadata; },
/* harmony export */   "__awaiter": function() { return /* binding */ __awaiter; },
/* harmony export */   "__generator": function() { return /* binding */ __generator; },
/* harmony export */   "__createBinding": function() { return /* binding */ __createBinding; },
/* harmony export */   "__exportStar": function() { return /* binding */ __exportStar; },
/* harmony export */   "__values": function() { return /* binding */ __values; },
/* harmony export */   "__read": function() { return /* binding */ __read; },
/* harmony export */   "__spread": function() { return /* binding */ __spread; },
/* harmony export */   "__spreadArrays": function() { return /* binding */ __spreadArrays; },
/* harmony export */   "__spreadArray": function() { return /* binding */ __spreadArray; },
/* harmony export */   "__await": function() { return /* binding */ __await; },
/* harmony export */   "__asyncGenerator": function() { return /* binding */ __asyncGenerator; },
/* harmony export */   "__asyncDelegator": function() { return /* binding */ __asyncDelegator; },
/* harmony export */   "__asyncValues": function() { return /* binding */ __asyncValues; },
/* harmony export */   "__makeTemplateObject": function() { return /* binding */ __makeTemplateObject; },
/* harmony export */   "__importStar": function() { return /* binding */ __importStar; },
/* harmony export */   "__importDefault": function() { return /* binding */ __importDefault; },
/* harmony export */   "__classPrivateFieldGet": function() { return /* binding */ __classPrivateFieldGet; },
/* harmony export */   "__classPrivateFieldSet": function() { return /* binding */ __classPrivateFieldSet; }
/* harmony export */ });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}


/***/ }),

/***/ 5869:
/*!*****************************************************!*\
  !*** ./node_modules/unfetch/dist/unfetch.module.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* export default binding */ __WEBPACK_DEFAULT_EXPORT__; }
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(e,n){return n=n||{},new Promise(function(t,r){var s=new XMLHttpRequest,o=[],u=[],i={},a=function(){return{ok:2==(s.status/100|0),statusText:s.statusText,status:s.status,url:s.responseURL,text:function(){return Promise.resolve(s.responseText)},json:function(){return Promise.resolve(s.responseText).then(JSON.parse)},blob:function(){return Promise.resolve(new Blob([s.response]))},clone:a,headers:{keys:function(){return o},entries:function(){return u},get:function(e){return i[e.toLowerCase()]},has:function(e){return e.toLowerCase()in i}}}};for(var l in s.open(n.method||"get",e,!0),s.onload=function(){s.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm,function(e,n,t){o.push(n=n.toLowerCase()),u.push([n,t]),i[n]=i[n]?i[n]+","+t:t}),t(a())},s.onerror=r,s.withCredentials="include"==n.credentials,n.headers)s.setRequestHeader(l,n.headers[l]);s.send(n.body||null)})}
//# sourceMappingURL=unfetch.module.js.map


/***/ }),

/***/ 9108:
/*!**************************************************!*\
  !*** ./node_modules/@lukeed/uuid/dist/index.mjs ***!
  \**************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v4": function() { return /* binding */ v4; }
/* harmony export */ });
var IDX=256, HEX=[], BUFFER;
while (IDX--) HEX[IDX] = (IDX + 256).toString(16).substring(1);

function v4() {
	var i=0, num, out='';

	if (!BUFFER || ((IDX + 16) > 256)) {
		BUFFER = Array(i=256);
		while (i--) BUFFER[i] = 256 * Math.random() | 0;
		i = IDX = 0;
	}

	for (; i < 16; i++) {
		num = BUFFER[IDX + i];
		if (i==6) out += HEX[num & 15 | 64];
		else if (i==8) out += HEX[num & 63 | 128];
		else out += HEX[num];

		if (i & 1 && i > 1 && i < 11) out += '-';
	}

	IDX++;
	return out;
}


/***/ }),

/***/ 6475:
/*!******************************************!*\
  !*** ./node_modules/dset/dist/index.mjs ***!
  \******************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dset": function() { return /* binding */ dset; }
/* harmony export */ });
function dset(obj, keys, val) {
	keys.split && (keys=keys.split('.'));
	var i=0, l=keys.length, t=obj, x, k;
	while (i < l) {
		k = keys[i++];
		if (k === '__proto__' || k === 'constructor' || k === 'prototype') break;
		t = t[k] = (i === l) ? val : (typeof(x=t[k])===typeof(keys)) ? x : (keys[i]*0 !== 0 || !!~(''+keys[i]).indexOf('.')) ? {} : [];
	}
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	!function() {
/******/ 		var getProto = Object.getPrototypeOf ? function(obj) { return Object.getPrototypeOf(obj); } : function(obj) { return obj.__proto__; };
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach(function(key) { def[key] = function() { return value[key]; }; });
/******/ 			}
/******/ 			def['default'] = function() { return value; };
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	!function() {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = function(chunkId) {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce(function(promises, key) {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	!function() {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = function(chunkId) {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".bundle." + {"vendors-node_modules_segment_tsub_dist_index_js":"9d8e3332eccf0618070f","ajs-destination":"6aae057c068eea9d5067","legacyVideos":"af223d6f506705504411","schemaFilter":"c32e03d853b9db8650a0","remoteMiddleware":"8dd65ab8498c448fa32f","auto-track":"72f9350129e007413584","middleware":"317f84de8aa3c93ce341","queryString":"2f88d6c809c48bcdd6d2","vendors-node_modules_segment_analytics_js-video-plugins_dist_index_umd_js":"37c91b49f5bd744799a2"}[chunkId] + ".js";
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	!function() {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "@june-so/analytics-next:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = function(url, done, key, chunkId) {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = function(prev, event) {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach(function(fn) { return fn(event); });
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			;
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	!function() {
/******/ 		__webpack_require__.p = "";
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	!function() {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"index": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = function(chunkId, promises) {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise(function(resolve, reject) { installedChunkData = installedChunks[chunkId] = [resolve, reject]; });
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = function(event) {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						} else installedChunks[chunkId] = 0;
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = function(parentChunkLoadingFunction, data) {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some(function(id) { return installedChunks[id] !== 0; })) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunk_june_so_analytics_next"] = self["webpackChunk_june_so_analytics_next"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
!function() {
"use strict";
/*!****************************!*\
  !*** ./src/browser-umd.ts ***!
  \****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AnalyticsBrowser": function() { return /* reexport safe */ _browser__WEBPACK_IMPORTED_MODULE_1__.AnalyticsBrowser; },
/* harmony export */   "loadLegacySettings": function() { return /* reexport safe */ _browser__WEBPACK_IMPORTED_MODULE_1__.loadLegacySettings; }
/* harmony export */ });
/* harmony import */ var _plugins_segmentio_normalize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./plugins/segmentio/normalize */ 9841);
/* harmony import */ var _browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./browser */ 9686);
var _a, _b;


if (true) {
    if (true) {
        // @ts-ignore
        // eslint-disable-next-line @typescript-eslint/camelcase
        __webpack_require__.p = '/dist/umd/';
    }
    else { var cdn; }
}
(0,_plugins_segmentio_normalize__WEBPACK_IMPORTED_MODULE_0__.setVersionType)('web');


}();
/******/ 	return __webpack_exports__;
/******/ })()
;
});
//# sourceMappingURL=index.js.map