"use strict";
(self["webpackChunk_june_so_analytics_next"] = self["webpackChunk_june_so_analytics_next"] || []).push([["ajs-destination"],{

/***/ 9559:
/*!**********************************************!*\
  !*** ./src/plugins/ajs-destination/index.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LegacyDestination": function() { return /* binding */ LegacyDestination; },
/* harmony export */   "ajsDestinations": function() { return /* binding */ ajsDestinations; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _segment_facade__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @segment/facade */ 9969);
/* harmony import */ var _segment_facade__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_segment_facade__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_connection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/connection */ 8231);
/* harmony import */ var _core_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../core/context */ 5373);
/* harmony import */ var _core_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../core/environment */ 4083);
/* harmony import */ var _core_queue_delivery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/queue/delivery */ 57);
/* harmony import */ var _lib_as_promise__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../lib/as-promise */ 5764);
/* harmony import */ var _lib_merged_options__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../lib/merged-options */ 7851);
/* harmony import */ var _lib_p_while__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/p-while */ 3319);
/* harmony import */ var _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/priority-queue/persisted */ 1778);
/* harmony import */ var _middleware__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../middleware */ 2734);
/* harmony import */ var _routing_middleware__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../routing-middleware */ 4186);
/* harmony import */ var _loader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./loader */ 9962);













var klona = function (evt) {
    return JSON.parse(JSON.stringify(evt));
};
function flushQueue(xt, queue) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var failedQueue;
        var _this = this;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    failedQueue = [];
                    if ((0,_core_connection__WEBPACK_IMPORTED_MODULE_2__.isOffline)()) {
                        return [2 /*return*/, queue];
                    }
                    return [4 /*yield*/, (0,_lib_p_while__WEBPACK_IMPORTED_MODULE_3__.pWhile)(function () { return queue.length > 0 && (0,_core_connection__WEBPACK_IMPORTED_MODULE_2__.isOnline)(); }, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () {
                            var ctx, result, success;
                            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        ctx = queue.pop();
                                        if (!ctx) {
                                            return [2 /*return*/];
                                        }
                                        return [4 /*yield*/, (0,_core_queue_delivery__WEBPACK_IMPORTED_MODULE_4__.attempt)(ctx, xt)];
                                    case 1:
                                        result = _a.sent();
                                        success = result instanceof _core_context__WEBPACK_IMPORTED_MODULE_5__.Context;
                                        if (!success) {
                                            failedQueue.push(ctx);
                                        }
                                        return [2 /*return*/];
                                }
                            });
                        }); })
                        // re-add failed tasks
                    ];
                case 1:
                    _a.sent();
                    // re-add failed tasks
                    failedQueue.map(function (failed) { return queue.pushWithBackoff(failed); });
                    return [2 /*return*/, queue];
            }
        });
    });
}
var LegacyDestination = /** @class */ (function () {
    function LegacyDestination(name, version, settings, options) {
        if (settings === void 0) { settings = {}; }
        this.options = {};
        this.type = 'destination';
        this.middleware = [];
        this._ready = false;
        this._initialized = false;
        this.flushing = false;
        this.name = name;
        this.version = version;
        this.settings = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({}, settings);
        // AJS-Renderer sets an extraneous `type` setting that clobbers
        // existing type defaults. We need to remove it if it's present
        if (this.settings['type'] && this.settings['type'] === 'browser') {
            delete this.settings['type'];
        }
        this.options = options;
        this.buffer = new _lib_priority_queue_persisted__WEBPACK_IMPORTED_MODULE_6__.PersistedPriorityQueue(4, "dest-" + name);
        this.scheduleFlush();
    }
    LegacyDestination.prototype.isLoaded = function () {
        return this._ready;
    };
    LegacyDestination.prototype.ready = function () {
        var _a;
        return (_a = this.onReady) !== null && _a !== void 0 ? _a : Promise.resolve();
    };
    LegacyDestination.prototype.load = function (ctx, analyticsInstance) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            var _a;
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (this._ready || this.onReady !== undefined) {
                            return [2 /*return*/];
                        }
                        _a = this;
                        return [4 /*yield*/, (0,_loader__WEBPACK_IMPORTED_MODULE_7__.loadIntegration)(ctx, analyticsInstance, this.name, this.version, this.settings)];
                    case 1:
                        _a.integration = _b.sent();
                        this.onReady = new Promise(function (resolve) {
                            var onReadyFn = function () {
                                _this._ready = true;
                                resolve(true);
                            };
                            _this.integration.once('ready', onReadyFn);
                        });
                        this.onInitialize = new Promise(function (resolve) {
                            var onInit = function () {
                                _this._initialized = true;
                                resolve(true);
                            };
                            _this.integration.on('initialize', onInit);
                        });
                        try {
                            ctx.stats.increment('analytics_js.integration.invoke', 1, [
                                "method:initialize",
                                "integration_name:" + this.name,
                            ]);
                            this.integration.initialize();
                        }
                        catch (error) {
                            ctx.stats.increment('analytics_js.integration.invoke.error', 1, [
                                "method:initialize",
                                "integration_name:" + this.name,
                            ]);
                            throw error;
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    LegacyDestination.prototype.unload = function (_ctx, _analyticsInstance) {
        return (0,_loader__WEBPACK_IMPORTED_MODULE_7__.unloadIntegration)(this.name, this.version);
    };
    LegacyDestination.prototype.addMiddleware = function () {
        var _a;
        var fn = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fn[_i] = arguments[_i];
        }
        this.middleware = (_a = this.middleware).concat.apply(_a, fn);
    };
    LegacyDestination.prototype.shouldBuffer = function (ctx) {
        return (
        // page events can't be buffered because of destinations that automatically add page views
        ctx.event.type !== 'page' &&
            ((0,_core_connection__WEBPACK_IMPORTED_MODULE_2__.isOffline)() || this._ready === false || this._initialized === false));
    };
    LegacyDestination.prototype.send = function (ctx, clz, eventType) {
        var _a, _b;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            var plan, ev, planEvent, afterMiddleware, event, err_1;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        if (this.shouldBuffer(ctx)) {
                            this.buffer.push(ctx);
                            this.scheduleFlush();
                            return [2 /*return*/, ctx];
                        }
                        plan = (_b = (_a = this.options) === null || _a === void 0 ? void 0 : _a.plan) === null || _b === void 0 ? void 0 : _b.track;
                        ev = ctx.event.event;
                        if (plan && ev && this.name !== 'Segment.io') {
                            planEvent = plan[ev];
                            if ((planEvent === null || planEvent === void 0 ? void 0 : planEvent.enabled) === false) {
                                ctx.updateEvent('integrations', (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({}, ctx.event.integrations), { All: false, 'Segment.io': true }));
                                ctx.cancel(new _core_context__WEBPACK_IMPORTED_MODULE_5__.ContextCancelation({
                                    retry: false,
                                    reason: "Event " + ev + " disabled for integration " + this.name + " in tracking plan",
                                    type: 'Dropped by plan',
                                }));
                                return [2 /*return*/, ctx];
                            }
                            else {
                                ctx.updateEvent('integrations', (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({}, ctx.event.integrations), planEvent === null || planEvent === void 0 ? void 0 : planEvent.integrations));
                            }
                            if ((planEvent === null || planEvent === void 0 ? void 0 : planEvent.enabled) && (planEvent === null || planEvent === void 0 ? void 0 : planEvent.integrations[this.name]) === false) {
                                ctx.cancel(new _core_context__WEBPACK_IMPORTED_MODULE_5__.ContextCancelation({
                                    retry: false,
                                    reason: "Event " + ev + " disabled for integration " + this.name + " in tracking plan",
                                    type: 'Dropped by plan',
                                }));
                                return [2 /*return*/, ctx];
                            }
                        }
                        return [4 /*yield*/, (0,_middleware__WEBPACK_IMPORTED_MODULE_8__.applyDestinationMiddleware)(this.name, klona(ctx.event), this.middleware)];
                    case 1:
                        afterMiddleware = _c.sent();
                        if (afterMiddleware === null) {
                            return [2 /*return*/, ctx];
                        }
                        event = new clz(afterMiddleware, {});
                        ctx.stats.increment('analytics_js.integration.invoke', 1, [
                            "method:" + eventType,
                            "integration_name:" + this.name,
                        ]);
                        _c.label = 2;
                    case 2:
                        _c.trys.push([2, 5, , 6]);
                        if (!this.integration) return [3 /*break*/, 4];
                        return [4 /*yield*/, (0,_lib_as_promise__WEBPACK_IMPORTED_MODULE_9__.asPromise)(this.integration.invoke.call(this.integration, eventType, event))];
                    case 3:
                        _c.sent();
                        _c.label = 4;
                    case 4: return [3 /*break*/, 6];
                    case 5:
                        err_1 = _c.sent();
                        ctx.stats.increment('analytics_js.integration.invoke.error', 1, [
                            "method:" + eventType,
                            "integration_name:" + this.name,
                        ]);
                        throw err_1;
                    case 6: return [2 /*return*/, ctx];
                }
            });
        });
    };
    LegacyDestination.prototype.track = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                return [2 /*return*/, this.send(ctx, _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Track, 'track')];
            });
        });
    };
    LegacyDestination.prototype.page = function (ctx) {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            var _this = this;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
                if (((_a = this.integration) === null || _a === void 0 ? void 0 : _a._assumesPageview) && !this._initialized) {
                    this.integration.initialize();
                }
                return [2 /*return*/, this.onInitialize.then(function () {
                        return _this.send(ctx, _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Page, 'page');
                    })];
            });
        });
    };
    LegacyDestination.prototype.identify = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                return [2 /*return*/, this.send(ctx, _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Identify, 'identify')];
            });
        });
    };
    LegacyDestination.prototype.alias = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                return [2 /*return*/, this.send(ctx, _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Alias, 'alias')];
            });
        });
    };
    LegacyDestination.prototype.group = function (ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                return [2 /*return*/, this.send(ctx, _segment_facade__WEBPACK_IMPORTED_MODULE_0__.Group, 'group')];
            });
        });
    };
    LegacyDestination.prototype.scheduleFlush = function () {
        var _this = this;
        if (this.flushing) {
            return;
        }
        // eslint-disable-next-line @typescript-eslint/no-misused-promises
        setTimeout(function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () {
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        this.flushing = true;
                        _a = this;
                        return [4 /*yield*/, flushQueue(this, this.buffer)];
                    case 1:
                        _a.buffer = _b.sent();
                        this.flushing = false;
                        if (this.buffer.todo > 0) {
                            this.scheduleFlush();
                        }
                        return [2 /*return*/];
                }
            });
        }); }, Math.random() * 5000);
    };
    return LegacyDestination;
}());

function ajsDestinations(settings, globalIntegrations, options) {
    var _a, _b;
    if (globalIntegrations === void 0) { globalIntegrations = {}; }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var routingRules, routingMiddleware, integrationOptions;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_c) {
            if ((0,_core_environment__WEBPACK_IMPORTED_MODULE_10__.isServer)()) {
                return [2 /*return*/, []];
            }
            if (settings.plan) {
                options = options !== null && options !== void 0 ? options : {};
                options.plan = settings.plan;
            }
            routingRules = (_b = (_a = settings.middlewareSettings) === null || _a === void 0 ? void 0 : _a.routingRules) !== null && _b !== void 0 ? _b : [];
            routingMiddleware = (0,_routing_middleware__WEBPACK_IMPORTED_MODULE_11__.tsubMiddleware)(routingRules);
            integrationOptions = (0,_lib_merged_options__WEBPACK_IMPORTED_MODULE_12__.mergedOptions)(settings, options !== null && options !== void 0 ? options : {});
            return [2 /*return*/, Object.entries(settings.integrations)
                    .map(function (_a) {
                    var _b;
                    var name = _a[0], integrationSettings = _a[1];
                    if (name.startsWith('Segment')) {
                        return;
                    }
                    var allDisableAndNotDefined = globalIntegrations.All === false &&
                        globalIntegrations[name] === undefined;
                    if (globalIntegrations[name] === false || allDisableAndNotDefined) {
                        return;
                    }
                    var type = integrationSettings.type, bundlingStatus = integrationSettings.bundlingStatus, versionSettings = integrationSettings.versionSettings;
                    // We use `!== 'unbundled'` (versus `=== 'bundled'`) to be inclusive of
                    // destinations without a defined value for `bundlingStatus`
                    var deviceMode = bundlingStatus !== 'unbundled' &&
                        (type === 'browser' || ((_b = versionSettings === null || versionSettings === void 0 ? void 0 : versionSettings.componentTypes) === null || _b === void 0 ? void 0 : _b.includes('browser')));
                    // checking for iterable is a quick fix we need in place to prevent
                    // errors showing Iterable as a failed destiantion. Ideally, we should
                    // fix the Iterable metadata instead, but that's a longer process.
                    if ((!deviceMode && name !== 'Segment.io') || name === 'Iterable') {
                        return;
                    }
                    var version = (0,_loader__WEBPACK_IMPORTED_MODULE_7__.resolveVersion)(integrationSettings);
                    var destination = new LegacyDestination(name, version, integrationOptions[name], options);
                    var routing = routingRules.filter(function (rule) { return rule.destinationName === name; });
                    if (routing.length > 0) {
                        destination.addMiddleware(routingMiddleware);
                    }
                    return destination;
                })
                    .filter(function (xt) { return xt !== undefined; })];
        });
    });
}


/***/ }),

/***/ 9962:
/*!***********************************************!*\
  !*** ./src/plugins/ajs-destination/loader.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadIntegration": function() { return /* binding */ loadIntegration; },
/* harmony export */   "unloadIntegration": function() { return /* binding */ unloadIntegration; },
/* harmony export */   "resolveVersion": function() { return /* binding */ resolveVersion; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _lib_parse_cdn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/parse-cdn */ 46);
/* harmony import */ var _lib_load_script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/load-script */ 6673);
var _a, _b;



var cdn = (_b = (_a = window.analytics) === null || _a === void 0 ? void 0 : _a._cdn) !== null && _b !== void 0 ? _b : (0,_lib_parse_cdn__WEBPACK_IMPORTED_MODULE_0__.getCDN)();
var path = cdn + '/next-integrations';
function normalizeName(name) {
    return name.toLowerCase().replace('.', '').replace(/\s+/g, '-');
}
function recordLoadMetrics(fullPath, ctx, name) {
    var _a, _b, _c;
    try {
        var metric = ((_c = (_b = (_a = __webpack_require__.g.window) === null || _a === void 0 ? void 0 : _a.performance) === null || _b === void 0 ? void 0 : _b.getEntriesByName(fullPath, 'resource')) !== null && _c !== void 0 ? _c : [])[0];
        // we assume everything that took under 100ms is cached
        metric &&
            ctx.stats.gauge('legacy_destination_time', Math.round(metric.duration), (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__spreadArrays)([
                name
            ], (metric.duration < 100 ? ['cached'] : [])));
    }
    catch (_) {
        // not available
    }
}
function loadIntegration(ctx, analyticsInstance, name, version, settings) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var pathName, fullPath, err_1, deps, integrationBuilder, analyticsStub, integration;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    pathName = normalizeName(name);
                    fullPath = path + "/integrations/" + pathName + "/" + version + "/" + pathName + ".dynamic.js.gz";
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, (0,_lib_load_script__WEBPACK_IMPORTED_MODULE_2__.loadScript)(fullPath)];
                case 2:
                    _a.sent();
                    recordLoadMetrics(fullPath, ctx, name);
                    return [3 /*break*/, 4];
                case 3:
                    err_1 = _a.sent();
                    ctx.stats.gauge('legacy_destination_time', -1, ["plugin:" + name, "failed"]);
                    throw err_1;
                case 4:
                    deps = window[pathName + "Deps"];
                    return [4 /*yield*/, Promise.all(deps.map(function (dep) { return (0,_lib_load_script__WEBPACK_IMPORTED_MODULE_2__.loadScript)(path + dep + '.gz'); }))
                        // @ts-ignore
                    ];
                case 5:
                    _a.sent();
                    // @ts-ignore
                    window[pathName + "Loader"]();
                    integrationBuilder = window[pathName + "Integration"];
                    // GA and Appcues use a different interface to instantiating integrations
                    if (integrationBuilder.Integration) {
                        analyticsStub = {
                            user: function () { return analyticsInstance.user(); },
                            addIntegration: function () { },
                        };
                        integrationBuilder(analyticsStub);
                        integrationBuilder = integrationBuilder.Integration;
                    }
                    integration = new integrationBuilder(settings);
                    integration.analytics = analyticsInstance;
                    return [2 /*return*/, integration];
            }
        });
    });
}
function unloadIntegration(name, version) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var pathName;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            pathName = normalizeName(name);
            return [2 /*return*/, (0,_lib_load_script__WEBPACK_IMPORTED_MODULE_2__.unloadScript)(path + "/integrations/" + pathName + "/" + version + "/" + pathName + ".dynamic.js.gz")];
        });
    });
}
function resolveVersion(settings) {
    var _a, _b, _c, _d;
    return ((_d = (_b = (_a = settings.versionSettings) === null || _a === void 0 ? void 0 : _a.override) !== null && _b !== void 0 ? _b : (_c = settings.versionSettings) === null || _c === void 0 ? void 0 : _c.version) !== null && _d !== void 0 ? _d : 'latest');
}


/***/ }),

/***/ 2734:
/*!*****************************************!*\
  !*** ./src/plugins/middleware/index.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "applyDestinationMiddleware": function() { return /* binding */ applyDestinationMiddleware; },
/* harmony export */   "sourceMiddlewarePlugin": function() { return /* binding */ sourceMiddlewarePlugin; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _core_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/context */ 5373);
/* harmony import */ var _lib_as_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/as-promise */ 5764);
/* harmony import */ var _lib_to_facade__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/to-facade */ 2722);




function applyDestinationMiddleware(destination, evt, middleware) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
        function applyMiddleware(event, fn) {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
                var nextCalled, returnedEvent;
                var _a;
                return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            nextCalled = false;
                            returnedEvent = null;
                            return [4 /*yield*/, (0,_lib_as_promise__WEBPACK_IMPORTED_MODULE_1__.asPromise)(fn({
                                    payload: (0,_lib_to_facade__WEBPACK_IMPORTED_MODULE_2__.toFacade)(event, {
                                        clone: true,
                                        traverse: false,
                                    }),
                                    integration: destination,
                                    next: function (evt) {
                                        nextCalled = true;
                                        if (evt === null) {
                                            returnedEvent = null;
                                        }
                                        if (evt) {
                                            returnedEvent = evt.obj;
                                        }
                                    },
                                }))];
                        case 1:
                            _b.sent();
                            if (!nextCalled && returnedEvent !== null) {
                                returnedEvent = returnedEvent;
                                returnedEvent.integrations = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, event.integrations), (_a = {}, _a[destination] = false, _a));
                            }
                            return [2 /*return*/, returnedEvent];
                    }
                });
            });
        }
        var _i, middleware_1, md, result;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _i = 0, middleware_1 = middleware;
                    _a.label = 1;
                case 1:
                    if (!(_i < middleware_1.length)) return [3 /*break*/, 4];
                    md = middleware_1[_i];
                    return [4 /*yield*/, applyMiddleware(evt, md)];
                case 2:
                    result = _a.sent();
                    if (result === null) {
                        return [2 /*return*/, null];
                    }
                    evt = result;
                    _a.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4: return [2 /*return*/, evt];
            }
        });
    });
}
function sourceMiddlewarePlugin(fn, integrations) {
    function apply(ctx) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, Promise, function () {
            var nextCalled;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        nextCalled = false;
                        return [4 /*yield*/, (0,_lib_as_promise__WEBPACK_IMPORTED_MODULE_1__.asPromise)(fn({
                                payload: (0,_lib_to_facade__WEBPACK_IMPORTED_MODULE_2__.toFacade)(ctx.event, {
                                    clone: true,
                                    traverse: false,
                                }),
                                integrations: integrations !== null && integrations !== void 0 ? integrations : {},
                                next: function (evt) {
                                    nextCalled = true;
                                    if (evt) {
                                        ctx.event = evt.obj;
                                    }
                                },
                            }))];
                    case 1:
                        _a.sent();
                        if (!nextCalled) {
                            throw new _core_context__WEBPACK_IMPORTED_MODULE_3__.ContextCancelation({
                                retry: false,
                                type: 'middleware_cancellation',
                                reason: 'Middleware `next` function skipped',
                            });
                        }
                        return [2 /*return*/, ctx];
                }
            });
        });
    }
    return {
        name: "Source Middleware " + fn.name,
        type: 'before',
        version: '0.1.0',
        isLoaded: function () { return true; },
        load: function (ctx) { return Promise.resolve(ctx); },
        track: apply,
        page: apply,
        identify: apply,
        alias: apply,
        group: apply,
    };
}


/***/ }),

/***/ 4186:
/*!*************************************************!*\
  !*** ./src/plugins/routing-middleware/index.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tsubMiddleware": function() { return /* binding */ tsubMiddleware; }
/* harmony export */ });
/* harmony import */ var _segment_tsub__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @segment/tsub */ 5130);

var tsubMiddleware = function (rules) { return function (_a) {
    var payload = _a.payload, integration = _a.integration, next = _a.next;
    var store = new _segment_tsub__WEBPACK_IMPORTED_MODULE_0__.Store(rules);
    var rulesToApply = store.getRulesByDestinationName(integration);
    rulesToApply.forEach(function (rule) {
        var matchers = rule.matchers, transformers = rule.transformers;
        for (var i = 0; i < matchers.length; i++) {
            if (_segment_tsub__WEBPACK_IMPORTED_MODULE_0__.matches(payload.obj, matchers[i])) {
                payload.obj = _segment_tsub__WEBPACK_IMPORTED_MODULE_0__.transform(payload.obj, transformers[i]);
                if (payload.obj === null) {
                    return next(null);
                }
            }
        }
    });
    next(payload);
}; };


/***/ })

}]);
//# sourceMappingURL=ajs-destination.bundle.6aae057c068eea9d5067.js.map