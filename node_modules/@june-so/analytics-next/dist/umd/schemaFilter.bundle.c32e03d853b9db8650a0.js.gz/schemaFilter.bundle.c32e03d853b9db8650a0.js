"use strict";
(self["webpackChunk_june_so_analytics_next"] = self["webpackChunk_june_so_analytics_next"] || []).push([["schemaFilter"],{

/***/ 8497:
/*!********************************************!*\
  !*** ./src/plugins/schema-filter/index.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "schemaFilter": function() { return /* binding */ schemaFilter; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 655);

function disabledActionDestinations(plan, settings) {
    var _a, _b;
    if (!plan || !Object.keys(plan)) {
        return {};
    }
    var disabledIntegrations = Object.keys(plan.integrations).filter(function (i) { return plan.integrations[i] === false; });
    // This accounts for cases like Fullstory, where the settings.integrations
    // contains a "Fullstory" object but settings.remotePlugins contains "Fullstory (Actions)"
    var disabledRemotePlugins = [];
    ((_a = settings.remotePlugins) !== null && _a !== void 0 ? _a : []).forEach(function (p) {
        disabledIntegrations.forEach(function (int) {
            if (p.name.includes(int) || int.includes(p.name)) {
                disabledRemotePlugins.push(p.name);
            }
        });
    });
    return ((_b = settings.remotePlugins) !== null && _b !== void 0 ? _b : []).reduce(function (acc, p) {
        // @ts-expect-error element implicitly has an 'any' type because p.settings is a JSONValue
        if (p.settings['subscriptions']) {
            if (disabledRemotePlugins.includes(p.name)) {
                // @ts-expect-error element implicitly has an 'any' type because p.settings is a JSONValue
                p.settings['subscriptions'].forEach(
                // @ts-expect-error parameter 'sub' implicitly has an 'any' type
                function (sub) { return (acc[p.name + " " + sub.partnerAction] = false); });
            }
        }
        return acc;
    }, {});
}
function schemaFilter(track, settings) {
    function filter(ctx) {
        var plan = track;
        var ev = ctx.event.event;
        if (plan && ev) {
            var planEvent = plan[ev];
            if ((planEvent === null || planEvent === void 0 ? void 0 : planEvent.enabled) === false) {
                ctx.updateEvent('integrations', (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, ctx.event.integrations), { All: false, 'Segment.io': true }));
                return ctx;
            }
            else {
                var disabledActions = disabledActionDestinations(planEvent, settings);
                ctx.updateEvent('integrations', (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, ctx.event.integrations), planEvent === null || planEvent === void 0 ? void 0 : planEvent.integrations), disabledActions));
            }
        }
        return ctx;
    }
    return {
        name: 'Schema Filter',
        version: '0.1.0',
        isLoaded: function () { return true; },
        load: function () { return Promise.resolve(); },
        type: 'before',
        page: filter,
        alias: filter,
        track: filter,
        identify: filter,
        group: filter,
    };
}


/***/ })

}]);
//# sourceMappingURL=schemaFilter.bundle.c32e03d853b9db8650a0.js.map