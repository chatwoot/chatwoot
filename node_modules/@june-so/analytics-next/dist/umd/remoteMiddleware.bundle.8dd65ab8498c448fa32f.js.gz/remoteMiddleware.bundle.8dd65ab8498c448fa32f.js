"use strict";
(self["webpackChunk_june_so_analytics_next"] = self["webpackChunk_june_so_analytics_next"] || []).push([["remoteMiddleware"],{

/***/ 7070:
/*!************************************************!*\
  !*** ./src/plugins/remote-middleware/index.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "remoteMiddlewares": function() { return /* binding */ remoteMiddlewares; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 655);
/* harmony import */ var _core_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/environment */ 4083);
/* harmony import */ var _lib_load_script__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/load-script */ 6673);
/* harmony import */ var _lib_parse_cdn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/parse-cdn */ 46);
var _a, _b;




var cdn = (_b = (_a = window.analytics) === null || _a === void 0 ? void 0 : _a._cdn) !== null && _b !== void 0 ? _b : (0,_lib_parse_cdn__WEBPACK_IMPORTED_MODULE_0__.getCDN)();
var path = cdn + '/next-integrations';
function remoteMiddlewares(ctx, settings) {
    var _a;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, Promise, function () {
        var remoteMiddleware, names, scripts, middleware;
        var _this = this;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if ((0,_core_environment__WEBPACK_IMPORTED_MODULE_2__.isServer)()) {
                        return [2 /*return*/, []];
                    }
                    remoteMiddleware = (_a = settings.enabledMiddleware) !== null && _a !== void 0 ? _a : {};
                    names = Object.keys(remoteMiddleware);
                    scripts = names.map(function (name) { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () {
                        var nonNamespaced, fullPath, error_1;
                        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    nonNamespaced = name.replace('@segment/', '');
                                    fullPath = path + "/middleware/" + nonNamespaced + "/latest/" + nonNamespaced + ".js.gz";
                                    _a.label = 1;
                                case 1:
                                    _a.trys.push([1, 3, , 4]);
                                    return [4 /*yield*/, (0,_lib_load_script__WEBPACK_IMPORTED_MODULE_3__.loadScript)(fullPath)
                                        // @ts-ignore
                                    ];
                                case 2:
                                    _a.sent();
                                    // @ts-ignore
                                    return [2 /*return*/, window[nonNamespaced + "Middleware"]];
                                case 3:
                                    error_1 = _a.sent();
                                    ctx.log('error', error_1);
                                    ctx.stats.increment('failed_remote_middleware');
                                    return [3 /*break*/, 4];
                                case 4: return [2 /*return*/];
                            }
                        });
                    }); });
                    return [4 /*yield*/, Promise.all(scripts)];
                case 1:
                    middleware = _b.sent();
                    middleware = middleware.filter(Boolean);
                    return [2 /*return*/, middleware];
            }
        });
    });
}


/***/ })

}]);
//# sourceMappingURL=remoteMiddleware.bundle.8dd65ab8498c448fa32f.js.map